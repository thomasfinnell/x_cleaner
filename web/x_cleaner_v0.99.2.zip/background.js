importScripts('subscription.js', 'api-fetch.js', 'rest-fetch.js');

let jobTabId = null;
let activeFetch = null;
let jobCancelled = false;
let listType = 'following';
let jobState = {
  username: null,
  listType: 'following',
  totalFollowing: null,
  totalFollowers: null,
  count: 0,
  isScraping: false,
  reason: null,
  method: 'graphql'
};

const LIST_TYPES = ['following', 'followers'];
const LIST_CONFIG = {
  following: {
    persistKey: 'xc_following_persist',
    opName: 'Following',
    path: 'following',
    label: 'Following',
    totalKey: 'totalFollowing'
  },
  followers: {
    persistKey: 'xc_followers_persist',
    opName: 'Followers',
    path: 'followers',
    label: 'Followers',
    totalKey: 'totalFollowers'
  }
};

const listStore = {
  following: { list: [], raw: [] },
  followers: { list: [], raw: [] }
};

const DEFAULT_INACTIVE_MONTHS = 6;
const BOT_CHECK_TWEET_MAX = 10;
const BOT_CHECK_ACCOUNT_MAX_DAYS = 30;
const BOT_CHECK_USERNAME_TRAILING_DIGITS = 4;
const BOT_CHECK_FOLLOWERS_RATIO = 2;
const MIN_FILTER_MONTHS = 1;
const MAX_FILTER_MONTHS = 24;
const ENRICH_BATCH_SIZE = XC_REST_LOOKUP_BATCH_SIZE;
const ENRICH_BATCH_DELAY_MS = XC_REST_LOOKUP_DELAY_MS;
const INACTIVE_LOOKUP_BATCH_SIZE = 12;
const INACTIVE_LOOKUP_DELAY_MS = 2800;
const ENRICH_RATE_LIMIT_MAX_RETRIES = 8;
const ENRICH_BEARER_WAIT_MS = 12000;
const SNIFFER_ENRICH_PASSES = 4;
const SNIFFER_ENRICH_SCROLL = 1100;
const SNIFFER_ENRICH_DELAY_MS = 450;
const XC_ACTIVITY_CACHE_KEY = 'xc_activity_cache';
const XC_ACTIVITY_CACHE_TTL_MS = 14 * 24 * 60 * 60 * 1000;
const XC_ENRICH_ARCHIVE_KEY = 'xc_enrich_archive';
const XC_ENRICH_ARCHIVE_VERSION = 1;
const XC_LIST_TYPE_PREF_KEY = 'xc_list_type_pref';
const XC_FETCH_MODE_PREF_KEY = 'xc_fetch_mode_pref';
const XC_FETCH_MODES = ['auto', 'rest', 'sniffer'];
const XC_FETCH_MODE_DEFAULT = 'auto';
const XC_GENTLE_DWELL_BASE_MS = 30000;
const XC_GENTLE_DWELL_JITTER_MS = 5000;
const XC_FAST_SCROLL_PREF_KEY = 'xc_fast_scroll_pref';
const XC_PERSIST_VERSION = 1;
const XC_PERSIST_COLLECT_INTERVAL = 250;
const XC_PERSIST_DEBOUNCE_MS = 15000;
// Let X finish rendering after tab navigation before sniffing/API capture.
const XC_PROFILE_NAV_SETTLE_MS = 2500;
const XC_LIST_NAV_SETTLE_MS = 3500;
const XC_FOLLOWERS_NAV_SETTLE_MS = 5000;
const XC_PRE_LIST_FETCH_SETTLE_MS = 1500;
const XC_POST_SNIFFER_SETTLE_MS = 800;

// Gentle mode recovery caps for followers: keep absolute numbers small even on large lists
// (stealth-friendly for overnight runs) but allow a small % so large accounts can finish.
function gentleFollowersRecoveryCap(totalList) {
  if (!totalList || totalList <= 0) return 40;
  const pct = Math.floor(totalList * 0.012); // ~1.2%
  return Math.min(120, Math.max(30, pct));
}

// Set false to hide the scrollable status log in the HUD/popup.
const XC_DEBUG_STATUS_LOG = false;

const XC_DEBUG_STATUS_LOG_MAX_LINES = 50;
const XC_DEBUG_STATUS_LOG_STORAGE_KEY = 'xc_debug_status_log';

let activeEnrich = false;
let subscriptionInfo = xcBuildSubscriptionInfo('', false);
const restoredTypes = { following: false, followers: false };
let restorePromise = null;
const persistDebounceTimers = { following: null, followers: null };
const lastPersistedCounts = { following: 0, followers: 0 };
const persistGuard = { following: 0, followers: 0 };
let enrichArchiveStore = null;
let enrichArchiveSaveTimer = null;
const freshStartBackupTypes = new Set();
let fastScrollEnabled = false;
let gentleScrollStepCount = 0;

function listCfg(type = listType) {
  return LIST_CONFIG[type] || LIST_CONFIG.following;
}

function normalizeAccountHandle(username) {
  return String(username || '').toLowerCase().replace(/^@+/, '').trim();
}

function persistStorageKey(type, username) {
  const cfg = listCfg(type);
  const handle = normalizeAccountHandle(username);
  if (!handle) return cfg.persistKey;
  return `${cfg.persistKey}@${handle}`;
}

async function readPersistData(type, username) {
  const cfg = listCfg(type);
  const handle = normalizeAccountHandle(username || jobState.username);
  const accountKey = handle ? persistStorageKey(type, handle) : null;
  const keys = accountKey ? [accountKey, cfg.persistKey] : [cfg.persistKey];
  const res = await chrome.storage.local.get(keys);

  if (accountKey && res[accountKey]) {
    return { data: res[accountKey], key: accountKey };
  }

  const legacy = res[cfg.persistKey];
  if (!legacy) return { data: null, key: null };

  const savedUser = normalizeAccountHandle(legacy.jobState?.username);
  if (handle && savedUser && savedUser !== handle) {
    return { data: null, key: null };
  }

  if (handle && savedUser === handle && accountKey) {
    try {
      await chrome.storage.local.set({ [accountKey]: legacy });
      await chrome.storage.local.remove(cfg.persistKey);
    } catch (error) {}
    return { data: legacy, key: accountKey };
  }

  return { data: legacy, key: cfg.persistKey };
}

function curList(type = listType) {
  return listStore[type].list;
}

function curRaw(type = listType) {
  return listStore[type].raw;
}

function setCurList(value, type = listType) {
  listStore[type].list = value;
}

function setCurRaw(value, type = listType) {
  listStore[type].raw = value;
}

function totalForType(type = listType) {
  const cfg = listCfg(type);
  return jobState[cfg.totalKey] ?? null;
}

function restoredFromStorage() {
  return restoredTypes.following || restoredTypes.followers;
}

async function sniffCreatorSubscriptions(tabId, options = {}) {
  const forceRefresh = !!options.forceNavigate;
  const passiveOnly = !!options.passiveOnly;

  if (!tabId) return { ok: false, handles: [] };

  await ensureSnifferInstalled(tabId);

  if (!forceRefresh) {
    const existing = await executeOnTab(tabId, readCreatorSubscriptionsCapture);
    if (existing?.ok) {
      return { ok: true, handles: existing.handles || [], capturedAt: existing.capturedAt };
    }
  }

  if (passiveOnly && !forceRefresh) {
    return { ok: false, handles: [] };
  }

  if (forceRefresh) {
    await executeOnTab(tabId, () => {
      try {
        sessionStorage.removeItem('xc_creator_subs_latest');
      } catch (error) {}
    });
  }

  const active = await fetchCreatorSubscriptionsFromTab(tabId);
  if (active?.ok) {
    const payload = {
      ok: true,
      handles: active.handles || [],
      capturedAt: Date.now()
    };
    await executeOnTab(tabId, (data) => {
      try {
        sessionStorage.setItem('xc_creator_subs_latest', JSON.stringify(data));
      } catch (error) {}
    }, [payload]);
    return payload;
  }

  return { ok: false, handles: [] };
}

function isXTabUrl(url) {
  return /^https:\/\/x\.com\//.test(url || '');
}

async function resolveActiveUsername(explicitHandle) {
  if (explicitHandle) return explicitHandle;

  const tab = await findFocusedXTab();
  if (tab?.id) {
    jobTabId = tab.id;
    try {
      const detected = await detectHandle(tab.id);
      if (detected) {
        jobState.username = detected;
        return detected;
      }
    } catch (error) {
      console.warn('[X Cleaner] handle detect for subscription failed', error);
    }
  }

  if (jobState.username) return jobState.username;

  const tabId = await ensureJobTabId();
  if (!tabId) return null;

  try {
    const detected = await detectHandle(tabId);
    if (detected) {
      jobState.username = detected;
      return detected;
    }
  } catch (error) {
    console.warn('[X Cleaner] handle detect for subscription failed', error);
  }

  return null;
}

async function hydrateSubscriptionFromStorage(handle) {
  subscriptionInfo = await xcHydrateSubscriptionFromStorage(handle || jobState.username);
  return subscriptionInfo;
}

async function subscriptionCacheIsFresh(handle) {
  const resolvedHandle = await resolveActiveUsername(handle);
  if (!resolvedHandle) return false;
  return xcSubscriptionCacheIsFreshForHandle(resolvedHandle);
}

async function refreshSubscription(handle, forceCheck = false) {
  const resolvedHandle = await resolveActiveUsername(handle);
  if (!forceCheck) {
    await hydrateSubscriptionFromStorage(resolvedHandle);
    const state = await xcLoadSubscriptionState();
    const normalized = xcNormalizeHandle(resolvedHandle);
    const cached = xcReadCachedAuthorization(state.subscriptionCache, normalized);
    if (cached) {
      subscriptionInfo = xcBuildInfoFromCachedAuth(normalized, cached);
      return subscriptionInfo;
    }
  }

  const tabId = await ensureJobTabId();
  const timeoutMs = forceCheck ? 45000 : 12000;
  let timedOut = false;

  const checkPromise = xcCheckSubscription(resolvedHandle, {
    forceCheck,
    sniff: tabId
      ? () => sniffCreatorSubscriptions(tabId, {
        forceNavigate: forceCheck,
        passiveOnly: !forceCheck
      })
      : null
  });

  const result = await Promise.race([
    checkPromise,
    new Promise((resolve) => {
      setTimeout(() => {
        timedOut = true;
        resolve(null);
      }, timeoutMs);
    })
  ]);

  if (result) {
    subscriptionInfo = result;
  } else if (timedOut) {
    if (!subscriptionInfo?.hydratedFromStorage) {
      await hydrateSubscriptionFromStorage(resolvedHandle);
    }
    subscriptionInfo = {
      ...subscriptionInfo,
      sniffFailed: true,
      sniffError: `Subscription check timed out after ${Math.round(timeoutMs / 1000)}s — using cached status`
    };
  }

  return subscriptionInfo;
}

function effectiveFetchTarget(totalList) {
  const cap = subscriptionInfo.fetchLimit;
  if (cap == null) {
    return totalList;
  }
  if (totalList == null) {
    return cap;
  }
  return Math.min(totalList, cap);
}

function normalizeFetchMode(mode) {
  const value = String(mode || '').toLowerCase();
  return XC_FETCH_MODES.includes(value) ? value : XC_FETCH_MODE_DEFAULT;
}

async function getFetchMode() {
  return XC_FETCH_MODE_DEFAULT;
}

async function setFetchMode(_mode) {
  return XC_FETCH_MODE_DEFAULT;
}

async function loadFastScrollPref() {
  const res = await chrome.storage.local.get(XC_FAST_SCROLL_PREF_KEY);
  fastScrollEnabled = !!res[XC_FAST_SCROLL_PREF_KEY];
  return fastScrollEnabled;
}

async function setFastScrollPref(enabled) {
  fastScrollEnabled = !!enabled;
  await chrome.storage.local.set({ [XC_FAST_SCROLL_PREF_KEY]: fastScrollEnabled });
  return fastScrollEnabled;
}

function scrollModeLabel() {
  return fastScrollEnabled ? 'fast scroll' : 'observe + gentle scroll';
}

function scrollJitterMs(base, spread = 0.35) {
  const delta = Math.floor(base * spread * (Math.random() * 2 - 1));
  return Math.max(800, base + delta);
}

async function sleepAfterScrollStep(type = listType, context = 'tail') {
  if (fastScrollEnabled) {
    if (context === 'native-loop') {
      const remaining = jobState.totalFollowing != null || jobState.totalFollowers != null
        ? (totalForType(type) || 0) - curList(type).length
        : null;
      if (remaining != null && remaining > 0 && remaining <= 100) {
        return type === 'followers' ? 2200 : 1800;
      }
      return type === 'followers' ? 2200 : 1800;
    }
    if (context === 'shortfall') {
      return type === 'followers' ? 2500 : 1800;
    }
    return type === 'followers' ? 1600 : 1200;
  }

  if (context === 'nudge') {
    return scrollJitterMs(type === 'followers' ? 4500 : 9000, 0.35);
  }
  if (context === 'shortfall') {
    return scrollJitterMs(type === 'followers' ? 8000 : 13000, 0.3);
  }
  if (context === 'native-loop') {
    return scrollJitterMs(type === 'followers' ? 5000 : 12000, 0.35);
  }
  return scrollJitterMs(type === 'followers' ? 6000 : 11000, 0.35);
}

function observeLoopPaceMs(type = listType, added = 0) {
  if (fastScrollEnabled) {
    return type === 'followers' ? 2200 : 1800;
  }
  if (type === 'followers') {
    if (added >= 15) return scrollJitterMs(1800, 0.2);
    if (added > 0) return scrollJitterMs(3000, 0.25);
    return scrollJitterMs(4500, 0.25);
  }
  if (added > 0) return scrollJitterMs(6500, 0.3);
  return scrollJitterMs(9000, 0.3);
}

async function maybeGentleDwellPause(type = listType) {
  if (fastScrollEnabled) return;
  if (type === 'followers') return;
  const cfg = listCfg(type);
  const totalList = jobState[cfg.totalKey] ?? null;
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (gap != null && gap > 100) return;
  if (gap != null && gap > 0 && gap <= 15) return;
  if (gentleScrollStepCount % 20 !== 0) return;
  const dwellMs = XC_GENTLE_DWELL_BASE_MS
    + Math.floor(Math.random() * (XC_GENTLE_DWELL_JITTER_MS * 2 + 1))
    - XC_GENTLE_DWELL_JITTER_MS;
  notifyProgress({
    status: `Gentle pace — pausing ${Math.round(dwellMs / 1000)}s before next scroll...`
  });
  await sleep(dwellMs, { cancellable: true });
  if (isJobCancelled()) return;
}

async function scrollListStep(tabId) {
  if (fastScrollEnabled || listType === 'followers') {
    await executeOnTab(tabId, injectedScrollListStep);
    gentleScrollStepCount += 1;
    appendDebugStatusLog({
      reason: 'scroll-step',
      method: jobState.method || listType,
      status: fastScrollEnabled
        ? 'Fast scroll step (list column)'
        : `Followers observe scroll #${gentleScrollStepCount}`
    });
    await maybeGentleDwellPause(listType);
    return;
  }
  const scrollResult = await gentleScrollStepFromTab(tabId, gentleScrollStepCount);
  gentleScrollStepCount += 1;
  const movedNote = scrollResult?.moved === false ? ' (no movement)' : '';
  const regionNote = scrollResult?.region ? ` @${scrollResult.region}` : '';
  appendDebugStatusLog({
    reason: 'scroll-step',
    method: jobState.method || 'observe',
    passes: gentleScrollStepCount,
    status: `Gentle scroll #${gentleScrollStepCount}: ${scrollResult?.pattern || 'unknown'}${regionNote}${movedNote}`
  });
  await maybeGentleDwellPause(listType);
}

async function scrollListToLoad(tabId, options = {}) {
  const gap = options.gap ?? null;
  const aggressive = !!options.aggressive || (gap != null && gap > 0 && gap <= (listType === 'followers' ? 40 : 25));
  if (fastScrollEnabled || aggressive) {
    await executeOnTab(tabId, injectedScrollListToLoad);
    if (!fastScrollEnabled && aggressive) {
      await sleep(scrollJitterMs(1800, 0.25), { cancellable: true });
      if (isJobCancelled()) return;
      await executeOnTab(tabId, injectedScrollListToLoad);
    }
    return;
  }
  for (let i = 0; i < 2; i += 1) {
    await scrollListStep(tabId);
    await sleep(scrollJitterMs(3500, 0.3), { cancellable: true });
    if (isJobCancelled()) return;
  }
}

async function scrollListToTop(tabId) {
  await executeOnTab(tabId, injectedScrollListToTop);
}

async function pacedNudgeTabScroll(tabId, amount = 900) {
  if (fastScrollEnabled) {
    await nudgeTabListScroll(tabId, amount);
    await sleep(amount > 800 ? 550 : 300, { cancellable: true });
    return;
  }
  await gentleScrollStepFromTab(tabId, gentleScrollStepCount);
  gentleScrollStepCount += 1;
  await sleep(await sleepAfterScrollStep(listType, 'nudge'), { cancellable: true });
  if (isJobCancelled()) return;
  await maybeGentleDwellPause(listType);
}

async function ensureProfileUserId(tabId, profile) {
  if (profile?.userId) return profile.userId;
  try {
    const catalog = await prefetchQueryCatalog(false);
    profile.userId = await resolveUserIdFromScreenName(profile.username, catalog, tabId);
  } catch (error) {}
  return profile?.userId || null;
}

async function observeFinishShortfall(tabId, profile, type, seen, totalList, options = {}) {
  if (isJobCancelled()) return 0;
  if (!listFetchNeedsMore(type, totalList)) return 0;
  let gap = totalList != null ? totalList - curList(type).length : null;
  if (!gap || gap <= 0) return 0;

  const cfg = listCfg(type);
  let totalAdded = 0;
  const noteProgress = (status, method = 'observe') => {
    appendDebugStatusLog({ reason: 'collecting', method, status });
    notifyProgress({ reason: 'collecting', method, status });
  };

  noteProgress(
    `Observe finish — ${gap.toLocaleString()} short (tail GraphQL + sniffer, no REST bulk)...`
  );

  await ensureProfileUserId(tabId, profile);
  try {
    await scrollListToTop(tabId);
    await sleep(scrollJitterMs(fastScrollEnabled ? 800 : 1500, 0.2), { cancellable: true });
    if (isJobCancelled()) return totalAdded;
    await scrollListToLoad(tabId, { gap, aggressive: true });
    await sleep(scrollJitterMs(fastScrollEnabled ? 1200 : 1800, 0.2), { cancellable: true });
    if (isJobCancelled()) return totalAdded;
  } catch (error) {}

  try {
    const drained = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
    if (drained?.users?.length) {
      const queueAdded = addNativeUsers({ users: drained.users }, seen, profile.username, type);
      totalAdded += queueAdded;
      trimListToFetchLimit(type);
      if (queueAdded > 0) {
        noteProgress(
          `Observe queue drain — ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${queueAdded})`,
          'native-sniffer'
        );
      }
    }
  } catch (error) {}

  totalAdded += await fetchListTailGap(tabId, profile, type, seen, totalList);

  if (listFetchNeedsMore(type, totalList) && profile.userId) {
    noteProgress(`Observe finish — GraphQL restart (${gap.toLocaleString()} short)...`, 'graphql');
    totalAdded += await continueListFetchWithGraphql(
      tabId,
      profile,
      type,
      seen,
      effectiveFetchTarget(totalList),
      totalList,
      { restartFromTop: true, skipPostRecovery: true }
    );
  }

  if (listFetchNeedsMore(type, totalList)) {
    totalAdded += await recoverShortfallViaTabGraphql(
      tabId,
      profile,
      type,
      seen,
      totalList,
      { skipWarmup: true }
    );
  }

  if (listFetchNeedsMore(type, totalList)) {
    totalAdded += await recoverShortfallViaWorkerGraphql(tabId, profile, type, seen, totalList);
  }

  if (listFetchNeedsMore(type, totalList)) {
    totalAdded += await recoverShortfallViaNativeScrollSniffer(tabId, profile, type, seen, totalList);
  }

  gap = totalList != null ? totalList - curList(type).length : null;
  const restGapCap = type === 'following' ? 200 : gentleFollowersRecoveryCap(totalList);
  if (options.allowRest !== false && gap > 0 && gap <= restGapCap && listFetchNeedsMore(type, totalList)) {
    noteProgress(`Observe finish — REST cursor recovery (${gap.toLocaleString()} short)...`, 'observe');
    totalAdded += await recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList, {
      maxPages: type === 'following' ? 16 : 12,
      scrollToLoad: true
    });
    if (isJobCancelled()) return totalAdded;
    gap = totalList != null ? totalList - curList(type).length : null;
    const restTailCap = type === 'following' ? 200 : Math.min(50, gentleFollowersRecoveryCap(totalList));
    if (gap > 0 && gap <= restTailCap && listFetchNeedsMore(type, totalList)) {
      noteProgress(`Observe finish — targeted REST lookup (${gap.toLocaleString()} short)...`, 'observe');
      totalAdded += await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
    }
  }

  return totalAdded;
}

async function observeRecoverShortfall(tabId, profile, type, seen, totalList) {
  const gap = totalList != null ? totalList - curList(type).length : null;
  const maxGap = type === 'followers' ? gentleFollowersRecoveryCap(totalList) : 25;
  if (!gap || gap <= 0 || gap > maxGap) return 0;
  return observeFinishShortfall(tabId, profile, type, seen, totalList);
}

function fetchModeLabel(mode) {
  if (mode === 'rest') return 'REST v1.1 (200/page)';
  if (mode === 'sniffer') return 'native sniffer + GraphQL';
  return 'auto: REST → GraphQL worker → sniffer';
}

function trimListToFetchLimit(type = listType) {
  const cap = subscriptionInfo.fetchLimit;
  if (cap == null || curList(type).length <= cap) return;
  setCurList(curList(type).slice(0, cap), type);
}

function subscriptionPayload() {
  const status = xcFormatSubscriptionStatus(subscriptionInfo, jobState.username);
  return {
    ...subscriptionInfo,
    canExport: true,
    subscriptionStatus: status
  };
}

async function clearAllListPersistForAccount(username) {
  const handle = normalizeAccountHandle(username);
  if (!handle) return;
  const keys = LIST_TYPES.map((type) => persistStorageKey(type, handle));
  await chrome.storage.local.remove(keys);
}

async function applyFreeTierWindow(handle) {
  const resolved = await resolveActiveUsername(handle);
  if (!resolved) return null;

  await hydrateSubscriptionFromStorage(resolved);
  if (subscriptionInfo.isSubscribed) {
    return { reset: false };
  }

  const windowInfo = await xcEnsureFreeTierWindow(resolved);
  subscriptionInfo = {
    ...subscriptionInfo,
    canExport: true,
    freeTierResetsAt: windowInfo.resetsAt
  };

  if (windowInfo.reset) {
    await clearAllListPersistForAccount(resolved);
    for (const type of LIST_TYPES) {
      setCurList([], type);
      setCurRaw([], type);
      restoredTypes[type] = false;
    }
    if ((jobState.username || '').toLowerCase() === resolved.toLowerCase()) {
      jobState.count = 0;
      jobState.rawCount = 0;
      jobState.savedAt = null;
      jobState.reason = null;
      jobState.status = `Free tier reset — cached lists cleared. Collect up to ${XC_FREE_FETCH_LIMIT} again.`;
      notifyProgress({ status: jobState.status, reason: 'complete' });
    }
  }

  return windowInfo;
}

const LIST_TYPE_IDLE_REASONS = new Set([
  'filtered',
  'complete',
  'stopped',
  'exported',
  'error',
  'end-of-list',
  'observe-empty',
  'rest-empty',
  'filtering',
  'enriching'
]);

const LIST_TYPE_MID_FLIGHT_REASONS = new Set([
  'start',
  'collecting',
  'loading-profile',
  'profile-loaded',
  'waiting-native',
  'filtering',
  'enriching'
]);

function clearStaleActiveFetch() {
  if (!activeFetch?.running || activeEnrich?.running) return;
  if (jobState.isScraping || jobState.isEnriching) return;
  if (LIST_TYPE_MID_FLIGHT_REASONS.has(jobState.reason)) return;
  activeFetch = null;
}

function isListTypeSwitchLocked(state = jobState) {
  if (activeEnrich?.running) return true;
  if (!activeFetch?.running) return false;
  if (!jobState.isScraping && !jobState.isEnriching && !LIST_TYPE_MID_FLIGHT_REASONS.has(jobState.reason)) {
    return false;
  }
  return true;
}

function buildListStats() {
  return {
    following: {
      count: listStore.following.list.length,
      rawCount: listStore.following.raw.length || listStore.following.list.length,
      total: jobState.totalFollowing ?? null
    },
    followers: {
      count: listStore.followers.list.length,
      rawCount: listStore.followers.raw.length || listStore.followers.list.length,
      total: jobState.totalFollowers ?? null
    }
  };
}

async function withFastScrollRecoveryBoost(fn) {
  const prev = fastScrollEnabled;
  fastScrollEnabled = true;
  try {
    return await fn();
  } finally {
    fastScrollEnabled = prev;
  }
}

function reconcileIdleJobState() {
  clearStaleActiveFetch();

  if (activeFetch?.running || activeEnrich?.running) return;

  if (activeEnrich && !activeEnrich.running) {
    activeEnrich = null;
  }

  if (jobState.isEnriching) {
    jobState.isEnriching = false;
  }

  const midFlightReasons = new Set([
    'start',
    'collecting',
    'loading-profile',
    'profile-loaded',
    'waiting-native',
    'filtering',
    'enriching'
  ]);

  if (jobState.isScraping && midFlightReasons.has(jobState.reason)) {
    jobState.isScraping = false;
    jobState.reason = curList().length > 0 ? 'complete' : (jobState.reason === 'filtering' ? 'filtered' : null);
  } else if (jobState.isScraping && LIST_TYPE_IDLE_REASONS.has(jobState.reason)) {
    jobState.isScraping = false;
  }

  if (jobState.reason === 'filtering' || jobState.reason === 'enriching') {
    jobState.isEnriching = false;
    if (!activeEnrich?.running) {
      jobState.reason = curList().length > 0 ? 'filtered' : 'complete';
    }
  }
}

function normalizeClientState(state) {
  reconcileIdleJobState();
  const next = { ...state };
  const enriching = !!(activeEnrich?.running || next.isEnriching);
  const collecting = !!activeFetch?.running;

  if (!collecting && LIST_TYPE_IDLE_REASONS.has(next.reason)) {
    next.isScraping = false;
  }
  if (!enriching && (next.reason === 'filtered' || next.reason === 'complete' || next.reason === 'stopped')) {
    next.isEnriching = false;
  }
  next.listTypeLocked = isListTypeSwitchLocked(next);
  return next;
}

function buildHudState(extra = {}) {
  return normalizeClientState({
    ...jobState,
    listType,
    count: curList().length,
    rawCount: curRaw().length || curList().length,
    totalList: totalForType(),
    storedCounts: {
      following: listStore.following.list.length,
      followers: listStore.followers.list.length
    },
    mutuals: computeMutuals(),
    fetchMode: jobState.fetchMode || XC_FETCH_MODE_DEFAULT,
    fastScroll: fastScrollEnabled,
    fastScrollLabel: scrollModeLabel(),
    listStats: buildListStats(),
    ...subscriptionPayload(),
    ...debugStatusPayload(),
    ...extra
  });
}

function sleep(ms, options = {}) {
  if (!options.cancellable) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }
  const stepMs = 200;
  const deadline = Date.now() + ms;
  return (async () => {
    while (Date.now() < deadline) {
      if (isJobCancelled()) return;
      const remaining = deadline - Date.now();
      await new Promise((resolve) => setTimeout(resolve, Math.min(stepMs, remaining)));
    }
  })();
}

async function waitForTabComplete(tabId, timeout = 25000) {
  return new Promise((resolve) => {
    let done = false;
    const finish = () => {
      if (!done) {
        done = true;
        resolve();
      }
    };

    const listener = (updatedId, info) => {
      if (updatedId === tabId && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(listener);
        finish();
      }
    };

    chrome.tabs.onUpdated.addListener(listener);
    setTimeout(() => {
      chrome.tabs.onUpdated.removeListener(listener);
      finish();
    }, timeout);
  });
}

async function waitAfterTabNavigation(tabId, settleMs = XC_LIST_NAV_SETTLE_MS) {
  await waitForTabComplete(tabId);
  if (settleMs > 0) {
    await sleep(settleMs);
  }
}

function mergeRelationshipFields(existing, incoming) {
  if (!existing || !incoming) return existing;
  if (existing.you_follow == null && incoming.you_follow != null) existing.you_follow = incoming.you_follow;
  if (existing.follows_you == null && incoming.follows_you != null) existing.follows_you = incoming.follows_you;
  return existing;
}

function mergeUserFields(existing, incoming) {
  if (!existing || !incoming) return existing;
  mergeRelationshipFields(existing, incoming);
  if (!existing.is_blue && incoming.is_blue) existing.is_blue = true;
  const incomingBio = accountBio(incoming);
  if (incomingBio) existing.bio = incomingBio;
  if (incoming.tweet_count != null && incoming.tweet_count !== '') {
    if (existing.tweet_count == null || existing.tweet_count === '') {
      existing.tweet_count = incoming.tweet_count;
    }
  }
  if (incoming.created_at && !existing.created_at) {
    existing.created_at = incoming.created_at;
  }
  if (incoming.default_avatar) existing.default_avatar = true;
  if (incoming.followers_count != null && incoming.followers_count !== '') {
    if (existing.followers_count == null || existing.followers_count === '') {
      existing.followers_count = incoming.followers_count;
    }
  }
  if (incoming.friends_count != null && incoming.friends_count !== '') {
    if (existing.friends_count == null || existing.friends_count === '') {
      existing.friends_count = incoming.friends_count;
    }
  }
  if (incoming.display_name && !existing.display_name) {
    existing.display_name = incoming.display_name;
  }
  if (incoming.last_active_ms != null && existing.last_active_ms == null) {
    existing.last_active_ms = incoming.last_active_ms;
  }
  return existing;
}

function normalizeArchiveOwner(username) {
  return String(username || '').toLowerCase().replace(/^@+/, '');
}

function pickEnrichableFields(user) {
  if (!user?.username) return null;

  const fields = { username: user.username };
  let hasData = false;

  if (user.last_active_ms != null) {
    fields.last_active_ms = user.last_active_ms;
    hasData = true;
  }
  const bio = accountBio(user);
  if (bio) {
    fields.bio = bio;
    hasData = true;
  }
  if (user.is_blue) {
    fields.is_blue = true;
    hasData = true;
  }
  if (user.tweet_count != null && user.tweet_count !== '') {
    fields.tweet_count = user.tweet_count;
    hasData = true;
  }
  if (user.created_at) {
    fields.created_at = user.created_at;
    hasData = true;
  }
  if (user.default_avatar) {
    fields.default_avatar = true;
    hasData = true;
  }
  if (user.followers_count != null && user.followers_count !== '') {
    fields.followers_count = user.followers_count;
    hasData = true;
  }
  if (user.friends_count != null && user.friends_count !== '') {
    fields.friends_count = user.friends_count;
    hasData = true;
  }
  if (user.display_name) {
    fields.display_name = user.display_name;
    hasData = true;
  }
  if (user.you_follow != null) {
    fields.you_follow = user.you_follow;
    hasData = true;
  }
  if (user.follows_you != null) {
    fields.follows_you = user.follows_you;
    hasData = true;
  }

  return hasData ? fields : null;
}

async function ensureEnrichArchiveLoaded() {
  if (enrichArchiveStore) return enrichArchiveStore;

  try {
    const res = await chrome.storage.local.get(XC_ENRICH_ARCHIVE_KEY);
    enrichArchiveStore = res[XC_ENRICH_ARCHIVE_KEY] || { version: XC_ENRICH_ARCHIVE_VERSION, accounts: {} };
    if (!enrichArchiveStore.accounts) enrichArchiveStore.accounts = {};
  } catch (error) {
    enrichArchiveStore = { version: XC_ENRICH_ARCHIVE_VERSION, accounts: {} };
  }

  return enrichArchiveStore;
}

function scheduleEnrichArchiveSave(force = false) {
  if (force) {
    clearTimeout(enrichArchiveSaveTimer);
    enrichArchiveSaveTimer = null;
    if (!enrichArchiveStore) return;
    chrome.storage.local.set({ [XC_ENRICH_ARCHIVE_KEY]: enrichArchiveStore }).catch(() => {});
    return;
  }

  clearTimeout(enrichArchiveSaveTimer);
  enrichArchiveSaveTimer = setTimeout(() => {
    enrichArchiveSaveTimer = null;
    if (!enrichArchiveStore) return;
    chrome.storage.local.set({ [XC_ENRICH_ARCHIVE_KEY]: enrichArchiveStore }).catch(() => {});
  }, 500);
}

function getArchivedEnrichment(type, handle) {
  if (!enrichArchiveStore || !jobState.username || !handle) return null;

  const owner = normalizeArchiveOwner(jobState.username);
  const key = String(handle).toLowerCase();
  return enrichArchiveStore.accounts[owner]?.[type]?.[key] || null;
}

function rememberEnrichment(type, user) {
  if (!enrichArchiveStore || !jobState.username || !user?.username) return;

  const picked = pickEnrichableFields(user);
  if (!picked) return;

  const owner = normalizeArchiveOwner(jobState.username);
  if (!enrichArchiveStore.accounts[owner]) {
    enrichArchiveStore.accounts[owner] = { following: {}, followers: {} };
  }
  if (!enrichArchiveStore.accounts[owner][type]) {
    enrichArchiveStore.accounts[owner][type] = {};
  }

  const bucket = enrichArchiveStore.accounts[owner][type];
  const key = String(user.username).toLowerCase();
  if (!bucket[key]) {
    bucket[key] = { username: user.username };
  }
  mergeUserFields(bucket[key], picked);
  scheduleEnrichArchiveSave();
}

function releaseEnrichArchiveEntry(type, handle) {
  if (!enrichArchiveStore || !jobState.username || !handle) return false;

  const owner = normalizeArchiveOwner(jobState.username);
  const key = String(handle).toLowerCase();
  const bucket = enrichArchiveStore.accounts[owner]?.[type];
  if (!bucket?.[key]) return false;

  delete bucket[key];
  scheduleEnrichArchiveSave();
  return true;
}

function consumeArchivedEnrichmentForUser(user, type = listType) {
  if (!freshStartBackupTypes.has(type) || !user?.username) return false;

  const archived = getArchivedEnrichment(type, user.username);
  if (!archived) return false;

  const before = pickEnrichableFields(user);
  mergeUserFields(user, archived);
  releaseEnrichArchiveEntry(type, user.username);

  const after = pickEnrichableFields(user);
  return JSON.stringify(before) !== JSON.stringify(after);
}

function hydrateUserFromStoredEnrichment(user, type = listType) {
  return consumeArchivedEnrichmentForUser(user, type);
}

function syncListEnrichmentToRaw(type = listType) {
  for (const row of curList(type)) {
    const rawRow = findRawUserByHandle(type, row.username);
    if (rawRow) mergeUserFields(rawRow, row);
  }
}

function hydrateListFromStoredEnrichment(type = listType) {
  if (!freshStartBackupTypes.has(type) || !enrichArchiveStore || !jobState.username) return 0;

  let merged = 0;
  const seen = new Set();

  for (const user of curList(type)) {
    const key = (user.username || '').toLowerCase();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    if (consumeArchivedEnrichmentForUser(user, type)) merged += 1;
  }

  for (const user of curRaw(type)) {
    const key = (user.username || '').toLowerCase();
    if (!key || seen.has(key)) continue;
    if (consumeArchivedEnrichmentForUser(user, type)) merged += 1;
    seen.add(key);
  }

  syncListEnrichmentToRaw(type);
  return merged;
}

function finalizeFreshStartBackup(type = listType) {
  if (!freshStartBackupTypes.has(type)) return 0;

  const owner = normalizeArchiveOwner(jobState.username);
  const bucket = enrichArchiveStore?.accounts?.[owner]?.[type];
  const remaining = bucket ? Object.keys(bucket).length : 0;

  if (bucket) {
    enrichArchiveStore.accounts[owner][type] = {};
  }
  freshStartBackupTypes.delete(type);
  scheduleEnrichArchiveSave(true);
  return remaining;
}

function finalizeFreshStartForStop(type = listType) {
  if (freshStartBackupTypes.has(type)) {
    finalizeFreshStartBackup(type);
  }
}

async function persistFreshStartStopState() {
  finalizeFreshStartForStop(listType);
  const type = listType;
  if (!curList(type).length && !curRaw(type).length) {
    await clearListPersist(type);
    if (type === listType) {
      jobState.count = 0;
      jobState.rawCount = 0;
      jobState.savedAt = null;
    }
    return;
  }
  await persistListState(type);
}

function applyArchivedEnrichmentToList(type) {
  return hydrateListFromStoredEnrichment(type);
}

async function archiveListEnrichment(type = listType) {
  await ensureEnrichArchiveLoaded();

  const rows = curRaw(type).length ? curRaw(type) : curList(type);
  for (const row of rows) {
    rememberEnrichment(type, row);
  }

  const cache = await loadActivityCache();
  const now = Date.now();
  for (const row of rows) {
    const key = (row.username || '').toLowerCase();
    const entry = cache[key];
    if (entry?.last_active_ms && now - (entry.fetched_at || 0) < XC_ACTIVITY_CACHE_TTL_MS) {
      rememberEnrichment(type, { username: row.username, last_active_ms: entry.last_active_ms });
    }
  }

  scheduleEnrichArchiveSave(true);
  freshStartBackupTypes.add(type);
}

async function purgeEnrichArchiveForOtherUsers(activeUsername) {
  await ensureEnrichArchiveLoaded();
  const active = normalizeArchiveOwner(activeUsername);
  if (!active || !enrichArchiveStore?.accounts) return;

  let changed = false;
  for (const owner of Object.keys(enrichArchiveStore.accounts)) {
    if (owner !== active) {
      delete enrichArchiveStore.accounts[owner];
      changed = true;
    }
  }

  if (changed) scheduleEnrichArchiveSave(true);
}

function findListUserByHandle(type, username) {
  const key = (username || '').toLowerCase();
  if (!key) return null;
  return curList(type).find((row) => (row.username || '').toLowerCase() === key) || null;
}

function findRawUserByHandle(type, username) {
  const key = (username || '').toLowerCase();
  if (!key) return null;
  return curRaw(type).find((row) => (row.username || '').toLowerCase() === key) || null;
}

function mergeSnifferFieldsIntoList(users, type, ownerUsername) {
  let blueUpgraded = 0;
  const owner = (ownerUsername || '').toLowerCase();
  for (const incoming of users || []) {
    const key = (incoming.username || '').toLowerCase();
    if (!key || key === owner) continue;
    const existing = findListUserByHandle(type, key);
    if (!existing) continue;
    const wasBlue = !!existing.is_blue;
    mergeUserFields(existing, incoming);
    if (!wasBlue && existing.is_blue) blueUpgraded += 1;
    const rawRow = findRawUserByHandle(type, key);
    if (rawRow) mergeUserFields(rawRow, incoming);
  }
  return blueUpgraded;
}

async function upgradeListFromSnifferDrain(tabId, type, ownerUsername) {
  if (!tabId) return 0;
  const cfg = listCfg(type);
  try {
    const drain = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
    if (!drain?.users?.length) return 0;
    return mergeSnifferFieldsIntoList(drain.users, type, ownerUsername);
  } catch (error) {
    return 0;
  }
}

async function passiveSnifferEnrichPass(tabId, type, ownerUsername) {
  if (!tabId) return 0;
  let totalMerged = 0;
  for (let pass = 0; pass < SNIFFER_ENRICH_PASSES; pass += 1) {
    await pacedNudgeTabScroll(tabId, SNIFFER_ENRICH_SCROLL);
    await sleep(SNIFFER_ENRICH_DELAY_MS);
    totalMerged += await upgradeListFromSnifferDrain(tabId, type, ownerUsername);
  }
  return totalMerged;
}

function syncWorkingFromRaw(working, type) {
  for (const user of working) {
    const rawRow = findRawUserByHandle(type, user.username);
    if (rawRow) mergeUserFields(user, rawRow);
    consumeArchivedEnrichmentForUser(user, type);
  }
  return working;
}

function syncLastActiveIntoRaw(working, type = listType) {
  let upgraded = 0;
  for (const user of working) {
    if (user.last_active_ms == null) continue;
    const rawRow = findRawUserByHandle(type, user.username);
    if (!rawRow) continue;
    if (rawRow.last_active_ms !== user.last_active_ms) {
      rawRow.last_active_ms = user.last_active_ms;
      upgraded += 1;
    }
  }
  return upgraded;
}

async function enrichSparseProfilesViaLookup(tabId, users, type, onProgress, needsFn = (u) => !hasReliableProfileForBotCheck(u)) {
  const enriched = users.map((user) => ({ ...user }));
  const needsLookup = enriched.filter(needsFn);
  if (!needsLookup.length) {
    return { users: enriched, lookedUp: 0, upgraded: 0 };
  }

  let upgraded = 0;
  let processed = 0;
  const total = needsLookup.length;

  if (tabId) {
    await xcRestPrepareSession(tabId);
  }

  let rateLimitRetries = 0;
  for (let i = 0; i < needsLookup.length; i += ENRICH_BATCH_SIZE) {
    if (activeEnrich?.cancelled) break;
    throwIfCancelled();

    const batch = needsLookup.slice(i, i + ENRICH_BATCH_SIZE);
    const handles = batch
      .map((user) => String(user.username || '').replace(/^@+/, '').trim())
      .filter(Boolean);

    try {
      const res = await xcRestUsersLookupBatch(handles, {
        tabId,
        listType: type,
        preferTabContext: true,
        tabRetries: 2,
        requireCaptured: true
      });
      throwIfCancelled();

      rateLimitRetries = 0;
      if (res?.ok && res.profilesByName) {
        for (const user of batch) {
          const key = (user.username || '').toLowerCase();
          const profile = res.profilesByName[key];
          if (!profile) continue;
          const wasReliable = hasReliableProfileForBotCheck(user);
          mergeUserFields(user, profile);
          const rawRow = findRawUserByHandle(type, key);
          if (rawRow) mergeUserFields(rawRow, profile);
          if (!wasReliable && hasReliableProfileForBotCheck(user)) upgraded += 1;
        }
      }
    } catch (error) {
      if (isCancelledError(error)) throw error;
      console.warn('[X Cleaner] REST profile lookup batch failed', error);
      if (error.status === 429) {
        rateLimitRetries += 1;
        if (rateLimitRetries > ENRICH_RATE_LIMIT_MAX_RETRIES) {
          appendDebugStatusLog({
            status: `Profile lookup rate limited — stopped after ${processed.toLocaleString()} / ${total.toLocaleString()} checked`,
            method: jobState.method || 'filter',
            reason: 'enriching'
          });
          break;
        }
        if (onProgress) onProgress({ processed, total, waiting: true });
        await sleep(XC_REST_RATE_LIMIT_BACKOFF_MS);
        if (activeEnrich?.cancelled) break;
        i -= ENRICH_BATCH_SIZE;
        continue;
      }
    }

    processed = Math.min(total, processed + batch.length);
    if (onProgress) onProgress({ processed, total, waiting: false });

    if (i + ENRICH_BATCH_SIZE < needsLookup.length) {
      if (onProgress) onProgress({ processed, total, waiting: true });
      await sleep(ENRICH_BATCH_DELAY_MS);
      if (activeEnrich?.cancelled) break;
    }
  }

  return { users: enriched, lookedUp: needsLookup.length, upgraded };
}

async function ensureReliableProfilesForBotCheck(tabId, type, working, onProgress) {
  const stats = {
    sparseBefore: working.filter((user) => !hasReliableProfileForBotCheck(user)).length,
    snifferMerged: 0,
    lookupUpgraded: 0,
    lookedUp: 0
  };

  if (tabId && stats.sparseBefore > 0) {
    stats.snifferMerged = await passiveSnifferEnrichPass(tabId, type, jobState.username);
    syncWorkingFromRaw(working, type);
  }

  const sparseAfterSniffer = working.filter((user) => !hasReliableProfileForBotCheck(user)).length;
  if (sparseAfterSniffer > 0 && tabId) {
    const result = await enrichSparseProfilesViaLookup(tabId, working, type, onProgress);
    stats.lookupUpgraded = result.upgraded;
    stats.lookedUp = result.lookedUp;
    return { users: result.users, stats };
  }

  return { users: working, stats };
}

async function ensureCoreProfileStats(tabId, type, onProgress) {
  const working = curList(type) || [];
  let sparse = working.filter((u) => !hasCoreProfileStats(u));
  if (!sparse.length || !tabId) return { lookedUp: 0, upgraded: 0 };

  // First give sniffer a chance (free data from page)
  try {
    await passiveSnifferEnrichPass(tabId, type, jobState.username);
    syncWorkingFromRaw(working, type);
  } catch (e) {}

  sparse = working.filter((u) => !hasCoreProfileStats(u));
  if (!sparse.length) return { lookedUp: 0, upgraded: 0 };

  // Batched lookup to pull friends/followers/tweet/created (the "everything" pass)
  const result = await enrichSparseProfilesViaLookup(tabId, working, type, onProgress, (u) => !hasCoreProfileStats(u));
  return { lookedUp: result.lookedUp || sparse.length, upgraded: result.upgraded || 0 };
}

async function nudgeTabListScroll(tabId, amount = 900) {
  if (!tabId) return;
  try {
    await executeOnTab(tabId, () => window.scrollBy(0, amount));
  } catch (error) {}
}

function buildSeenFromCurList(type, ownerUsername) {
  const seen = new Set();
  const owner = (ownerUsername || '').toLowerCase();
  for (const user of curList(type)) {
    const key = (user.username || '').toLowerCase();
    if (key && key !== owner) seen.add(key);
  }
  return seen;
}

function resetListForFreshFallback(type) {
  if (curList(type).length > 0) return false;
  setCurList([], type);
  setCurRaw([], type);
  return true;
}

function listResumeIsTailOnly(type, totalList) {
  const cached = curList(type).length;
  return cached > 0 && (totalList == null || cached < totalList);
}

function addNativeUsers(nativeBatch, seen, ownerUsername, type = listType) {
  let added = 0;
  const owner = (ownerUsername || '').toLowerCase();
  const cfg = listCfg(type);
  const totalList = jobState[cfg.totalKey] ?? null;

  const otherType = type === 'following' ? 'followers' : 'following';
  const otherSet = new Set((curList(otherType) || []).map(u => (u.username || '').toLowerCase()));

  for (const user of nativeBatch.users || []) {
    if (totalList != null && curList(type).length >= totalList) break;
    const key = (user.username || '').toLowerCase();
    if (!key || key === owner) continue;
    if (type === 'following' && !xcIsVerifiedFollowingListUser(user)) {
      continue;
    }
    if (seen.has(key)) {
      const existing = curList(type).find((row) => (row.username || '').toLowerCase() === key);
      mergeUserFields(existing, user);
      consumeArchivedEnrichmentForUser(existing, type);
      crossPopulateMutualFlags(existing, type, otherSet);
      continue;
    }
    seen.add(key);
    const row = { ...user };
    consumeArchivedEnrichmentForUser(row, type);
    curList(type).push(row);
    crossPopulateMutualFlags(row, type, otherSet);
    added++;
  }

  return added;
}

function crossPopulateMutualFlags(row, type, otherSet) {
  if (!row || !row.username) return;
  const key = (row.username || '').toLowerCase();
  let inOther = false;
  const otherType = type === 'following' ? 'followers' : 'following';
  if (otherSet && otherSet.has(key)) {
    inOther = true;
  } else if (!otherSet) {
    const otherList = curList(otherType) || [];
    inOther = otherList.some(u => (u.username || '').toLowerCase() === key);
  }

  if (type === 'following') {
    if (row.you_follow == null) row.you_follow = true;
    if (inOther) {
      row.follows_you = true;
      const otherLive = (curList(otherType) || []).find(u => (u.username || '').toLowerCase() === key);
      if (otherLive) {
        otherLive.you_follow = true;
        otherLive.follows_you = true;
      }
      const otherRaw = findRawUserByHandle(otherType, key);
      if (otherRaw) {
        otherRaw.you_follow = true;
        otherRaw.follows_you = true;
        if (otherRaw.last_active_ms != null && row.last_active_ms == null) {
          row.last_active_ms = otherRaw.last_active_ms;
        }
      }
    } else {
      const otherLen = (curList(otherType) || []).length;
      const otherTotal = jobState[listCfg(otherType).totalKey];
      const otherComplete = (otherTotal != null && otherLen >= otherTotal) || (!jobState.isScraping && otherLen > 0);
      if (otherComplete && row.follows_you == null) {
        row.follows_you = false;
      }
    }
  } else {
    if (row.follows_you == null) row.follows_you = true;
    if (inOther) {
      row.you_follow = true;
      const otherLive = (curList(otherType) || []).find(u => (u.username || '').toLowerCase() === key);
      if (otherLive) {
        otherLive.follows_you = true;
        otherLive.you_follow = true;
      }
      const otherRaw = findRawUserByHandle(otherType, key);
      if (otherRaw) {
        otherRaw.follows_you = true;
        otherRaw.you_follow = true;
        if (otherRaw.last_active_ms != null && row.last_active_ms == null) {
          row.last_active_ms = otherRaw.last_active_ms;
        }
      }
    } else {
      const otherLen = (curList(otherType) || []).length;
      const otherTotal = jobState[listCfg(otherType).totalKey];
      const otherComplete = (otherTotal != null && otherLen >= otherTotal) || (!jobState.isScraping && otherLen > 0);
      if (otherComplete && row.you_follow == null) {
        row.you_follow = false;
      }
    }
  }
}

async function scrapeProfileStats(tabId, handle) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (screenName) => {
      const parseCountText = (text) => {
        const cleaned = (text || '').replace(/,/g, '').trim();
        const suffix = cleaned.match(/([\d.]+)\s*([KkMm])/);
        if (suffix) {
          const amount = parseFloat(suffix[1]);
          const multiplier = suffix[2].toLowerCase() === 'm' ? 1000000 : 1000;
          return Math.round(amount * multiplier);
        }

        const digits = cleaned.match(/(\d+)/);
        return digits ? parseInt(digits[1], 10) : null;
      };

      const sn = String(screenName || '').replace(/^@+/, '').toLowerCase();
      const html =
        document.documentElement.innerHTML +
        ' ' +
        Array.from(document.getElementsByTagName('script'))
          .map((script) => script.textContent || '')
          .join(' ');

      let following = null;
      let followers = null;
      let userId = null;

      const followingLink = document.querySelector(
        'a[href$="/following"], a[href*="/following"]'
      );
      if (followingLink) {
        following = parseCountText(followingLink.textContent || followingLink.innerText || '');
      }

      for (const link of document.querySelectorAll('a[href*="/followers"]')) {
        const href = (link.getAttribute('href') || '').toLowerCase();
        if (href.includes('verified_followers')) continue;
        if (href.endsWith('/followers') || /\/followers(?:[/?]|$)/.test(href)) {
          followers = parseCountText(link.textContent || link.innerText || '');
          break;
        }
      }

      if (following === null) {
        const friendsMatch = html.match(/"friends_count":(\d+)/i);
        if (friendsMatch) following = parseInt(friendsMatch[1], 10);
      }

      if (following === null) {
        const followingMatch = html.match(/"following_count":(\d+)/i);
        if (followingMatch) following = parseInt(followingMatch[1], 10);
      }

      if (followers === null) {
        const followersMatch = html.match(/"followers_count":(\d+)/i);
        if (followersMatch) followers = parseInt(followersMatch[1], 10);
      }

      const patterns = [
        new RegExp(`"screen_name":"${sn}"[^}]{0,1200}?"rest_id":"(\\d+)"`, 'i'),
        new RegExp(`"rest_id":"(\\d+)"[^}]{0,1200}?"screen_name":"${sn}"`, 'i'),
        new RegExp(`"screen_name":"${sn}"[^}]{0,1200}?"id":"(\\d+)"`, 'i')
      ];

      for (const pattern of patterns) {
        const match = html.match(pattern);
        if (match) {
          userId = match[1];
          break;
        }
      }

      if (!userId) {
        const idx = html.toLowerCase().indexOf(`"screen_name":"${sn}"`);
        if (idx >= 0) {
          const windowText = html.slice(idx, idx + 1200);
          const nearMatch = windowText.match(/"rest_id":"?(\d{6,})"?/i);
          if (nearMatch) userId = nearMatch[1];
        }
      }

      return {
        username: screenName,
        totalFollowing: following,
        totalFollowers: followers,
        userId
      };
    },
    args: [handle]
  });

  return results?.[0]?.result || {
    username: handle,
    totalFollowing: null,
    totalFollowers: null,
    userId: null
  };
}

async function scrapeListPageTotal(tabId, type) {
  const cfg = listCfg(type);
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (listPath, countKey, pathPattern) => {
      const parseCountText = (text) => {
        const cleaned = (text || '').replace(/,/g, '').trim();
        const suffix = cleaned.match(/([\d.]+)\s*([KkMm])/);
        if (suffix) {
          const amount = parseFloat(suffix[1]);
          const multiplier = suffix[2].toLowerCase() === 'm' ? 1000000 : 1000;
          return Math.round(amount * multiplier);
        }
        const digits = cleaned.match(/(\d+)/);
        return digits ? parseInt(digits[1], 10) : null;
      };

      const headingPattern = pathPattern || listPath;
      const headings = document.querySelectorAll('h2, [role="heading"], [data-testid="primaryColumn"] span');
      for (const node of headings) {
        const text = node.textContent || '';
        if (!new RegExp(headingPattern, 'i').test(text)) continue;
        const count = parseCountText(text);
        if (count != null) return count;
      }

      const html =
        document.documentElement.innerHTML +
        ' ' +
        Array.from(document.getElementsByTagName('script'))
          .map((script) => script.textContent || '')
          .join(' ');
      const match = html.match(new RegExp(`"${countKey}":(\\d+)`, 'i'));
      return match ? parseInt(match[1], 10) : null;
    },
    args: [
      cfg.path,
      cfg.totalKey === 'totalFollowers' ? 'followers_count' : 'friends_count',
      type === 'followers' ? 'followers|verified' : cfg.path
    ]
  });

  const value = results?.[0]?.result;
  return Number.isFinite(value) ? value : null;
}

function escapeCsvField(value) {
  const str = String(value ?? '').replace(/"/g, '""');
  return `"${str.replace(/\r?\n/g, ' ')}"`;
}

function parseAccountCreatedAt(value) {
  if (!value) return null;
  const ts = Date.parse(value);
  return Number.isNaN(ts) ? null : ts;
}

function normalizeFilterMonths(value, fallback = DEFAULT_INACTIVE_MONTHS) {
  const months = Math.round(Number(value));
  if (!Number.isFinite(months)) return fallback;
  return Math.min(MAX_FILTER_MONTHS, Math.max(MIN_FILTER_MONTHS, months));
}

function normalizeInactiveMonths(value) {
  return normalizeFilterMonths(value, DEFAULT_INACTIVE_MONTHS);
}

function inactiveFilterCutoffMs(months = DEFAULT_INACTIVE_MONTHS) {
  const cutoff = new Date();
  cutoff.setMonth(cutoff.getMonth() - months);
  return cutoff.getTime();
}

function isInactiveAccount(lastActiveMs, months = DEFAULT_INACTIVE_MONTHS) {
  if (lastActiveMs == null) return false;
  return lastActiveMs < inactiveFilterCutoffMs(months);
}

function accountCreatedMs(user) {
  return parseAccountCreatedAt(user?.created_at);
}

function isAccountTooYoungForInactiveFilter(user, months) {
  // Age threshold for pre-qual must come from the UI input (the inactiveMonths value),
  // not hardcoded to DEFAULT_INACTIVE_MONTHS (6).
  if (months == null) months = DEFAULT_INACTIVE_MONTHS;
  const createdMs = accountCreatedMs(user);
  if (createdMs == null) return false;
  return createdMs >= inactiveFilterCutoffMs(months);
}

function hasZeroTweetCount(user) {
  const count = user?.tweet_count;
  if (count == null || count === '') return false;
  const n = Number(count);
  return Number.isFinite(n) && n <= 0;
}

function partitionInactiveFilterCandidates(users, months, cache, now, type = listType) {
  const cutoffMs = inactiveFilterCutoffMs(months);
  const tooYoung = [];
  const resolvedInactive = [];
  const resolvedActive = [];
  const needsLookup = [];

  for (const user of users) {
    if (isAccountTooYoungForInactiveFilter(user, months)) {
      tooYoung.push(user);
      continue;
    }

    hydrateLastActiveFromStoredSources(user, type, cache, now);

    if (user.last_active_ms != null) {
      if (user.last_active_ms < cutoffMs) resolvedInactive.push(user);
      else resolvedActive.push(user);
      continue;
    }

    const createdMs = accountCreatedMs(user);
    if (hasZeroTweetCount(user) && (createdMs == null || createdMs < cutoffMs)) {
      resolvedInactive.push(user);
      continue;
    }

    needsLookup.push(user);
  }

  return { tooYoung, resolvedInactive, resolvedActive, needsLookup, cutoffMs };
}

function classifyInactiveAfterLookup(user, cutoffMs) {
  if (user.last_active_ms != null) {
    return user.last_active_ms < cutoffMs;
  }
  // If we couldn't obtain a last tweet date, fall back to account age for old accounts.
  // This helps detect inactive accounts when the lookup didn't return status.created_at
  // (common for some accounts, protected, low activity, etc.).
  const createdMs = accountCreatedMs(user);
  if (createdMs != null && createdMs < cutoffMs) {
    // Old account: treat as inactive if zero or very low tweets, or if we simply have no recent activity signal.
    if (hasZeroTweetCount(user) || (user.tweet_count != null && Number(user.tweet_count) <= 5)) {
      return true;
    }
    // Conservative: if old account and no last tweet data at all, consider it a candidate
    // (user can adjust months or review manually).
    return true;
  }
  return false;
}

function accountBio(user) {
  return String(user?.bio ?? user?.description ?? '').trim();
}

function hasReliableProfileForBotCheck(user) {
  const bio = accountBio(user);
  if (bio) return true;
  const hasTweetCount = user?.tweet_count != null && user.tweet_count !== '';
  const hasFollowers = user?.followers_count != null && user.followers_count !== '';
  const hasCreated = !!user?.created_at;
  if (hasTweetCount && hasCreated) return true;
  if (hasFollowers && hasCreated && (user?.display_name || user?.friends_count != null)) {
    return true;
  }
  return false;
}

function hasCoreProfileStats(user) {
  if (!user) return false;
  const hasF = user.friends_count != null && user.friends_count !== '';
  const hasFl = user.followers_count != null && user.followers_count !== '';
  const hasT = user.tweet_count != null && user.tweet_count !== '';
  const hasC = !!user.created_at;
  return hasF || hasFl || hasT || hasC;
}

function hasNoBio(user) {
  // REST friends/followers list rows omit description — empty bio there is not a bot signal.
  if (!hasReliableProfileForBotCheck(user)) return false;
  return !accountBio(user);
}

function isLowTweetAccount(user, maxTweets = BOT_CHECK_TWEET_MAX) {
  const count = user?.tweet_count;
  if (count == null || count === '') return false;
  const n = Number(count);
  return Number.isFinite(n) && n < maxTweets;
}

function isYoungAccount(createdAt, days = BOT_CHECK_ACCOUNT_MAX_DAYS) {
  const ts = parseAccountCreatedAt(createdAt);
  if (ts == null) return false;
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  return ts > cutoff;
}

function hasTrailingDigitUsername(user, minTrailingDigits = BOT_CHECK_USERNAME_TRAILING_DIGITS) {
  const handle = String(user?.username || '').replace(/^@+/, '').trim();
  if (!handle) return false;
  const trailingDigits = handle.match(/\d+$/);
  return !!(trailingDigits && trailingDigits[0].length > minTrailingDigits);
}

function hasHighFollowerRatio(user, ratio = BOT_CHECK_FOLLOWERS_RATIO) {
  const followers = user?.followers_count;
  const following = user?.friends_count;
  if (followers == null || followers === '' || following == null || following === '') {
    return false;
  }
  const followerN = Number(followers);
  const followingN = Number(following);
  if (!Number.isFinite(followerN) || !Number.isFinite(followingN)) return false;
  if (followingN < 0 || followerN < 0) return false;
  return followerN > ratio * followingN;
}

function isPotentialBot(user) {
  if (!user) return false;
  if (user.default_avatar) return true;
  if (hasNoBio(user)) return true;
  if (isLowTweetAccount(user)) return true;
  if (isYoungAccount(user.created_at)) return true;
  if (hasTrailingDigitUsername(user)) return true;
  if (hasHighFollowerRatio(user)) return true;
  return false;
}

function mutualOtherListType(type) {
  return type === 'followers' ? 'following' : 'followers';
}

function buildHandleSetForList(type) {
  const users = usersForMutuals(type);
  return new Set(
    users.map((user) => (user.username || '').toLowerCase()).filter(Boolean)
  );
}

function buildMutualFilterContext(type) {
  const otherType = mutualOtherListType(type);
  return {
    type,
    otherType,
    followingSet: buildHandleSetForList('following'),
    followersSet: buildHandleSetForList('followers'),
    otherListCount: usersForMutuals(otherType).length
  };
}

function mutualDetectionAvailable(type, ctx) {
  if (type === 'followers') {
    if (ctx.followingSet.size > 0) return true;
    return usersForMutuals('followers').some(
      (user) => user.you_follow === true || user.following === true
    );
  }
  if (ctx.followersSet.size > 0) return true;
  return usersForMutuals('following').some((user) => user.follows_you === true);
}

function isMutualAccount(user, type, ctx) {
  const key = (user.username || '').toLowerCase();
  if (!key) return false;

  if (type === 'followers') {
    if (ctx.followingSet.size > 0) return ctx.followingSet.has(key);
    return user.you_follow === true || user.following === true;
  }

  if (ctx.followersSet.size > 0) return ctx.followersSet.has(key);
  return user.follows_you === true;
}

function refreshMutualFlagsFromOtherList(type) {
  const otherType = mutualOtherListType(type);
  const otherSet = buildHandleSetForList(otherType);
  if (!otherSet.size) return { upgraded: 0, otherCount: 0 };

  const flagKey = type === 'followers' ? 'you_follow' : 'follows_you';
  let upgraded = 0;
  const seen = new Set();

  // Build map from other list for hydration data transfer (e.g. last_active for mutuals)
  const otherUsers = usersForMutuals(otherType);
  const otherMap = new Map();
  for (const ou of otherUsers) {
    const k = (ou.username || '').toLowerCase();
    if (k) otherMap.set(k, ou);
  }

  for (const user of curRaw(type)) {
    const key = (user.username || '').toLowerCase();
    if (!key || !otherSet.has(key) || seen.has(key)) continue;
    seen.add(key);
    if (user[flagKey] !== true) {
      user[flagKey] = true;
      upgraded += 1;
    }
    const live = findListUserByHandle(type, key);
    if (live && live[flagKey] !== true) live[flagKey] = true;

    // Transfer any last_active_ms hydration from mutual in the other list to this list (esp. to followers)
    const otherUser = otherMap.get(key);
    if (otherUser && otherUser.last_active_ms != null && user.last_active_ms == null) {
      user.last_active_ms = otherUser.last_active_ms;
      upgraded += 1;
      if (live && live.last_active_ms == null) live.last_active_ms = otherUser.last_active_ms;
      const rawRow = findRawUserByHandle(type, key);
      if (rawRow && rawRow.last_active_ms == null) rawRow.last_active_ms = otherUser.last_active_ms;
    }
  }

  return { upgraded, otherCount: otherSet.size };
}

function excludeMutuals(users, type, ctx) {
  return users.filter((user) => !isMutualAccount(user, type, ctx));
}

function isYouFollowingAccount(user, ctx) {
  return isMutualAccount(user, 'followers', ctx);
}

function fullListForType(type = listType) {
  return curRaw(type).length ? curRaw(type).slice() : curList(type).slice();
}

function formatLastActiveField(ms) {
  if (!ms) return '';
  return new Date(ms).toISOString();
}

async function loadActivityCache() {
  const res = await chrome.storage.local.get(XC_ACTIVITY_CACHE_KEY);
  return res[XC_ACTIVITY_CACHE_KEY] || {};
}

async function saveActivityCache(cache) {
  await chrome.storage.local.set({ [XC_ACTIVITY_CACHE_KEY]: cache });
}

async function getLastTweetTimeFromTimeline(screenName, options = {}) {
  const handle = String(screenName || '').replace(/^@+/, '').trim();
  if (!handle) return null;
  const query = new URLSearchParams({
    screen_name: handle,
    count: '1',
    include_rts: 'false',
    trim_user: 'true'
  });
  const url = `${XC_REST_API_ORIGIN}/statuses/user_timeline.json?${query.toString()}`;
  try {
    const body = await xcRestMakeApiRequest(url, 'GET', null, options);
    if (Array.isArray(body) && body.length > 0) {
      const created = body[0] && body[0].created_at;
      if (created) {
        const ts = Date.parse(created);
        if (!isNaN(ts)) return ts;
      }
    }
  } catch (e) {
    // ignore, keep as null
  }
  return null;
}

function hasStoredLastActive(user, type = listType, cache = {}, now = Date.now()) {
  if (user.last_active_ms != null) return true;
  const key = (user.username || '').toLowerCase();
  if (!key) return false;
  if (freshStartBackupTypes.has(type)) {
    const archived = getArchivedEnrichment(type, key);
    if (archived?.last_active_ms != null) return true;
  }
  const entry = cache[key];
  if (entry && typeof entry === 'object' && entry.fetched_at != null &&
      (now - (entry.fetched_at || 0) < XC_ACTIVITY_CACHE_TTL_MS)) {
    // Only skip re-lookup if we have a positive date, or a previous full attempt (lookup + timeline)
    // This lets old cache nulls (pre-timeline) be re-attempted with current logic.
    if (entry.last_active_ms != null || entry.full_attempt === true) {
      return true;
    }
  }
  return false;
}

function hydrateLastActiveFromStoredSources(user, type = listType, cache = {}, now = Date.now()) {
  if (user.last_active_ms != null) return true;
  const key = (user.username || '').toLowerCase();
  if (!key) return false;

  if (freshStartBackupTypes.has(type)) {
    const archived = getArchivedEnrichment(type, key);
    if (archived?.last_active_ms != null) {
      user.last_active_ms = archived.last_active_ms;
      return true;
    }
  }

  const entry = cache[key];
  if (entry && typeof entry === 'object' && entry.fetched_at != null &&
      (now - (entry.fetched_at || 0) < XC_ACTIVITY_CACHE_TTL_MS)) {
    user.last_active_ms = entry.last_active_ms ?? null;
    // Only treat as stored/skip if we have positive date or full previous attempt.
    // Old nulls (no full_attempt flag) will not skip, allowing timeline fallback etc.
    if (entry.last_active_ms != null || entry.full_attempt === true) {
      return true;
    }
    return false;
  }

  return false;
}

function countLastActiveLookupNeeded(users, cache, now = Date.now(), type = listType) {
  let needed = 0;
  for (const user of users) {
    if (hasStoredLastActive(user, type, cache, now)) continue;
    needed += 1;
  }
  return needed;
}

async function enrichLastActiveForUsers(tabId, users, type = listType, progressOrOptions) {
  let onProgress = null;
  let batchSize = ENRICH_BATCH_SIZE;
  let batchDelayMs = ENRICH_BATCH_DELAY_MS;

  if (typeof type === 'function') {
    onProgress = type;
    type = listType;
  } else if (typeof progressOrOptions === 'function') {
    onProgress = progressOrOptions;
  } else if (progressOrOptions && typeof progressOrOptions === 'object') {
    onProgress = progressOrOptions.onProgress;
    batchSize = progressOrOptions.batchSize || batchSize;
    batchDelayMs = progressOrOptions.batchDelayMs || batchDelayMs;
  }

  const cache = await loadActivityCache();
  const now = Date.now();
  const enriched = users.map((user) => ({ ...user }));

  const needsLookup = [];
  for (const user of enriched) {
    if (hydrateLastActiveFromStoredSources(user, type, cache, now)) continue;
    needsLookup.push(user);
  }

  let processed = enriched.length - needsLookup.length;
  const total = enriched.length;
  if (onProgress) onProgress({ processed, total, fromCache: needsLookup.length === 0 });

  if (tabId && needsLookup.length > 0) {
    await xcRestWaitForBearer(tabId, { maxMs: ENRICH_BEARER_WAIT_MS });
    await xcRestPrepareSession(tabId);
  }

  let rateLimitRetries = 0;
  for (let i = 0; i < needsLookup.length; i += batchSize) {
    if (activeEnrich?.cancelled) break;
    throwIfCancelled();

    const batch = needsLookup.slice(i, i + batchSize);
    const handles = batch
      .map((user) => String(user.username || '').replace(/^@+/, '').trim())
      .filter(Boolean);

    let lookupRes = null;
    try {
      lookupRes = await xcRestUsersLookupBatch(handles, {
        tabId,
        listType: type,
        preferTabContext: true,
        tabRetries: 2,
        requireCaptured: true
      });
      throwIfCancelled();

      rateLimitRetries = 0;
      if (lookupRes?.ok) {
        const la = lookupRes.lastActive || {};
        for (const h of handles) {
          const sk = h.toLowerCase();
          const ts = la[sk];
          cache[sk] = {
            last_active_ms: (ts != null ? ts : null),
            fetched_at: now
          };
        }
      }
      if (lookupRes?.ok && lookupRes.profilesByName) {
        for (const user of batch) {
          const key = (user.username || '').toLowerCase();
          const profile = lookupRes.profilesByName[key];
          if (!profile) continue;
          mergeUserFields(user, profile);
          const rawRow = findRawUserByHandle(type, key);
          if (rawRow) mergeUserFields(rawRow, profile);
        }
      }
      if (lookupRes?.ok && lookupRes.blueByName) {
        for (const user of enriched) {
          const key = (user.username || '').toLowerCase();
          if (key && lookupRes.blueByName[key]) user.is_blue = true;
        }
        for (const [sn, isBlue] of Object.entries(lookupRes.blueByName)) {
          if (!isBlue) continue;
          const rawRow = findRawUserByHandle(type, sn);
          if (rawRow) rawRow.is_blue = true;
        }
      }
    } catch (error) {
      if (isCancelledError(error)) throw error;
      console.warn('[X Cleaner] REST users/lookup batch failed', error);
      if (error.status === 429) {
        rateLimitRetries += 1;
        if (rateLimitRetries > ENRICH_RATE_LIMIT_MAX_RETRIES) {
          appendDebugStatusLog({
            status: `Last-tweet lookup rate limited — stopped after ${processed.toLocaleString()} / ${total.toLocaleString()} checked`,
            method: jobState.method || 'filter',
            reason: 'enriching'
          });
          break;
        }
        if (onProgress) onProgress({ processed, total, waiting: true });
        await sleep(XC_REST_RATE_LIMIT_BACKOFF_MS);
        if (activeEnrich?.cancelled) break;
        i -= batchSize;
        continue;
      }
    }

    for (const user of batch) {
      const key = (user.username || '').toLowerCase();
      const entry = cache[key];
      user.last_active_ms = entry?.last_active_ms ?? null;
    }

    // Fallback to user timeline if the lookup didn't provide a last tweet date.
    // This can get dates for accounts where /users/lookup omits the status.
    for (const user of batch) {
      if (user.last_active_ms != null) continue;
      const ts = await getLastTweetTimeFromTimeline(user.username, { tabId });
      if (ts) {
        user.last_active_ms = ts;
        const k = (user.username || '').toLowerCase();
        cache[k] = { last_active_ms: ts, fetched_at: now, full_attempt: true };
      }
    }

    // Ensure we record a cache entry for every account we queried in this batch
    // (even if no date from lookup or fallback). This prevents re-queries on re-runs
    // for "no tweet date" accounts.
    for (const user of batch) {
      const k = (user.username || '').toLowerCase();
      if (!cache[k]) {
        cache[k] = { last_active_ms: null, fetched_at: now, full_attempt: true };
      } else if (cache[k] && !cache[k].full_attempt) {
        // upgrade old entry to mark as full attempt
        cache[k].full_attempt = true;
      }
    }

    processed = Math.min(total, processed + batch.length);
    if (onProgress) onProgress({ processed, total, waiting: false });

    if (i + batchSize < needsLookup.length) {
      if (onProgress) onProgress({ processed, total, waiting: true });
      await sleep(batchDelayMs);
      if (activeEnrich?.cancelled) break;
    }
  }

  await saveActivityCache(cache);

  for (const user of enriched) {
    if (user.last_active_ms != null) continue;
    const key = (user.username || '').toLowerCase();
    const entry = cache[key];
    user.last_active_ms = entry?.last_active_ms ?? null;
  }

  return enriched;
}

function applyRemoveBlueFilter(source) {
  return source.filter((user) => !user.is_blue);
}

function syncBlueFlagsIntoRaw(type) {
  let upgraded = 0;
  for (const rawUser of curRaw(type)) {
    const live = findListUserByHandle(type, rawUser.username);
    if (live?.is_blue && !rawUser.is_blue) {
      rawUser.is_blue = true;
      upgraded += 1;
    }
  }
  return upgraded;
}

async function refreshBlueFlagsFromSniffer(type) {
  syncBlueFlagsIntoRaw(type);
  if (!(await ensureJobTabId())) return 0;
  await pacedNudgeTabScroll(jobTabId, 900);
  await sleep(450, { cancellable: true });
  return upgradeListFromSnifferDrain(jobTabId, type, jobState.username);
}

function snapshotListRaw(type = listType) {
  hydrateListFromStoredEnrichment(type);
  setCurRaw(curList(type).slice(), type);
  jobState.rawCount = curRaw(type).length;
  schedulePersist(true, type);
  finalizeFreshStartBackup(type);
}

function serializeJobStateForPersist(type = listType) {
  return {
    username: jobState.username,
    listType: type,
    totalFollowing: jobState.totalFollowing,
    totalFollowers: jobState.totalFollowers,
    count: curList(type).length,
    rawCount: curRaw(type).length || curList(type).length,
    isScraping: false,
    isEnriching: false,
    reason: jobState.reason,
    method: jobState.method,
    filterRemoved: jobState.filterRemoved ?? 0,
    appliedFilters: Array.isArray(jobState.appliedFilters) ? jobState.appliedFilters.slice() : [],
    status: jobState.status || null
  };
}

async function persistListState(type = listType) {
  const guardAtStart = persistGuard[type];
  const cfg = listCfg(type);
  const fullList = fullListForType(type);
  const storageKey = persistStorageKey(type, jobState.username);

  if (!fullList.length) {
    if (guardAtStart !== persistGuard[type]) return;
    await chrome.storage.local.remove(storageKey);
    if (storageKey !== cfg.persistKey) {
      await chrome.storage.local.remove(cfg.persistKey);
    }
    return;
  }

  const payload = {
    version: XC_PERSIST_VERSION,
    listType: type,
    savedAt: new Date().toISOString(),
    accountList: fullList,
    accountListRaw: fullList,
    jobState: {
      ...serializeJobStateForPersist(type),
      username: jobState.username || null,
      count: curList(type).length,
      rawCount: fullList.length
    }
  };

  try {
    if (guardAtStart !== persistGuard[type]) return;
    await chrome.storage.local.set({ [storageKey]: payload });
    if (storageKey !== cfg.persistKey) {
      await chrome.storage.local.remove(cfg.persistKey);
    }
    lastPersistedCounts[type] = fullList.length;
    if (type === listType) {
      jobState.savedAt = payload.savedAt;
    }
  } catch (error) {
    console.warn(`[X Cleaner] persist failed (${type})`, error);
  }
}

function schedulePersist(force = false, type = listType) {
  if (!curList(type).length && !curRaw(type).length) return;

  if (force) {
    clearTimeout(persistDebounceTimers[type]);
    persistDebounceTimers[type] = null;
    persistListState(type).catch(() => {});
    return;
  }

  if (jobState.isScraping && type === listType) {
    const delta = curList(type).length - lastPersistedCounts[type];
    if (delta < XC_PERSIST_COLLECT_INTERVAL) {
      clearTimeout(persistDebounceTimers[type]);
      persistDebounceTimers[type] = setTimeout(() => {
        persistListState(type).catch(() => {});
      }, XC_PERSIST_DEBOUNCE_MS);
      return;
    }
  }

  clearTimeout(persistDebounceTimers[type]);
  persistDebounceTimers[type] = setTimeout(() => {
    persistListState(type).catch(() => {});
  }, 500);
}

async function clearListPersist(type = listType) {
  const cfg = listCfg(type);
  const storageKey = persistStorageKey(type, jobState.username);
  persistGuard[type] += 1;
  clearTimeout(persistDebounceTimers[type]);
  persistDebounceTimers[type] = null;
  lastPersistedCounts[type] = 0;
  restoredTypes[type] = false;
  if (type === listType) {
    jobState.savedAt = null;
  }
  await chrome.storage.local.remove(storageKey);
  if (storageKey !== cfg.persistKey) {
    await chrome.storage.local.remove(cfg.persistKey);
  }
}

async function cleanupLegacyGlobalPersist(activeUsername) {
  const activeUser = normalizeAccountHandle(activeUsername);
  if (!activeUser) return;

  await purgeEnrichArchiveForOtherUsers(activeUser);

  for (const type of LIST_TYPES) {
    const cfg = listCfg(type);
    const res = await chrome.storage.local.get(cfg.persistKey);
    const data = res[cfg.persistKey];
    if (!data) continue;

    const savedUser = normalizeAccountHandle(data?.jobState?.username);
    if (savedUser === activeUser) {
      const accountKey = persistStorageKey(type, activeUser);
      try {
        await chrome.storage.local.set({ [accountKey]: data });
        await chrome.storage.local.remove(cfg.persistKey);
      } catch (error) {}
      continue;
    }

    if (savedUser && savedUser !== activeUser) {
      await chrome.storage.local.remove(cfg.persistKey);
      console.log(`[X Cleaner] Removed legacy cached ${cfg.label.toLowerCase()} for @${savedUser} (active @${activeUser})`);
    }
  }
}

function clearInMemoryLists() {
  for (const type of LIST_TYPES) {
    setCurList([], type);
    setCurRaw([], type);
    restoredTypes[type] = false;
    clearTimeout(persistDebounceTimers[type]);
    persistDebounceTimers[type] = null;
    lastPersistedCounts[type] = 0;
  }
}

async function applyAccountSwitch(detected) {
  cancelActiveWork();
  clearInMemoryLists();
  jobState = {
    ...jobState,
    username: detected,
    count: 0,
    rawCount: 0,
    totalFollowing: null,
    totalFollowers: null,
    savedAt: null,
    reason: null,
    filterRemoved: 0,
    appliedFilters: [],
    status: null
  };
  activeFetch = null;
  activeEnrich = null;
  await restoreAllListState();
}

async function alignAccountForJob(detected) {
  const next = String(detected || '').replace(/^@+/, '');
  if (!next) return;

  const prev = normalizeAccountHandle(jobState.username);
  const nextLower = normalizeAccountHandle(next);

  if (prev && prev !== nextLower) {
    cancelActiveWork();
    activeFetch = null;
    activeEnrich = null;
    await applyAccountSwitch(next);
    return;
  }

  jobState.username = next;
  await cleanupLegacyGlobalPersist(next);
  if (!curList('following').length && !curList('followers').length) {
    await restoreAllListState();
  }
}

async function restoreListState(type, options = {}) {
  if (curList(type).length || activeFetch?.running) return false;
  if (freshStartBackupTypes.has(type)) return false;

  const cfg = listCfg(type);

  try {
    const activeUser = normalizeAccountHandle(options.username || jobState.username);
    const { data } = await readPersistData(type, activeUser);
    if (!data) return false;

    const raw = data.accountListRaw || data.followingListRaw || data?.accountList || data?.followingList;
    if (!raw?.length) return false;

    const savedUser = normalizeAccountHandle(data.jobState?.username);
    if (activeUser && savedUser && activeUser !== savedUser) {
      return false;
    }
    if (!jobState.username && savedUser) {
      jobState.username = data.jobState?.username || savedUser;
    }

    const fullList = raw.slice();
    setCurRaw(fullList, type);
    setCurList(fullList, type);
    if (type === listType) {
      jobState = {
        ...jobState,
        ...data.jobState,
        listType: type,
        isScraping: false,
        isEnriching: false,
        count: curList(type).length,
        rawCount: curRaw(type).length
      };
      jobState.savedAt = data.savedAt || null;
    }

    restoredTypes[type] = true;

    const tab = await findLastActiveXTab();
    if (tab?.id) jobTabId = tab.id;

    console.log(
      `[X Cleaner] Restored ${curRaw(type).length.toLocaleString()} ${cfg.label.toLowerCase()} (full cache) from storage`
    );
    return true;
  } catch (error) {
    console.warn(`[X Cleaner] restore failed (${type})`, error);
    return false;
  }
}

async function restoreAllListState() {
  const pref = await chrome.storage.local.get(XC_LIST_TYPE_PREF_KEY);
  if (pref[XC_LIST_TYPE_PREF_KEY] && LIST_CONFIG[pref[XC_LIST_TYPE_PREF_KEY]]) {
    listType = pref[XC_LIST_TYPE_PREF_KEY];
    jobState.listType = listType;
  }

  let restored = false;
  for (const type of LIST_TYPES) {
    if (await restoreListState(type)) {
      restored = true;
    }
  }
  return restored;
}

function ensureRestored() {
  if (!restorePromise) {
    restorePromise = restoreAllListState().finally(() => {
      restorePromise = null;
    });
  }
  return restorePromise;
}

async function setListType(nextType) {
  if (!LIST_CONFIG[nextType]) {
    return { ok: false, error: 'Invalid list type.' };
  }

  if (isListTypeSwitchLocked()) {
    return { ok: false, error: 'Wait until collection finishes before switching lists.' };
  }

  if (!jobState.isScraping && !activeFetch?.running) {
    await syncActiveAccountFromTab({ refreshSub: false });
  }
  await ensureRestored();
  listType = nextType;
  jobState.listType = nextType;
  if (!activeFetch?.running) {
    jobState.isScraping = false;
    jobState.isEnriching = false;
  }
  if (!curList(nextType).length) {
    await restoreListState(nextType);
  }
  jobState.count = curList(nextType).length;
  jobState.rawCount = curRaw(nextType).length || curList(nextType).length;

  const cfg = listCfg();
  const { data: saved } = await readPersistData(nextType, jobState.username);
  if (saved?.savedAt) {
    jobState.savedAt = saved.savedAt;
    if (saved.jobState) {
      const savedUser = (saved.jobState.username || '').toLowerCase();
      const activeUser = (jobState.username || '').toLowerCase();
      if (!activeUser || !savedUser || savedUser === activeUser) {
        jobState.reason = saved.jobState.reason ?? jobState.reason;
        jobState.filterRemoved = saved.jobState.filterRemoved ?? 0;
        jobState.appliedFilters = Array.isArray(saved.jobState.appliedFilters)
          ? saved.jobState.appliedFilters.slice()
          : [];
        jobState.totalFollowing = saved.jobState.totalFollowing ?? jobState.totalFollowing;
        jobState.totalFollowers = saved.jobState.totalFollowers ?? jobState.totalFollowers;
        jobState.username = saved.jobState.username ?? jobState.username;
      }
    }
  } else {
    jobState.savedAt = null;
  }

  await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: nextType });
  await hydrateSubscriptionFromStorage(jobState.username);
  notifyProgress();
  return normalizeClientState(getStatus());
}

function usersForMutuals(type) {
  const bucket = listStore[type];
  return bucket.raw.length ? bucket.raw : bucket.list;
}

function countMutualsFromRelationships(type, users) {
  if (!users.length) return null;

  let withData = 0;
  let mutualCount = 0;

  for (const user of users) {
    const flag = type === 'followers' ? user.you_follow : user.follows_you;
    if (typeof flag !== 'boolean') continue;
    withData += 1;
    if (flag) mutualCount += 1;
  }

  if (withData === 0) return null;

  return {
    mutualCount,
    withData,
    total: users.length,
    source: type
  };
}

function computeMutuals() {
  const followingUsers = usersForMutuals('following');
  const followersUsers = usersForMutuals('followers');
  const followingCount = followingUsers.length;
  const followersCount = followersUsers.length;
  const hasBoth = followingCount > 0 && followersCount > 0;

  const tryOrder = listType === 'followers'
    ? ['followers', 'following']
    : ['following', 'followers'];

  for (const type of tryOrder) {
    const users = type === 'followers' ? followersUsers : followingUsers;
    const rel = countMutualsFromRelationships(type, users);
    if (rel) {
      return {
        followingCount,
        followersCount,
        mutualCount: rel.mutualCount,
        hasBoth,
        hasRelationshipData: true,
        method: 'relationship',
        source: rel.source,
        relationshipCoverage: rel.withData,
        relationshipTotal: rel.total
      };
    }
  }

  const followingSet = new Set(
    followingUsers.map((user) => (user.username || '').toLowerCase()).filter(Boolean)
  );
  const followersSet = new Set(
    followersUsers.map((user) => (user.username || '').toLowerCase()).filter(Boolean)
  );

  let mutualCount = 0;
  for (const name of followingSet) {
    if (followersSet.has(name)) mutualCount += 1;
  }

  return {
    followingCount: followingSet.size,
    followersCount: followersSet.size,
    mutualCount,
    hasBoth,
    hasRelationshipData: false,
    method: hasBoth ? 'intersection' : null,
    source: hasBoth ? 'both' : null,
    relationshipCoverage: 0,
    relationshipTotal: 0
  };
}

async function ensureJobTabId() {
  if (jobTabId) return jobTabId;
  const tab = await findLastActiveXTab();
  if (tab?.id) {
    jobTabId = tab.id;
    return jobTabId;
  }
  return null;
}

function formatCsvBool(value) {
  if (value === true) return 'true';
  if (value === false) return 'false';
  return '';
}

const LIST_PREVIEW_COLUMNS = [
  { key: 'username', label: 'username' },
  { key: 'display_name', label: 'display_name' },
  { key: 'friends_count', label: 'friends_count' },
  { key: 'followers_count', label: 'followers_count' },
  { key: 'tweet_count', label: 'tweet_count' },
  { key: 'created_at', label: 'created_at' },
  { key: 'created_on', label: 'created_on' },
  { key: 'bio', label: 'bio' },
  { key: 'is_blue', label: 'is_blue' },
  { key: 'default_avatar', label: 'default_avatar' },
  { key: 'you_follow', label: 'you_follow' },
  { key: 'follows_you', label: 'follows_you' },
  { key: 'last_tweet_at', label: 'last_tweet_at' }
];

function mapListPreviewRow(user) {
  return {
    username: user.username || '',
    display_name: user.display_name ?? user.name ?? '',
    friends_count: user.friends_count ?? '',
    followers_count: user.followers_count ?? '',
    tweet_count: user.tweet_count ?? '',
    created_at: user.created_at ?? '',
    created_on: user.created_at ?? user.created_on ?? '',
    bio: accountBio(user),
    is_blue: user.is_blue ?? false,
    default_avatar: user.default_avatar ?? false,
    you_follow: formatCsvBool(user.you_follow),
    follows_you: formatCsvBool(user.follows_you),
    last_tweet_at: formatLastActiveField(user.last_active_ms)
  };
}

async function getListPreview(requestedType = listType) {
  const type = LIST_CONFIG[requestedType] ? requestedType : listType;
  if (!jobState.isScraping && !activeFetch?.running) {
    await syncActiveAccountFromTab({ refreshSub: false });
  }
  await ensureRestored();
  if (!curList(type).length) {
    await restoreListState(type);
  }

  // Make sure the preview rows (what people click "View" on early) have the
  // rich data (counts etc) for quick verification, especially first batch / free tier.
  if (jobTabId && curList(type).length > 0) {
    await ensureCoreProfileStats(jobTabId, type, null).catch(() => {});
  }

  const cfg = listCfg(type);
  const isNonFree = !!subscriptionInfo.isSubscribed || subscriptionInfo.canExport === true;
  const previewLimit = isNonFree ? 10 : 5;
  const users = curList(type).slice(0, previewLimit);
  return {
    ok: true,
    listType: type,
    listLabel: cfg.label,
    total: curList(type).length,
    columns: LIST_PREVIEW_COLUMNS,
    rows: users.map(mapListPreviewRow),
    previewLimit
  };
}

function buildCsv(users) {
  const header =
    'username,display_name,friends_count,followers_count,tweet_count,created_at,bio,is_blue,default_avatar,you_follow,follows_you,last_tweet_at\n';
  const rows = users.map((user) =>
    [
      user.username,
      user.display_name ?? user.name ?? '',
      user.friends_count ?? '',
      user.followers_count ?? '',
      user.tweet_count ?? '',
      user.created_at ?? '',
      accountBio(user),
      user.is_blue ?? false,
      user.default_avatar ?? false,
      formatCsvBool(user.you_follow),
      formatCsvBool(user.follows_you),
      formatLastActiveField(user.last_active_ms)
    ]
      .map(escapeCsvField)
      .join(',')
  ).join('\n');
  return header + rows + '\n';
}

function parseImportCsvRows(text) {
  const rows = [];
  let i = 0;
  const len = text.length;
  let row = [];
  let field = '';
  let inQuotes = false;

  const pushField = () => { row.push(field); field = ''; };
  const pushRow = () => { if (row.length) rows.push(row); row = []; };

  while (i < len) {
    const c = text[i];
    if (inQuotes) {
      if (c === '"') {
        if (i + 1 < len && text[i + 1] === '"') { field += '"'; i++; }
        else { inQuotes = false; }
      } else {
        field += c;
      }
    } else if (c === '"') {
      inQuotes = true;
    } else if (c === ',') {
      pushField();
    } else if (c === '\n' || c === '\r') {
      pushField();
      pushRow();
      if (c === '\r' && i + 1 < len && text[i + 1] === '\n') i++;
    } else {
      field += c;
    }
    i++;
  }
  pushField();
  if (row.length || field) pushRow();
  return rows;
}

function findImportColumnIndex(headers, patterns) {
  for (let i = 0; i < headers.length; i += 1) {
    const h = (headers[i] || '').toLowerCase().trim();
    if (patterns.some((re) => re.test(h))) return i;
  }
  return -1;
}

function parseImportOptionalCount(value) {
  if (value == null || value === '') return null;
  const cleaned = String(value).replace(/,/g, '').trim();
  const num = Number(cleaned);
  return Number.isFinite(num) ? num : null;
}

function parseImportCsvBool(value) {
  const v = String(value || '').trim().toLowerCase();
  if (v === 'true' || v === '1' || v === 'yes') return true;
  if (v === 'false' || v === '0' || v === 'no') return false;
  return null;
}

function parseImportLastTweetAt(value) {
  const raw = String(value || '').trim();
  if (!raw) return null;
  const ms = Date.parse(raw);
  return Number.isFinite(ms) ? ms : null;
}

function normalizeImportedUser(fields, type) {
  const username = String(fields.username || '').trim().replace(/^@+/, '');
  if (!username || !/^[a-zA-Z0-9_]{1,30}$/.test(username)) return null;

  const user = { username };
  if (fields.display_name) user.display_name = fields.display_name;
  if (fields.friends_count != null) user.friends_count = fields.friends_count;
  if (fields.followers_count != null) user.followers_count = fields.followers_count;
  if (fields.tweet_count != null) user.tweet_count = fields.tweet_count;
  if (fields.created_at) user.created_at = fields.created_at;
  if (fields.bio) user.bio = fields.bio;
  if (fields.is_blue != null) user.is_blue = fields.is_blue;
  if (fields.default_avatar != null) user.default_avatar = fields.default_avatar;
  if (fields.you_follow != null) user.you_follow = fields.you_follow;
  if (fields.follows_you != null) user.follows_you = fields.follows_you;
  if (fields.last_active_ms != null) user.last_active_ms = fields.last_active_ms;

  if (type === 'following' && user.you_follow == null) user.you_follow = true;
  if (type === 'followers' && user.follows_you == null) user.follows_you = true;

  return user;
}

function extractUsersFromImportCsv(text, type = 'following') {
  const rows = parseImportCsvRows(String(text || '').trim());
  if (!rows.length) return [];

  let headerRow = null;
  let data = rows;
  const first = rows[0].map((c) => (c || '').toLowerCase().trim());
  const likelyHeader = first.some((h) =>
    /user|handle|screen|name|login|display|follow|friend|count|bio|blue|avatar|tweet|created|last/.test(h)
  );
  if (likelyHeader) {
    headerRow = first;
    data = rows.slice(1);
  }

  let usernameIdx = 0;
  let displayIdx = -1;
  let friendsIdx = -1;
  let followersIdx = -1;
  let tweetIdx = -1;
  let createdIdx = -1;
  let bioIdx = -1;
  let blueIdx = -1;
  let avatarIdx = -1;
  let youFollowIdx = -1;
  let followsYouIdx = -1;
  let lastTweetIdx = -1;

  if (headerRow) {
    const uIdx = findImportColumnIndex(headerRow, [
      /^username$/,
      /^user$/,
      /^handle$/,
      /^screen.?name$/,
      /^login$/,
      /^screen_name$/
    ]);
    if (uIdx !== -1) usernameIdx = uIdx;
    displayIdx = findImportColumnIndex(headerRow, [/^display.?name$/, /^name$/, /^display_name$/]);
    if (displayIdx === usernameIdx) displayIdx = -1;
    friendsIdx = findImportColumnIndex(headerRow, [
      /^friends_count$/,
      /^following_count$/,
      /^following$/,
      /^friends$/
    ]);
    followersIdx = findImportColumnIndex(headerRow, [/^followers_count$/, /^followers$/]);
    tweetIdx = findImportColumnIndex(headerRow, [/^tweet_count$/, /^tweets$/, /^statuses_count$/]);
    createdIdx = findImportColumnIndex(headerRow, [/^created_at$/, /^account_created$/]);
    bioIdx = findImportColumnIndex(headerRow, [/^bio$/, /^description$/]);
    blueIdx = findImportColumnIndex(headerRow, [/^is_blue$/, /^verified$/, /^blue$/]);
    avatarIdx = findImportColumnIndex(headerRow, [/^default_avatar$/, /^default_profile_image$/]);
    youFollowIdx = findImportColumnIndex(headerRow, [/^you_follow$/, /^following_you_follow$/]);
    followsYouIdx = findImportColumnIndex(headerRow, [/^follows_you$/, /^follows_me$/]);
    lastTweetIdx = findImportColumnIndex(headerRow, [/^last_tweet_at$/, /^last_active$/, /^last_post$/]);
  }

  const users = [];
  for (const r of data) {
    const fields = {
      username: (r[usernameIdx] || r[0] || '').trim(),
      display_name: displayIdx >= 0 ? (r[displayIdx] || '').trim() : '',
      friends_count: friendsIdx >= 0 ? parseImportOptionalCount(r[friendsIdx]) : null,
      followers_count: followersIdx >= 0 ? parseImportOptionalCount(r[followersIdx]) : null,
      tweet_count: tweetIdx >= 0 ? parseImportOptionalCount(r[tweetIdx]) : null,
      created_at: createdIdx >= 0 ? (r[createdIdx] || '').trim() : '',
      bio: bioIdx >= 0 ? (r[bioIdx] || '').trim() : '',
      is_blue: blueIdx >= 0 ? parseImportCsvBool(r[blueIdx]) : null,
      default_avatar: avatarIdx >= 0 ? parseImportCsvBool(r[avatarIdx]) : null,
      you_follow: youFollowIdx >= 0 ? parseImportCsvBool(r[youFollowIdx]) : null,
      follows_you: followsYouIdx >= 0 ? parseImportCsvBool(r[followsYouIdx]) : null,
      last_active_ms: lastTweetIdx >= 0 ? parseImportLastTweetAt(r[lastTweetIdx]) : null
    };
    const user = normalizeImportedUser(fields, type);
    if (user) users.push(user);
  }

  return users;
}

function mergeImportedUserLists(existing, incoming) {
  const order = [];
  const bucket = {};
  for (const user of existing) {
    const key = (user.username || '').toLowerCase();
    if (!key) continue;
    bucket[key] = { ...user };
    order.push(key);
  }

  let added = 0;
  for (const user of incoming) {
    const key = (user.username || '').toLowerCase();
    if (!key) continue;
    if (bucket[key]) {
      mergeUserFields(bucket[key], user);
    } else {
      bucket[key] = { ...user };
      order.push(key);
      added += 1;
    }
  }

  return { list: order.map((k) => bucket[k]), added };
}

function isCsvImportBlocked() {
  if (activeFetch?.running) return true;
  if (activeEnrich?.running) return true;
  if (jobState.isScraping && !LIST_TYPE_IDLE_REASONS.has(jobState.reason)) return true;
  return false;
}

async function loadListFromCsv(type, csvText, options = {}) {
  if (!LIST_CONFIG[type]) {
    return { ok: false, error: 'Invalid list type.' };
  }
  if (isCsvImportBlocked()) {
    return { ok: false, error: 'Wait until collection or filtering finishes before importing.' };
  }

  await ensureRestored();
  await hydrateSubscriptionFromStorage(jobState.username);

  const parsed = extractUsersFromImportCsv(csvText, type);
  if (!parsed.length) {
    return {
      ok: false,
      error: 'No valid usernames found. Use an X Cleaner export or one handle per line.'
    };
  }

  const mode = options.mode === 'append' ? 'append' : 'replace';
  const cap = subscriptionInfo.fetchLimit;
  let nextList;
  let appended = 0;

  if (mode === 'append') {
    const merged = mergeImportedUserLists(curList(type), parsed);
    nextList = merged.list;
    appended = merged.added;
  } else {
    nextList = parsed.map((user) => ({ ...user }));
  }

  let truncated = 0;
  if (cap != null && nextList.length > cap) {
    truncated = nextList.length - cap;
    nextList = nextList.slice(0, cap);
  }

  const nextRaw = nextList.map((user) => ({ ...user }));
  setCurList(nextList, type);
  setCurRaw(nextRaw, type);
  listType = type;
  jobState.listType = type;
  jobState.appliedFilters = [];
  jobState.filterRemoved = 0;
  jobState.isScraping = false;
  jobState.isEnriching = false;
  jobState.reason = 'complete';
  jobState.count = nextList.length;
  jobState.rawCount = nextRaw.length;
  restoredTypes[type] = true;

  // Wire cross-populate for CSV loads: if same username appears in the other list (already loaded),
  // set the mutual flags (you_follow / follows_you) on both sides.
  const otherType = type === 'following' ? 'followers' : 'following';
  const otherSet = new Set((curList(otherType) || []).map(u => (u.username || '').toLowerCase()));
  for (const u of curList(type)) {
    crossPopulateMutualFlags(u, type, otherSet);
  }
  for (const u of curRaw(type)) {
    crossPopulateMutualFlags(u, type, otherSet);
  }

  // Persist updates to the other list if we filled any mutual flags on it
  if ((curList(otherType) || []).length > 0) {
    schedulePersist(true, otherType);
  }

  const cfg = listCfg(type);
  let status = mode === 'append'
    ? `Appended CSV — ${nextList.length.toLocaleString()} ${cfg.label.toLowerCase()} (${parsed.length.toLocaleString()} in file, ${appended.toLocaleString()} new).`
    : `Loaded CSV — ${nextList.length.toLocaleString()} ${cfg.label.toLowerCase()} (replaced).`;
  if (truncated > 0) {
    status += ` Free tier capped at ${XC_FREE_FETCH_LIMIT} (${truncated.toLocaleString()} skipped).`;
  }
  jobState.status = status;

  schedulePersist(true, type);
  notifyProgress({ status, reason: 'complete' });
  return normalizeClientState({
    ok: true,
    ...getStatus(),
    importMode: mode,
    importParsed: parsed.length,
    importLoaded: nextList.length,
    importTruncated: truncated
  });
}

async function sendHudMessage(tabId, payload, retries = 1) {
  if (!tabId) return false;

  for (let attempt = 0; attempt < retries; attempt += 1) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, payload);
      if (payload.action === 'showHud' && response?.ok === false) {
        if (attempt + 1 >= retries) break;
        await sleep(400);
        continue;
      }
      return true;
    } catch (error) {
      if (attempt + 1 >= retries) break;
      await sleep(400);
    }
  }

  return false;
}

async function ensureContentScriptReady(tabId) {
  if (!tabId) return false;

  let injected = false;
  for (let attempt = 0; attempt < 12; attempt += 1) {
    try {
      const response = await chrome.tabs.sendMessage(tabId, { action: 'ping' });
      if (response?.ok) return true;
    } catch (error) {
      if (!injected && attempt >= 9) {
        injected = true;
        try {
          await chrome.scripting.executeScript({
            target: { tabId },
            files: ['list-preview.js', 'content.js']
          });
        } catch (injectError) {}
      }
    }
    await sleep(200 + attempt * 120);
  }

  return false;
}

async function ensureHudShown(tabId, extra = {}) {
  if (!tabId) return false;
  if (!(await ensureContentScriptReady(tabId))) return false;
  return sendHudMessage(tabId, {
    action: 'showHud',
    ...buildHudState(extra)
  }, 16);
}

function attachHudReady(result, hudReady) {
  if (!hudReady) return result;
  return { ...result, hudReady: true };
}

async function ensurePopupHudHandoff(options = {}, hudExtra = {}) {
  if (!options.handoffAfterHud) {
    return { ok: true, hudReady: false };
  }

  const tab = await findFocusedXTab();
  if (!tab?.id) {
    return {
      ok: false,
      hudReady: false,
      error: 'No X tab found. Open x.com in a browser tab first.'
    };
  }

  jobTabId = tab.id;
  const hudReady = await ensureHudShown(tab.id, hudExtra);

  if (!hudReady) {
    return {
      ok: false,
      hudReady: false,
      error: 'Could not open the on-page HUD on your X tab. Refresh x.com and try again.',
      ...normalizeClientState(getStatus())
    };
  }

  return { ok: true, hudReady: true };
}

async function ensureFilterHudHandoff(options = {}, type = listType) {
  return ensurePopupHudHandoff(options, {
    listType: type,
    reason: 'filtering',
    status: 'Applying filters on the X page panel...'
  });
}

const XC_EXPECTED_SNIFFER_VERSION = 5;

async function ensureSnifferInstalled(tabId) {
  const version = await executeOnTab(tabId, () => window.__xcSnifferVersion || 0);
  if (version === XC_EXPECTED_SNIFFER_VERSION) return true;

  try {
    await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      files: ['xc-fetch-sniffer.js']
    });
    return true;
  } catch (error) {
    return false;
  }
}

function formatDebugStatusLine(state = {}) {
  const ts = new Date(state.timestamp || Date.now()).toLocaleTimeString([], {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit'
  });
  const tags = [];
  if (state.method) tags.push(state.method);
  if (state.reason) tags.push(state.reason);
  if (state.fetchMode) tags.push(`mode:${state.fetchMode}`);
  if (state.restPage != null) tags.push(`restP${state.restPage}`);
  if (state.passes != null) tags.push(`pass${state.passes}`);
  else if (state.pages != null) tags.push(`p${state.pages}`);
  if (state.parsedLastPage != null) tags.push(`parsed${state.parsedLastPage}`);
  if (state.addedLastPage != null) tags.push(`+${state.addedLastPage}`);
  if (state.dupLastPage != null && state.dupLastPage > 0) tags.push(`dup${state.dupLastPage}`);
  let msg = String(
    (state.error && (state.reason === 'error' || state.reason === 'rest-empty'))
      ? state.error
      : (state.status || state.error || '')
  ).trim();
  const attemptSummary = state.attemptSummary || state.restAttemptSummary;
  if (attemptSummary && !msg.includes(attemptSummary)) {
    msg = msg ? `${msg} | attempts: ${attemptSummary}` : `attempts: ${attemptSummary}`;
  }
  const tagPrefix = tags.length ? `${tags.join(' ')}: ` : '';
  const line = `${tagPrefix}${msg || '(tick)'}`.trim();
  return line ? `[${ts}] ${line}` : null;
}

function snapshotDebugStatusLog() {
  if (!XC_DEBUG_STATUS_LOG) return [];
  return Array.isArray(jobState.debugStatusLog)
    ? jobState.debugStatusLog.slice(-XC_DEBUG_STATUS_LOG_MAX_LINES)
    : [];
}

function assignJobState(next = {}, options = {}) {
  const preserveLog = options.preserveLog !== false;
  const prevLog = preserveLog ? snapshotDebugStatusLog() : [];
  const nextLog = Array.isArray(next.debugStatusLog) ? next.debugStatusLog : null;
  jobState = {
    ...next,
    debugStatusLog: nextLog?.length
      ? nextLog.slice(-XC_DEBUG_STATUS_LOG_MAX_LINES)
      : prevLog
  };
}

function resetDebugStatusLog(initialEntry = null) {
  if (!XC_DEBUG_STATUS_LOG) {
    jobState.debugStatusLog = [];
    return;
  }
  jobState.debugStatusLog = [];
  if (initialEntry) appendDebugStatusLog(initialEntry);
}

function appendDebugStatusLogStart(entry = {}) {
  if (!XC_DEBUG_STATUS_LOG) return;
  if (!Array.isArray(jobState.debugStatusLog) || !jobState.debugStatusLog.length) {
    resetDebugStatusLog(entry);
    return;
  }
  appendDebugStatusLog(entry);
}

function shouldAppendDebugStatusLog(entry = {}) {
  if (!XC_DEBUG_STATUS_LOG) return false;
  if (entry.reason === 'complete' || entry.reason === 'stopped' || entry.reason === 'start') return true;
  if (entry.reason === 'rest-empty' || entry.reason === 'error') return true;
  if (entry.error) return true;
  if (entry.attemptSummary || entry.restAttemptSummary) return true;
  const status = String(entry.status || '');
  if (/REST|GraphQL worker|fallback|sniffer|verify_credentials|attempts:|failed|error|switching|GraphQL plan|Short by|tail|DONE|dup|empty/i.test(status)) {
    return true;
  }
  if (entry.method === 'rest-v1.1' || entry.method === 'graphql-worker' || entry.method === 'graphql') {
    return true;
  }
  if (entry.method === 'observe') return true;
  if (entry.method && entry.method !== 'native-sniffer') return true;
  if (entry.addedLastPage > 0) return true;
  if (entry.parsedLastPage > 0 && !entry.addedLastPage) return true;
  if (entry.reason === 'scroll-step') return true;
  if (entry.reason === 'collecting' && entry.method === 'native-sniffer') return false;
  return !!status;
}

function persistDebugStatusLog() {
  if (!XC_DEBUG_STATUS_LOG) return;
  try {
    chrome.storage.local.set({
      [XC_DEBUG_STATUS_LOG_STORAGE_KEY]: jobState.debugStatusLog || []
    });
  } catch (error) {}
}

function appendDebugStatusLog(entry = {}) {
  if (!shouldAppendDebugStatusLog(entry)) return;
  const line = formatDebugStatusLine(entry);
  if (!line) return;
  if (!Array.isArray(jobState.debugStatusLog)) jobState.debugStatusLog = [];
  jobState.debugStatusLog.push(line);
  if (jobState.debugStatusLog.length > XC_DEBUG_STATUS_LOG_MAX_LINES) {
    jobState.debugStatusLog = jobState.debugStatusLog.slice(-XC_DEBUG_STATUS_LOG_MAX_LINES);
  }
  persistDebugStatusLog();
}

function debugStatusPayload() {
  return {
    debugStatusLogEnabled: XC_DEBUG_STATUS_LOG,
    debugStatusLog: XC_DEBUG_STATUS_LOG ? (jobState.debugStatusLog || []) : [],
    debugStatusLogPersisted: XC_DEBUG_STATUS_LOG
  };
}

function notifyProgress(extra = {}) {
  jobState = {
    ...jobState,
    listType,
    count: curList().length,
    rawCount: curRaw().length || curList().length,
    ...extra
  };

  appendDebugStatusLog({
    timestamp: Date.now(),
    ...jobState,
    ...extra
  });

  const payload = normalizeClientState({
    type: 'scrapeStatus',
    ok: true,
    ...jobState,
    totalList: totalForType(),
    fetchTarget: effectiveFetchTarget(totalForType()),
    storedCounts: {
      following: listStore.following.list.length,
      followers: listStore.followers.list.length
    },
    listStats: buildListStats(),
    mutuals: computeMutuals(),
    ...subscriptionPayload(),
    ...debugStatusPayload()
  });

  chrome.runtime.sendMessage(payload).catch(() => {});

  if (jobTabId) {
    sendHudMessage(jobTabId, {
      action: 'updateHud',
      ...buildHudState()
    }).catch(() => {});
  }

  schedulePersist();
}

let accountSyncDebounceTimer = null;

function scheduleAccountSyncFromTab(tabId) {
  if (jobState.isScraping || activeFetch?.running) return;
  clearTimeout(accountSyncDebounceTimer);
  accountSyncDebounceTimer = setTimeout(() => {
    syncActiveAccountFromTab({ tabId, refreshSub: false })
      .then((result) => {
        if (result?.switched) notifyProgress();
      })
      .catch(() => {});
  }, 350);
}

chrome.tabs.onActivated.addListener((activeInfo) => {
  chrome.tabs.get(activeInfo.tabId)
    .then((tab) => {
      if (!tab?.id || !isXTabUrl(tab.url)) return;
      jobTabId = tab.id;
      scheduleAccountSyncFromTab(tab.id);
    })
    .catch(() => {});
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo) => {
  if (changeInfo.status === 'complete') {
    chrome.tabs.get(tabId)
      .then((tab) => {
        if (!tab?.url || !isXTabUrl(tab.url)) return;
        scheduleAccountSyncFromTab(tabId);
      })
      .catch(() => {});
  }

  if (tabId !== jobTabId || changeInfo.status !== 'complete') return;
  if (!jobState.username && !jobState.isScraping) return;

  ensureSnifferInstalled(tabId)
    .then(() => sendHudMessage(tabId, {
      action: 'updateHud',
      ...buildHudState()
    }, 12))
    .catch(() => {});
});

async function findLastActiveXTab() {
  const tabs = await chrome.tabs.query({
    url: ['https://x.com/*']
  });

  if (!tabs.length) return null;
  tabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
  return tabs[0];
}

async function findFocusedXTab() {
  const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  if (activeTab?.id && isXTabUrl(activeTab.url)) {
    return activeTab;
  }
  return findLastActiveXTab();
}

async function syncActiveAccountFromTab(options = {}) {
  const {
    refreshSub = true,
    forceSubRefresh = false,
    tabId: preferredTabId,
    username: explicitUsername
  } = options;

  // Always detect first to catch user switches even while a job might be active for previous user.

  let tab = null;
  if (preferredTabId) {
    try {
      tab = await chrome.tabs.get(preferredTabId);
    } catch (error) {
      tab = null;
    }
  }
  if (!tab?.id) {
    tab = await findFocusedXTab();
  }
  if (!tab?.id) {
    return {
      ok: false,
      switched: false,
      username: jobState.username,
      tabId: null,
      error: 'No X tab found. Open x.com in a browser tab first.'
    };
  }

  jobTabId = tab.id;

  let detected = explicitUsername ? String(explicitUsername).replace(/^@+/, '') : null;
  if (!detected) {
    try {
      detected = await detectHandle(tab.id);
    } catch (error) {
      console.warn('[X Cleaner] focused tab handle detect failed', error);
    }
  }

  if (!detected) {
    return { ok: true, switched: false, username: jobState.username, tabId: jobTabId };
  }

  const prevUsername = (jobState.username || '').toLowerCase();
  const nextUsername = detected.toLowerCase();
  const switched = !!prevUsername && prevUsername !== nextUsername;

  if (switched) {
    cancelActiveWork();
    activeFetch = null;
    activeEnrich = null;
    await applyAccountSwitch(detected);
    notifyProgress({
      status: `Switched to @${detected} — showing cached lists for this account.`
    });
  } else if (!jobState.username) {
    jobState.username = detected;
    await cleanupLegacyGlobalPersist(detected);
    await restoreAllListState();
  } else {
    jobState.username = detected;
    await cleanupLegacyGlobalPersist(detected);
    if (!curList('following').length && !curList('followers').length) {
      await restoreAllListState();
    }
  }

  if (refreshSub) {
    const cacheFresh = !forceSubRefresh && await subscriptionCacheIsFresh(detected);
    if (!cacheFresh) {
      await refreshSubscription(detected, forceSubRefresh);
    } else {
      await hydrateSubscriptionFromStorage(detected);
    }
  }

  return { ok: true, switched, username: detected, tabId: jobTabId };
}

async function detectHandle(tabId) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const fromHref = (href) => {
        const match = (href || '').match(/\/([a-zA-Z0-9_]{1,15})(?:[/?]|$)/);
        return match ? match[1] : null;
      };

      const profileLink = document.querySelector('a[data-testid="AppTabBar_Profile_Link"]');
      if (profileLink?.href) {
        const handle = fromHref(profileLink.href);
        if (handle) return handle;
      }

      const switcher = document.querySelector('[data-testid="SideNav_AccountSwitcher_Button"]');
      if (switcher) {
        const text = (switcher.innerText || switcher.textContent || '').trim();
        let match = text.match(/@([a-zA-Z0-9_]{1,15})/);
        if (match) return match[1];

        for (const span of switcher.querySelectorAll('span')) {
          const value = (span.textContent || '').trim();
          match = value.match(/^@?([a-zA-Z0-9_]{1,15})$/);
          if (match) return match[1];
        }
      }

      const pathMatch = location.pathname.match(/^\/([a-zA-Z0-9_]{1,15})(?:\/|$)/);
      if (pathMatch) {
        const reserved = new Set([
          'home', 'explore', 'notifications', 'messages', 'i', 'settings', 'search'
        ]);
        if (!reserved.has(pathMatch[1])) return pathMatch[1];
      }

      return null;
    }
  });

  return results?.[0]?.result || null;
}

function remainingListCount(type, totalList, fetchTarget) {
  const count = curList(type).length;
  if (fetchTarget != null && count < fetchTarget) return fetchTarget - count;
  if (totalList != null && count < totalList) return totalList - count;
  return 0;
}

const NATIVE_PAGE_SIZE = {
  following: 50,
  followers: 48
};

function nativePageSize(type = listType) {
  return NATIVE_PAGE_SIZE[type] || 50;
}

// GraphQL `count` — Following 20/page; Followers 100/page (full list via Followers op).
function graphqlListPageCount(type = listType) {
  return type === 'followers' ? 100 : 20;
}

function graphqlTailPageCount(type = listType) {
  return graphqlListPageCount(type);
}

// When the last page is a small tail, request one account per call (avoids oversize partial-page cursor loss).
const GRAPHQL_TAIL_SINGLE_MAX = 20;

function planGraphqlListFetch(type, totalList, collectedCount = 0) {
  const pageSize = graphqlListPageCount(type);
  if (totalList == null || totalList <= 0) {
    return {
      pageSize,
      remaining: null,
      fullPages: null,
      lastPageAccounts: null,
      totalPages: null,
      tailSingleAccount: false
    };
  }

  const collected = Math.max(0, collectedCount || 0);
  const remaining = Math.max(0, totalList - collected);
  const fullPages = Math.floor(remaining / pageSize);
  const lastPageAccounts = remaining % pageSize;
  const totalPages = fullPages + (lastPageAccounts > 0 ? 1 : 0);
  // Followers: 1/request on small tail. Following: one sized request (native batches are ~50).
  const tailSingleAccount = type === 'following'
    && totalPages === 1
    && remaining > 0
    && remaining <= GRAPHQL_TAIL_SINGLE_MAX;

  return {
    pageSize,
    remaining,
    fullPages,
    lastPageAccounts: lastPageAccounts || (remaining > 0 && remaining <= pageSize ? remaining : 0),
    totalPages,
    tailSingleAccount
  };
}

function graphqlRequestCount(type, totalList, collectedCount = 0) {
  const pageSize = graphqlListPageCount(type);
  const plan = planGraphqlListFetch(type, totalList, collectedCount);
  if (plan.remaining == null || plan.remaining <= 0) return pageSize;
  if (plan.fullPages > 0) return pageSize;
  if (plan.tailSingleAccount) return 1;
  // For followers small tails, avoid tiny counts that can 404; use a small safe batch
  if (type === 'followers' && plan.remaining != null && plan.remaining > 0 && plan.remaining <= 20) {
    return Math.min(Math.max(3, plan.remaining), pageSize);
  }
  return Math.min(plan.remaining + 2, pageSize);
}

function graphqlPageStatusLabel(type, totalList, collectedCount, pageIndex, requestCount) {
  const plan = planGraphqlListFetch(type, totalList, collectedCount);
  if (plan.totalPages == null) return `page ${pageIndex}`;
  if (plan.tailSingleAccount) {
    return `tail ${plan.remaining.toLocaleString()} left, 1/request (#${pageIndex})`;
  }
  const pageNum = Math.min(pageIndex, plan.totalPages);
  return `page ${pageNum}/${plan.totalPages}, count=${requestCount}`;
}

const GRAPHQL_PAGE_DELAY_MS = {
  followers: 1100,
  following: 600
};

// Profile totals are often rounded — a "full page" count may still have another page.
function nativeListLikelyHasMore(count, totalList, type = listType) {
  if (count === 0) return false;
  if (totalList != null && count < totalList) return true;
  const pageSize = nativePageSize(type);
  if (count >= pageSize && count % pageSize === 0) return true;
  return false;
}

function nativeLikelyAtTail(type, collected, totalList) {
  if (totalList == null || collected <= 0) return false;
  const remaining = totalList - collected;
  if (remaining <= 0) return true;
  const pageSize = nativePageSize(type);
  return remaining <= pageSize && collected % pageSize !== 0;
}

function nativeStalePassLimit(type, totalList, collected) {
  if (nativeLikelyAtTail(type, collected, totalList)) return 3;
  const remaining = totalList != null ? totalList - collected : null;
  if (remaining != null && remaining <= nativePageSize(type)) return 4;
  if (totalList != null && collected < totalList) {
    // More patience on large followers lists in overnight gentle mode
    if (type === 'followers' && totalList > 2000) return 12;
    return 8;
  }
  return 5;
}

function nativeListenTimeoutMs(type, passes, remaining) {
  if (passes === 0) {
    return type === 'followers' ? 20000 : 15000;
  }
  if (remaining > 0 && remaining <= 100) return 2000;
  return type === 'followers' ? 6000 : 4000;
}

function observeListenTimeoutMs(type, passes, remaining) {
  if (passes === 0) {
    return type === 'followers' ? 12000 : 20000;
  }
  if (remaining > 0 && remaining <= 100) {
    return type === 'followers' ? scrollJitterMs(3500, 0.25) : scrollJitterMs(8000, 0.25);
  }
  return type === 'followers'
    ? scrollJitterMs(5000, 0.25)
    : scrollJitterMs(11000, 0.3);
}

function observeGraphqlHandoffMinPasses(type, collected) {
  if (type === 'following' && collected === 0) return 1;
  return 2;
}

async function observeTryGraphqlHandoff(tabId, profile, type, seen, fetchTarget, totalList, passes) {
  if (!listFetchNeedsMore(type, totalList)) return false;
  const collected = curList(type).length;
  if (passes < observeGraphqlHandoffMinPasses(type, collected)) return false;
  if (isJobCancelled()) return false;

  const cfg = listCfg(type);
  const captured = await readCapturedListTemplateFromTab(tabId, cfg.opName);
  const pageNote = type === 'followers' ? '~100/page' : '~20/page';
  const stalled = passes >= 5 && collected > 0 && collected < 200; // allow handoff on slow progress for large lists
  const canHandoff = type === 'following'
    ? (collected === 0 && passes >= 1)
      || collected >= 12
      || (collected > 0 && (captured?.url || passes >= 4))
    : !(collected < 12 && !captured?.url) || stalled;
  if (!canHandoff) return false;

  await ensureProfileUserId(tabId, profile);
  if (!profile.userId) return false;

  try {
    await stopListObserverFromTab(tabId);
  } catch (error) {}

  const restartFromTop = collected === 0;
  if (restartFromTop) {
    try {
      await scrollListToTop(tabId);
      await sleep(1000, { cancellable: true });
      if (isJobCancelled()) return true;
    } catch (error) {}
  }

  if (collected > 0) {
    notifyProgress({
      reason: 'collecting',
      method: 'rest-v1.1',
      status: `${cfg.label} observe → REST sniffer cursor (${collected.toLocaleString()} warmed up)...`
    });
    appendDebugStatusLog({
      reason: 'collecting',
      method: 'rest-v1.1',
      status: `${cfg.label} handoff — REST sniffer cursor after ${passes} observe pass(es)`
    });
    await recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList, {
      maxPages: type === 'followers' ? 12 : 16,
      scrollToLoad: true
    });
    if (isJobCancelled() || !listFetchNeedsMore(type, totalList)) return true;

    const tailGap = totalList != null ? totalList - curList(type).length : null;
    if (tailGap != null && tailGap > 0 && tailGap <= 200) {
      await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
      if (isJobCancelled()) return true;
    }
    if (!listFetchNeedsMore(type, totalList)) return true;

    if (type === 'followers') {
      await recoverShortfallViaTabGraphql(tabId, profile, type, seen, totalList, { skipWarmup: true });
      return true;
    }
  }

  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: `${cfg.label} observe → GraphQL (${collected.toLocaleString()} warmed up, ${pageNote})...`
  });
  appendDebugStatusLog({
    reason: 'collecting',
    method: 'graphql',
    status: `Observe handoff to GraphQL (${type}) after ${passes} pass(es), ${collected} collected`
  });

  await continueListFetchWithGraphql(tabId, profile, type, seen, fetchTarget, totalList, {
    restartFromTop
  });
  return true;
}

function effectiveTotalList(type, profile) {
  const cfg = listCfg(type);
  const fromProfile = profile?.[cfg.totalKey];
  if (fromProfile != null) return fromProfile;
  return jobState[cfg.totalKey] ?? null;
}

async function tabIsOnListPage(tabId, username, listPath) {
  const handle = String(username || '').replace(/^@+/, '').toLowerCase();
  if (!handle) return false;

  const pathname = await executeOnTab(tabId, () => (location.pathname || '').toLowerCase());
  if (!pathname) return false;

  const segments = listPath === 'followers'
    ? ['followers']
    : [listPath];

  return segments.some((segment) => {
    const base = `/${handle}/${segment}`;
    return pathname === base || pathname.startsWith(`${base}/`);
  });
}

async function resolveListPagePath(tabId, screenName, listPath) {
  const basePath = listPath || 'following';
  // Always use /followers (all accounts), not /verified_followers subset tab.
  if (basePath === 'followers') return 'followers';
  const effective = await readEffectiveListPathFromTab(tabId, screenName, basePath);
  return effective || basePath;
}

async function resolveFollowersWorkerOpName(_tabId, opName) {
  if (opName !== 'Followers') return opName;
  return 'Followers';
}

async function followersWorkerOpCandidates(_tabId) {
  return ['Followers'];
}

async function buildGraphqlCatalog(tabId, type, force = false) {
  let catalog = await prefetchQueryCatalog(force);
  if (type === 'followers') {
    catalog = await resolveCatalogWithTabQueryIds(tabId, catalog);
  }
  return catalog;
}

async function fetchListGraphqlPage(tabId, type, fetchParams, options = {}) {
  const listPath = fetchParams.listPath
    || (fetchParams.opName === 'Followers' ? 'followers' : 'following');
  const params = {
    ...fetchParams,
    listPath,
    capturedTemplate: options.capturedTemplate ?? null
  };

  if (tabId) {
    if (type === 'followers' && !params.capturedTemplate) {
      try {
        const snifferTemplate = await readCapturedListTemplateFromTab(tabId, params.opName);
        if (snifferTemplate?.url) {
          const sniffRes = await fetchListPageFromTab(tabId, {
            ...params,
            capturedTemplate: snifferTemplate
          });
          if (sniffRes?.ok) return sniffRes;
        }
      } catch (error) {}
    }

    let tabRes = await fetchListPageFromTab(tabId, params);
    if (tabRes?.ok) return tabRes;

    const shouldRefresh = !options.retried
      && (tabRes?.status === 404
        || tabRes?.status === 401
        || /404|401|auth failed/i.test(tabRes?.error || ''));
    if (shouldRefresh) {
      const freshCatalog = await buildGraphqlCatalog(tabId, type, true);
      tabRes = await fetchListPageFromTab(tabId, {
        ...params,
        catalog: freshCatalog,
        capturedTemplate: null
      });
      if (tabRes?.ok) return tabRes;
    }

    if (type === 'followers') {
      return tabRes;
    }

    const merged = await fetchListPageMerged(tabId, { ...params, capturedTemplate: null });
    return merged?.ok ? merged : (tabRes || merged);
  }

  const session = await getXSessionCookies();
  return fetchListPageWorker({
    opName: params.opName,
    userId: params.userId,
    screenName: params.screenName,
    cursor: params.cursor,
    count: params.count,
    catalog: params.catalog,
    ct0: session.ct0,
    listPath
  });
}

async function recoverShortfallViaWorkerGraphql(tabId, profile, type, seen, totalList) {
  if (isJobCancelled()) return 0;
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (gap == null || gap <= 0 || gap > 200) return 0;

  const cfg = listCfg(type);
  const session = await getXSessionCookies();
  if (!session.ct0 || !profile.userId) return 0;

  let catalog = await buildGraphqlCatalog(tabId, type, true);
  const opNames = type === 'followers'
    ? await followersWorkerOpCandidates(tabId)
    : [cfg.opName];
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;
  let totalAdded = 0;

  appendDebugStatusLog({
    status: `Worker recovery: ${gap.toLocaleString()} short — sweeping ${opNames.join(' → ')}...`,
    reason: 'collecting',
    method: 'graphql-worker'
  });
  notifyProgress({
    reason: 'collecting',
    method: 'graphql-worker',
    status: `Short by ${gap.toLocaleString()} — worker GraphQL sweep...`
  });

  for (const opName of opNames) {
    if (!listFetchNeedsMore(type, totalList)) break;

    let cursor = null;
    let pages = 0;
    let stalePages = 0;
    const maxPages = Math.ceil((totalList || 500) / graphqlListPageCount(type)) + 8;

    while (!isJobCancelled() && pages < maxPages && listFetchNeedsMore(type, totalList)) {
      const requestCount = graphqlRequestCount(type, totalList, curList(type).length);
      const res = await fetchListPageWorker({
        opName,
        userId: profile.userId,
        screenName: profile.username,
        cursor,
        count: requestCount,
        catalog,
        ct0: session.ct0,
        listPath: cfg.path
      });

      if (!res?.ok) {
        appendDebugStatusLog({
          status: `Worker recovery ${opName} failed: ${res?.error || res?.status || 'unknown'}`,
          method: 'graphql-worker',
          reason: 'collecting'
        });
        if (tabId && pages === 0 && type === 'followers') {
          const tabRes = await fetchListGraphqlPage(tabId, type, {
            opName,
            userId: profile.userId,
            screenName: profile.username,
            cursor,
            count: requestCount,
            catalog,
            listPath: cfg.path
          });
          if (tabRes?.ok) {
            const parsedCount = (tabRes.users || []).length;
            const added = addNativeUsers({ users: tabRes.users || [] }, seen, profile.username, type);
            totalAdded += added;
            trimListToFetchLimit(type);
            pages += 1;
            notifyProgress({
              reason: 'collecting',
              method: 'graphql-worker',
              pages,
              addedLastPage: added,
              status: `Recovery tab ${opName} p${pages}: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added}, parsed ${parsedCount})`
            });
            if (!listFetchNeedsMore(type, totalList)) return totalAdded;
            const nextCursor = tabRes.nextCursor || null;
            if (nextCursor && nextCursor !== cursor) {
              cursor = nextCursor;
              stalePages = 0;
              continue;
            }
          }
        }
        break;
      }

      const parsedCount = (res.users || []).length;
      const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
      totalAdded += added;
      trimListToFetchLimit(type);
      pages += 1;

      notifyProgress({
        reason: 'collecting',
        method: 'graphql-worker',
        pages,
        addedLastPage: added,
        status: `Recovery ${opName} p${pages}: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added}, parsed ${parsedCount})`
      });

      if (!listFetchNeedsMore(type, totalList)) return totalAdded;

      const nextCursor = res.nextCursor || null;
      if (!nextCursor || nextCursor === cursor) {
        stalePages += 1;
        if (stalePages >= 2) break;
        continue;
      }

      stalePages = 0;
      cursor = nextCursor;
      await sleep(requestCount === 1 ? Math.min(pageDelayMs, 450) : pageDelayMs, { cancellable: true });
      if (isJobCancelled()) return totalAdded;
    }

    if (!listFetchNeedsMore(type, totalList) || totalAdded > 0) break;
  }

  return totalAdded;
}

async function warmRestListPageContext(tabId, profile, type = listType) {
  const cfg = listCfg(type);
  const username = profile?.username;
  if (!tabId || !username) return false;

  const listUrl = `https://x.com/${String(username).replace(/^@+/, '')}/${cfg.path}`;
  const fullSettleMs = type === 'followers' ? XC_FOLLOWERS_NAV_SETTLE_MS : XC_LIST_NAV_SETTLE_MS;
  const scrollMs = type === 'followers' ? 2500 : 1800;

  await ensureSnifferInstalled(tabId);

  const pathname = await executeOnTab(tabId, () => (location.pathname || '').toLowerCase());
  const onVerifiedFollowers = !!(pathname && pathname.includes('verified_followers'));
  const alreadyOnListPage = !onVerifiedFollowers && await tabIsOnListPage(tabId, username, cfg.path);

  if (alreadyOnListPage) {
    appendDebugStatusLog({
      status: `REST warmup: already on ${cfg.label.toLowerCase()} page — sniffer + session...`,
      method: 'rest-v1.1'
    });
    notifyProgress({
      reason: 'collecting',
      method: 'rest-v1.1',
      status: `Using open ${cfg.label.toLowerCase()} tab for REST session...`
    });
    await ensureSnifferInstalled(tabId);
    if (XC_PRE_LIST_FETCH_SETTLE_MS > 0) {
      await sleep(XC_PRE_LIST_FETCH_SETTLE_MS);
    }
  } else {
    appendDebugStatusLog({
      status: `REST warmup: opening ${cfg.label.toLowerCase()} page for session + sniffer...`,
      method: 'rest-v1.1'
    });
    notifyProgress({
      reason: 'collecting',
      method: 'rest-v1.1',
      status: `Opening ${cfg.label.toLowerCase()} page for REST session...`
    });
    await chrome.tabs.update(tabId, { url: listUrl, active: true });
    await waitAfterTabNavigation(tabId, fullSettleMs);
    await ensureSnifferInstalled(tabId);

    const afterPath = await executeOnTab(tabId, () => (location.pathname || '').toLowerCase());
    if (afterPath && afterPath.includes('verified_followers')) {
      await chrome.tabs.update(tabId, { url: listUrl, active: true });
      await waitAfterTabNavigation(tabId, fullSettleMs);
      await ensureSnifferInstalled(tabId);
    }
  }

  try {
    if (fastScrollEnabled) {
      await executeOnTab(tabId, () => {
        window.scrollTo(0, Math.max(document.body.scrollHeight, 1200));
      });
      await sleep(alreadyOnListPage ? Math.min(scrollMs, 1200) : scrollMs);
    } else {
      await scrollListStep(tabId);
      await sleep(scrollJitterMs(type === 'followers' ? 6000 : 5000, 0.25));
    }
  } catch (error) {}

  await xcRestPrepareSession(tabId);
  return true;
}

async function recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList, options = {}) {
  if (isJobCancelled()) return 0;
  const cfg = listCfg(type);
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (!tabId || !gap || gap <= 0) return 0;

  const maxPages = options.maxPages || (type === 'followers' ? 12 : 16);
  let totalAdded = 0;
  let stalePasses = 0;
  let restCursor = null;

  for (let pass = 0; pass < maxPages && !isJobCancelled() && listFetchNeedsMore(type, totalList); pass += 1) {
    let cursor = restCursor;
    if (!cursor || cursor === '0') {
      cursor = await readNativeListCursorFromTab(tabId, cfg.opName);
      if (!cursor || cursor === '0') {
        if (options.scrollToLoad && pass < maxPages - 1) {
          try {
            const remaining = totalList != null ? totalList - curList(type).length : gap;
            if (remaining != null && remaining <= 20) {
              await scrollListToLoad(tabId, { gap: remaining, aggressive: true });
              await sleep(type === 'followers' ? 1200 : 1800, { cancellable: true });
              if (isJobCancelled()) return totalAdded;
            } else {
              await scrollListStep(tabId);
              await sleep(type === 'followers' ? 1800 : 2500, { cancellable: true });
              if (isJobCancelled()) return totalAdded;
            }
          } catch (error) {}
          cursor = await readNativeListCursorFromTab(tabId, cfg.opName);
        }
        if (!cursor || cursor === '0') break;
      }
    }

    try {
      const remaining = totalList != null ? totalList - curList(type).length : gap;
      const page = await xcRestFetchListPage(profile.username, type, cursor, {
        tabId,
        userId: profile.userId,
        preferTabContext: true,
        pageSize: Math.min(200, Math.max(remaining + 5, 20)),
        tabRetries: 2
      });
      const parsedCount = (page.users || []).length;
      const added = addNativeUsers({ users: page.users || [] }, seen, profile.username, type);
      trimListToFetchLimit(type);
      totalAdded += added;

      const nextCursor = page.nextCursor && page.nextCursor !== '0' ? page.nextCursor : null;
      if (nextCursor && nextCursor !== cursor) {
        restCursor = nextCursor;
      } else {
        restCursor = null;
      }

      if (added > 0) {
        stalePasses = 0;
        notifyProgress({
          reason: 'collecting',
          method: 'rest-v1.1',
          addedLastPage: added,
          status: `REST sniffer cursor: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
        });
      } else if (parsedCount > 0 && restCursor) {
        stalePasses = 0;
      } else {
        stalePasses += 1;
        restCursor = null;
        if (stalePasses >= 2) break;
      }
    } catch (error) {
      restCursor = null;
      break;
    }

    if (
      options.scrollToLoad
      && listFetchNeedsMore(type, totalList)
      && pass < maxPages - 1
      && (!restCursor || restCursor === '0')
    ) {
      try {
        await scrollListStep(tabId);
        await sleep(type === 'followers' ? 1500 : 2200, { cancellable: true });
        if (isJobCancelled()) return totalAdded;
      } catch (error) {}
    }
  }

  return totalAdded;
}

async function recoverShortfallViaRest(tabId, profile, type, seen, totalList) {
  if (isJobCancelled()) return 0;
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (gap == null || gap <= 0 || gap > 100 || !profile?.username) return 0;

  appendDebugStatusLog({
    status: `REST tail recovery: ${gap.toLocaleString()} short — multi-strategy REST...`,
    method: 'rest-v1.1',
    reason: 'collecting'
  });
  notifyProgress({
    reason: 'collecting',
    method: 'rest-v1.1',
    status: `Short by ${gap.toLocaleString()} — REST tail strategies...`
  });

  let snifferCursor = null;
  try {
    snifferCursor = await readNativeListCursorFromTab(tabId, listCfg(type).opName);
  } catch (error) {}

  const lastResult = {
    nextCursor: snifferCursor || '0',
    hasValidCursor: !!(snifferCursor && snifferCursor !== '0')
  };
  const requestOptions = {
    tabId,
    userId: profile.userId,
    preferTabContext: true,
    pageSize: totalList,
    tabRetries: 2
  };
  const allAttempts = [];

  try {
    const tail = await xcRestTryShortfallRecovery(
      profile.username,
      type,
      totalList,
      curList(type).length,
      lastResult,
      requestOptions,
      allAttempts
    );
    const recovery = tail?.recovery;
    if (recovery?.users?.length) {
      const added = addNativeUsers({ users: recovery.users }, seen, profile.username, type);
      trimListToFetchLimit(type);
      const attemptNote = xcRestFormatAttempts(recovery.attempts || allAttempts);
      appendDebugStatusLog({
        status: `REST tail ${tail.label || 'recovery'}: +${added} parsed ${recovery.users.length}${attemptNote ? ` (${attemptNote})` : ''}`,
        method: 'rest-v1.1',
        reason: 'collecting'
      });
      notifyProgress({
        reason: 'collecting',
        method: 'rest-v1.1',
        addedLastPage: added,
        status: `REST tail (${tail.label || 'recovery'}): ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
      });
      return added;
    }
    if (allAttempts.length) {
      appendDebugStatusLog({
        status: `REST tail strategies empty — ${xcRestFormatAttempts(allAttempts)}`,
        method: 'rest-v1.1',
        reason: 'collecting'
      });
    }

    // For gentle followers small tail: if no new users, do extra gentle scroll to potentially advance the native cursor/sniffer, then retry once
    if (type === 'followers' && !fastScrollEnabled && gap <= 30) {
      try {
        await scrollListToLoad(tabId);
        await sleep(2000, { cancellable: true });
        if (isJobCancelled()) return 0;
        const freshCursor = await readNativeListCursorFromTab(tabId, listCfg(type).opName);
        if (freshCursor && freshCursor !== lastResult.nextCursor) {
          lastResult.nextCursor = freshCursor;
          lastResult.hasValidCursor = true;
          const retryTail = await xcRestTryShortfallRecovery(
            profile.username,
            type,
            totalList,
            curList(type).length,
            lastResult,
            requestOptions,
            allAttempts
          );
          const retryRec = retryTail?.recovery;
          if (retryRec?.users?.length) {
            const added = addNativeUsers({ users: retryRec.users }, seen, profile.username, type);
            if (added > 0) {
              trimListToFetchLimit(type);
              notifyProgress({
                reason: 'collecting',
                method: 'rest-v1.1',
                addedLastPage: added,
                status: `REST tail (post-scroll retry): ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
              });
              return added;
            }
          }
        }
      } catch (e) {}
    }

    // For small gentle follower tails: force a fresh screen_name fetch (cursor -1, sized to remaining + buffer).
    // This mimics the successful full-page REST in fast mode for the tail without doing full-list bulk on large accounts.
    // Extra pause keeps it gentle/stealthy.
    if (type === 'followers' && !fastScrollEnabled && gap > 0 && gap <= 50) {
      try {
        await sleep(3000, { cancellable: true });
        if (isJobCancelled()) return 0;
        const fresh = await xcRestFetchListPage(profile.username, type, '-1', {
          ...requestOptions,
          pageSize: Math.min(totalList || (gap + 50), XC_REST_PAGE_SIZE),
          preferUserId: false,
          preferTabContext: true,
          tabRetries: 2
        });
        if (fresh?.users?.length) {
          const added = addNativeUsers({ users: fresh.users }, seen, profile.username, type);
          if (added > 0) {
            trimListToFetchLimit(type);
            const attemptNote = xcRestFormatAttempts(fresh.attempts || []);
            appendDebugStatusLog({
              status: `REST tail (fresh full): +${added} parsed ${fresh.users.length}${attemptNote ? ` (${attemptNote})` : ''}`,
              method: 'rest-v1.1',
              reason: 'collecting'
            });
            notifyProgress({
              reason: 'collecting',
              method: 'rest-v1.1',
              addedLastPage: added,
              status: `REST tail (fresh): ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
            });
            return added;
          }
        }
      } catch (e) {}
    }
  } catch (error) {
    appendDebugStatusLog({
      status: `REST tail recovery failed: ${error.message || error}`,
      method: 'rest-v1.1',
      reason: 'collecting'
    });
  }

  return 0;
}

async function recoverShortfallViaNativeScrollSniffer(tabId, profile, type, seen, totalList) {
  const cfg = listCfg(type);
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (!tabId || !gap || gap <= 0 || gap > 100) return 0;

  let totalAdded = 0;
  let lastSeq = 0;
  // More passes for small gaps in gentle mode on followers (patient overnight collection)
  let passes;
  if (fastScrollEnabled) {
    passes = (gap <= 10 ? 4 : 2);
  } else if (type === 'followers' && gap <= 25) {
    passes = Math.min(25, Math.max(12, Math.ceil(gap * 1.2)));
  } else {
    passes = (gap <= 10 ? 8 : 12);
  }
  const listenMs = fastScrollEnabled
    ? (type === 'followers' ? 7000 : 5000)
    : (type === 'followers' ? 16000 : 12000);

  appendDebugStatusLog({
    status: `Native scroll sniffer: ${gap.toLocaleString()} short — ${passes} scroll passes...`,
    method: 'native-sniffer',
    reason: 'collecting'
  });
  notifyProgress({
    reason: 'collecting',
    method: 'native-sniffer',
    status: `Scrolling ${cfg.label.toLowerCase()} to trigger native API (${gap.toLocaleString()} short)...`
  });

  for (let pass = 0; pass < passes && !isJobCancelled() && listFetchNeedsMore(type, totalList); pass += 1) {
    await scrollListToLoad(tabId);
    await sleep(await sleepAfterScrollStep(type, 'shortfall'), { cancellable: true });
    if (isJobCancelled()) return totalAdded;

    const native = await waitForNativeList(tabId, cfg.opName, lastSeq, listenMs);
    if (native?.users?.length) {
      const added = addNativeUsers(native, seen, profile.username, type);
      totalAdded += added;
      trimListToFetchLimit(type);
      if (native.seq) lastSeq = Math.max(lastSeq, native.seq);
      if (added > 0) {
        notifyProgress({
          reason: 'collecting',
          method: 'native-sniffer',
          addedLastPage: added,
          status: fastScrollEnabled
            ? `Scroll sniffer p${pass + 1}: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
            : `Gentle sniffer p${pass + 1}: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
        });
      }
    }

    try {
      const drain = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
      if (drain?.users?.length) {
        const drainAdded = addNativeUsers({ users: drain.users }, seen, profile.username, type);
        totalAdded += drainAdded;
        trimListToFetchLimit(type);
        if (drainAdded > 0) {
          notifyProgress({
            reason: 'collecting',
            method: 'native-sniffer',
            addedLastPage: drainAdded,
            status: `Scroll drain p${pass + 1}: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${drainAdded})`
          });
        }
      }
    } catch (error) {}

    // For followers small gaps, interleave a quick REST recovery attempt (more reliable than pure sniffer)
    if (type === 'followers' && gap != null && gap <= 30 && pass % 3 === 2) {
      const restAdded = await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
      totalAdded += restAdded;
      if (restAdded > 0) {
        notifyProgress({
          reason: 'collecting',
          method: 'rest-v1.1',
          status: `REST top-up during sniffer: +${restAdded} (now ${curList(type).length})`
        });
      }
    }

    if (!listFetchNeedsMore(type, totalList)) break;
  }

  return totalAdded;
}

async function recoverShortfallChain(tabId, profile, type, seen, totalList, options = {}) {
  if (isJobCancelled()) return { totalAdded: 0, summary: 'cancelled' };
  const notes = [];
  let totalAdded = 0;

  const restAdded = await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
  totalAdded += restAdded;
  if (restAdded > 0) notes.push(`rest:+${restAdded}`);

  if (listFetchNeedsMore(type, totalList)) {
    const gqlAdded = await recoverShortfallViaTabGraphql(
      tabId,
      profile,
      type,
      seen,
      totalList,
      options
    );
    totalAdded += gqlAdded;
    if (gqlAdded > 0) notes.push(`gql:+${gqlAdded}`);
  }

  if (listFetchNeedsMore(type, totalList)) {
    const workerAdded = await recoverShortfallViaWorkerGraphql(tabId, profile, type, seen, totalList);
    totalAdded += workerAdded;
    if (workerAdded > 0) notes.push(`worker:+${workerAdded}`);
  }

  if (listFetchNeedsMore(type, totalList)) {
    const gap = totalList != null ? totalList - curList(type).length : null;
    const runTailGap = async () => fetchListTailGap(tabId, profile, type, seen, totalList);
    const tailThreshold = type === 'followers' ? gentleFollowersRecoveryCap(totalList) : 20;
    const tailGapAdded = gap != null && gap > 0 && gap <= tailThreshold
      ? await withFastScrollRecoveryBoost(runTailGap)
      : await runTailGap();
    totalAdded += tailGapAdded;
    if (tailGapAdded > 0) notes.push(`tail-gap:+${tailGapAdded}`);
  }

  return {
    totalAdded,
    summary: notes.length ? notes.join(', ') : ''
  };
}

async function recoverShortfallViaTabGraphql(tabId, profile, type, seen, totalList, options = {}) {
  if (isJobCancelled()) return 0;
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (gap == null || gap <= 0 || gap > 200 || !tabId) return 0;

  const cfg = listCfg(type);
  let totalAdded = 0;

  if (!options.skipWarmup) {
    await warmRestListPageContext(tabId, profile, type);
  }

  appendDebugStatusLog({
    status: `Tab recovery: ${gap.toLocaleString()} short — native sniffer + tab GraphQL...`,
    reason: 'collecting',
    method: 'graphql-tab'
  });
  notifyProgress({
    reason: 'collecting',
    method: 'rest-v1.1',
    status: `Short by ${gap.toLocaleString()} — tab GraphQL + sniffer tail...`
  });

  try {
    const nativeDrain = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
    if (nativeDrain?.users?.length) {
      const added = addNativeUsers({ users: nativeDrain.users }, seen, profile.username, type);
      totalAdded += added;
      trimListToFetchLimit(type);
      if (added > 0) {
        notifyProgress({
          reason: 'collecting',
          method: 'rest-v1.1',
          addedLastPage: added,
          status: `Sniffer drain: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added})`
        });
      }
    }
  } catch (error) {}

  if (!listFetchNeedsMore(type, totalList)) return totalAdded;

  if (type === 'followers') {
    const restCursorAdded = await recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList, {
      maxPages: 8,
      scrollToLoad: true
    });
    totalAdded += restCursorAdded;
    if (!listFetchNeedsMore(type, totalList)) return totalAdded;

    const restTailGap = totalList != null ? totalList - curList(type).length : null;
    if (restTailGap != null && restTailGap > 0 && restTailGap <= 100) {
      totalAdded += await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
    }
    if (!listFetchNeedsMore(type, totalList)) return totalAdded;
  }

  const scrollSnifferAdded = await recoverShortfallViaNativeScrollSniffer(tabId, profile, type, seen, totalList);
  totalAdded += scrollSnifferAdded;
  if (!listFetchNeedsMore(type, totalList)) return totalAdded;

  const domAdded = await fetchListTailDom(tabId, profile, type, seen, totalList);
  totalAdded += domAdded;
  if (!listFetchNeedsMore(type, totalList)) return totalAdded;

  if (type !== 'followers') {
    const restCursorAdded = await recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList);
    totalAdded += restCursorAdded;
    if (!listFetchNeedsMore(type, totalList)) return totalAdded;
  }

  if (!profile.userId) {
    try {
      const catalog = await prefetchQueryCatalog(false);
      profile.userId = await resolveUserIdFromScreenName(profile.username, catalog, tabId);
    } catch (error) {}
  }
  if (!profile.userId) return totalAdded;

  const session = await getXSessionCookies();
  if (!session.ct0) return totalAdded;

  let catalog = await buildGraphqlCatalog(tabId, type, true);
  const opNames = type === 'followers' ? ['Followers'] : [cfg.opName];
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;
  const remainingGap = totalList != null ? totalList - curList(type).length : null;
  const maxPages = remainingGap != null && remainingGap <= 10
    ? 5
    : Math.ceil((totalList || 500) / graphqlListPageCount(type)) + 4;

  for (const opName of opNames) {
    if (!listFetchNeedsMore(type, totalList)) break;

    const capturedOp = await readCapturedListOpNameFromTab(tabId, opName);
    let captured = type === 'followers' ? null : await readCapturedListTemplateFromTab(tabId, capturedOp || opName);
    if (!captured?.url) {
      await scrollListToLoad(tabId);
      await sleep(await sleepAfterScrollStep(type, 'shortfall'), { cancellable: true });
      if (isJobCancelled()) return totalAdded;
      captured = await readCapturedListTemplateFromTab(tabId, capturedOp || opName);
    }
    let cursor = null;
    let pages = 0;
    let stalePages = 0;
    let zeroAddPages = 0;
    let droppedCaptured = false;

    while (!isJobCancelled() && pages < maxPages && listFetchNeedsMore(type, totalList)) {
      const requestCount = graphqlRequestCount(type, totalList, curList(type).length);
      let res = await fetchListGraphqlPage(tabId, type, {
        opName: capturedOp || opName,
        userId: profile.userId,
        screenName: profile.username,
        cursor,
        count: requestCount,
        catalog,
        listPath: cfg.path
      }, {
        capturedTemplate: type === 'followers' ? null : captured,
        retried: droppedCaptured
      });

      if (
        !res?.ok
        && !droppedCaptured
        && (res?.status === 404 || res?.status === 401 || /404|401|auth failed/i.test(res?.error || ''))
      ) {
        droppedCaptured = true;
        captured = null;
        catalog = await buildGraphqlCatalog(tabId, type, true);
        appendDebugStatusLog({
          status: `Tab recovery ${opName}: retrying in tab with live query id`,
          method: 'graphql-tab',
          reason: 'collecting'
        });
        res = await fetchListGraphqlPage(tabId, type, {
          opName: capturedOp || opName,
          userId: profile.userId,
          screenName: profile.username,
          cursor,
          count: requestCount,
          catalog,
          listPath: cfg.path
        }, { capturedTemplate: null, retried: true });
      }

      if (!res?.ok) {
        appendDebugStatusLog({
          status: `Tab recovery ${opName} failed: ${res?.error || res?.status || 'unknown'}`,
          method: 'graphql-tab',
          reason: 'collecting'
        });
        break;
      }

      const parsedCount = (res.users || []).length;
      const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
      totalAdded += added;
      trimListToFetchLimit(type);
      pages += 1;

      notifyProgress({
        reason: 'collecting',
        method: 'rest-v1.1',
        pages,
        addedLastPage: added,
        status: `Tab recovery ${opName} p${pages}: ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} (+${added}, parsed ${parsedCount})`
      });

      if (!listFetchNeedsMore(type, totalList)) return totalAdded;

      if (added <= 0) {
        zeroAddPages += 1;
        if (zeroAddPages >= 2) break;
      } else {
        zeroAddPages = 0;
      }

      const nextCursor = res.nextCursor || null;
      if (!nextCursor || nextCursor === cursor) {
        stalePages += 1;
        if (stalePages >= 2) break;
        continue;
      }

      stalePages = 0;
      cursor = nextCursor;
      await sleep(requestCount === 1 ? Math.min(pageDelayMs, 450) : pageDelayMs, { cancellable: true });
      if (isJobCancelled()) return totalAdded;
    }

    if (!listFetchNeedsMore(type, totalList) || totalAdded > 0) break;
  }

  return totalAdded;
}

function listFetchNeedsMore(type, totalList) {
  const count = curList(type).length;
  const subscriptionCap = subscriptionInfo.fetchLimit;
  if (subscriptionCap != null && count >= subscriptionCap) return false;
  if (totalList != null && count >= totalList) return false;
  if (totalList != null && count < totalList) return true;
  return nativeListLikelyHasMore(count, totalList, type);
}

async function fetchListPageForJob(tabId, params) {
  const basePath = params.listPath || (params.opName === 'Followers' ? 'followers' : 'following');
  const listPath = await resolveListPagePath(tabId, params.screenName, basePath);
  const tabParams = { ...params, listPath };
  const tabRes = await fetchListPageFromTab(tabId, tabParams);
  if (tabRes?.ok) return tabRes;
  if (tabRes && !tabRes.ok) {
    console.warn('[X Cleaner] tab GraphQL failed, retrying from worker', tabRes.error || tabRes.status);
  }

  const session = await getXSessionCookies();
  const workerOpName = await resolveFollowersWorkerOpName(tabId, params.opName);
  return fetchListPageWorker({
    opName: workerOpName,
    userId: params.userId,
    screenName: params.screenName,
    cursor: params.cursor,
    count: params.count,
    catalog: params.catalog,
    ct0: session.ct0,
    listPath
  });
}

async function fetchListPageMerged(tabId, params) {
  const basePath = params.listPath || (params.opName === 'Followers' ? 'followers' : 'following');
  const listPath = await resolveListPagePath(tabId, params.screenName, basePath);
  const tabParams = { ...params, listPath };
  let tabRes = await fetchListPageFromTab(tabId, tabParams);

  if (tabRes?.ok) {
    return tabRes;
  }

  if (
    params.opName === 'Followers'
    && (tabRes?.status === 401 || /auth failed/i.test(tabRes?.error || ''))
  ) {
    return tabRes;
  }

  const session = await getXSessionCookies();
  const workerOpName = await resolveFollowersWorkerOpName(tabId, params.opName);
  let workerCatalog = params.catalog;
  if (workerOpName === 'Followers') {
    workerCatalog = await resolveCatalogWithTabQueryIds(tabId, workerCatalog);
  }
  const workerRes = await fetchListPageWorker({
    opName: workerOpName,
    userId: params.userId,
    screenName: params.screenName,
    cursor: params.cursor,
    count: params.count,
    catalog: workerCatalog,
    ct0: session.ct0,
    listPath
  });

  if (workerRes?.ok && (!tabRes?.ok || (tabRes?.status === 404 || /404/.test(tabRes?.error || '')))) {
    return workerRes;
  }

  if (tabRes?.ok || workerRes?.ok) {
    return mergeListPageResults(tabRes, workerRes);
  }

  return tabRes || workerRes || { ok: false, error: 'GraphQL page failed', users: [], nextCursor: null };
}

async function fetchListPageWithRetry(tabId, params, options = {}) {
  const retries = options.retries ?? 3;
  let lastRes = null;

  for (let attempt = 0; attempt < retries; attempt += 1) {
    const res = await fetchListPageForJob(tabId, params);
    lastRes = res;
    if (res?.ok) return res;
    if (attempt < retries - 1) {
      await sleep(900 * (attempt + 1), { cancellable: true });
      if (isJobCancelled()) return lastRes;
    }
  }

  return lastRes;
}

async function fetchFullListViaGraphql(tabId, profile, type, fetchTarget, totalList) {
  const cfg = listCfg(type);
  const opName = cfg.opName;
  let userId = profile.userId;
  if (!userId) {
    const catalog = await prefetchQueryCatalog(false);
    userId = await resolveUserIdFromScreenName(profile.username, catalog);
    profile.userId = userId;
  }
  if (!userId) {
    console.warn('[X Cleaner] Full GraphQL fetch skipped — could not resolve userId');
    return { users: [], lastCursor: null };
  }

  const catalog = await prefetchQueryCatalog(false);
  const owner = (profile.username || '').toLowerCase();
  // Only the free-tier cap may stop pagination — profile totals are often rounded (e.g. 50 vs 52).
  const subscriptionCap = subscriptionInfo.fetchLimit;
  const pageSize = graphqlListPageCount(type);
  const captured = await readCapturedListTemplateFromTab(tabId, opName);
  const ordered = [];
  const seen = new Set();
  let cursor = null;
  let lastValidCursor = null;
  let pages = 0;
  let stalePages = 0;
  const maxPages = 500;
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;

  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: `Fetching full ${cfg.label.toLowerCase()} list via GraphQL...`
  });

  while (!isJobCancelled() && pages < maxPages) {
    const useCaptured = pages === 0
      && !cursor
      && (await tabIsOnListPage(tabId, profile.username, cfg.path));
    const res = await fetchListPageWithRetry(tabId, {
      opName,
      listPath: cfg.path,
      userId,
      screenName: profile.username,
      cursor,
      count: pageSize,
      catalog,
      capturedTemplate: useCaptured ? captured : null
    });

    if (!res?.ok) {
      console.warn('[X Cleaner] GraphQL page failed', res.error || res.status);
      break;
    }

    let pageAdded = 0;
    for (const user of res.users || []) {
      const key = (user.username || '').toLowerCase();
      if (!key || key === owner || seen.has(key)) continue;
      seen.add(key);
      ordered.push(user);
      pageAdded += 1;
    }

    if (pageAdded > 0) {
      stalePages = 0;
    } else {
      stalePages += 1;
    }

    const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
    notifyProgress({
      reason: 'collecting',
      method: 'graphql',
      pages: pages + 1,
      addedLastPage: pageAdded,
      status: `GraphQL ${ordered.length.toLocaleString()} / ${totalLabel} ${cfg.label.toLowerCase()} (+${pageAdded.toLocaleString()} page ${pages + 1})`
    });

    if (subscriptionCap != null && ordered.length >= subscriptionCap) break;

    const nextCursor = res.nextCursor || null;
    const likelyMore = nativeListLikelyHasMore(ordered.length, totalList, type);
    if (!nextCursor || nextCursor === cursor) {
      if (likelyMore && pageAdded > 0 && stalePages < 2) {
        stalePages += 1;
        await sleep(pageDelayMs * 2, { cancellable: true });
      if (isJobCancelled()) break;
        continue;
      }
      break;
    }
    lastValidCursor = nextCursor;
    cursor = nextCursor;
    pages += 1;
    if (pageAdded === 0) stalePages += 1;
    await sleep(pageDelayMs, { cancellable: true });
    if (isJobCancelled()) break;
  }

  return { users: ordered, lastCursor: lastValidCursor };
}

async function fetchListTailCursorSweep(tabId, profile, type, seen, totalList, captured) {
  const cfg = listCfg(type);
  const catalog = await prefetchQueryCatalog(false);
  const cursors = (await readNativeListTailCursorsFromTab(tabId, cfg.opName, 8)) || [];
  if (!cursors.length) return 0;

  const pageCount = graphqlTailPageCount(type);
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;
  let totalAdded = 0;

  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: `Tail cursor sweep across ${cursors.length} saved positions...`
  });

  for (const startCursor of [...cursors].reverse()) {
    if (!listFetchNeedsMore(type, totalList)) break;

    let cursor = startCursor;
    const visited = new Set([cursor]);

    for (let page = 0; page < 6 && listFetchNeedsMore(type, totalList); page += 1) {
      const res = await fetchListPageMerged(tabId, {
        opName: cfg.opName,
        listPath: cfg.path,
        userId: profile.userId,
        screenName: profile.username,
        cursor,
        count: pageCount,
        catalog,
        capturedTemplate: captured || null
      });

      if (!res?.ok) break;

      const parsedCount = (res.users || []).length;
      const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
      totalAdded += added;
      trimListToFetchLimit(type);

      if (added > 0) {
        const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
        notifyProgress({
          reason: 'collecting',
          method: 'graphql',
          addedLastPage: added,
          status: `Tail sweep ${curList(type).length.toLocaleString()} / ${totalLabel} (parsed ${parsedCount}, +${added})`
        });
      }

      if (!listFetchNeedsMore(type, totalList)) break;

      const nextCursor = res.nextCursor || null;
      if (!nextCursor || nextCursor === cursor || visited.has(nextCursor)) break;
      visited.add(nextCursor);
      cursor = nextCursor;
      await sleep(pageDelayMs, { cancellable: true });
    if (isJobCancelled()) break;
    }
  }

  return totalAdded;
}

async function fetchListFinalPartialPage(tabId, profile, type, seen, totalList, captured) {
  const cfg = listCfg(type);
  const gap = totalList != null ? totalList - curList(type).length : null;
  if (gap == null || gap <= 0 || gap > nativePageSize(type)) return 0;

  const catalog = await prefetchQueryCatalog(false);
  const cursors = (await readNativeListTailCursorsFromTab(tabId, cfg.opName, 10)) || [];
  const latest = await readNativeListCursorFromTab(tabId, cfg.opName);
  if (latest) cursors.push(latest);
  const unique = [...new Set(cursors.filter(Boolean))];
  if (!unique.length) return 0;

  const listPath = await resolveListPagePath(tabId, profile.username, cfg.path);
  const plan = planGraphqlListFetch(type, totalList, curList(type).length);
  const requestCount = graphqlRequestCount(type, totalList, curList(type).length);
  let totalAdded = 0;
  const tailPasses = plan.tailSingleAccount ? Math.max(gap * 4, 12) : 1;

  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: plan.tailSingleAccount
      ? `Final tail: ${gap.toLocaleString()} ${cfg.label.toLowerCase()} — 1 account per request...`
      : `Fetching final partial page (~${gap.toLocaleString()} ${cfg.label.toLowerCase()}, count=${requestCount})...`
  });

  for (const startCursor of [...unique].reverse()) {
    if (!listFetchNeedsMore(type, totalList)) break;

    let cursor = startCursor;
    let staleTailPasses = 0;

    for (let pass = 0; pass < tailPasses && !isJobCancelled() && listFetchNeedsMore(type, totalList); pass += 1) {
      const countNow = graphqlRequestCount(type, totalList, curList(type).length);
      const res = await fetchListPageMerged(tabId, {
        opName: cfg.opName,
        listPath,
        userId: profile.userId,
        screenName: profile.username,
        cursor,
        count: countNow,
        catalog,
        capturedTemplate: captured || null
      });

      if (!res?.ok) break;

      const parsedCount = (res.users || []).length;
      const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
      totalAdded += added;
      trimListToFetchLimit(type);

      const totalLabel = totalList.toLocaleString();
      const pageLabel = graphqlPageStatusLabel(type, totalList, curList(type).length, pass + 1, countNow);
      notifyProgress({
        reason: 'collecting',
        method: 'graphql',
        addedLastPage: added,
        status: `Final ${pageLabel} — ${curList(type).length.toLocaleString()} / ${totalLabel} (parsed ${parsedCount}, +${added})`
      });

      if (!listFetchNeedsMore(type, totalList)) break;

      const nextCursor = res.nextCursor || null;
      if (!nextCursor || nextCursor === cursor) {
        staleTailPasses += 1;
        if (!plan.tailSingleAccount || staleTailPasses >= 3) break;
        await sleep(GRAPHQL_PAGE_DELAY_MS[type] || 600);
        continue;
      }

      staleTailPasses = 0;
      cursor = nextCursor;
      if (!plan.tailSingleAccount) break;
      await sleep(Math.min(GRAPHQL_PAGE_DELAY_MS[type] || 600, 500));
    }

    if (totalAdded > 0 || !listFetchNeedsMore(type, totalList)) break;
  }

  return totalAdded;
}

async function fetchListTailScrollNative(tabId, profile, type, seen, totalList, lastSeq = 0) {
  const cfg = listCfg(type);
  let seq = lastSeq;
  let totalAdded = 0;
  let stalePasses = 0;
  const gap = totalList != null ? totalList - curList(type).length : null;
  const listenMs = fastScrollEnabled
    ? (gap != null && gap <= 15 ? 3500 : 5000)
    : (gap != null && gap <= 15 ? 12000 : 16000);
  const maxSteps = fastScrollEnabled
    ? (gap != null && gap <= 15 ? 8 : 12)
    : (gap != null && gap <= 15 ? 24 : 80);
  const staleLimit = fastScrollEnabled ? 6 : 4;

  notifyProgress({
    reason: 'collecting',
    method: 'native-sniffer',
    status: fastScrollEnabled
      ? `Step-scrolling ${cfg.label.toLowerCase()} list for missing accounts...`
      : `Gentle scroll — ${cfg.label.toLowerCase()} tail (paced for overnight)...`
  });

  await scrollListToTop(tabId);
  await sleep(fastScrollEnabled ? 800 : 2000, { cancellable: true });
  if (isJobCancelled()) return 0;

  for (let step = 0; step < maxSteps && !isJobCancelled() && listFetchNeedsMore(type, totalList); step += 1) {
    await scrollListStep(tabId);
    await sleep(await sleepAfterScrollStep(type, 'tail'), { cancellable: true });
    if (isJobCancelled()) return totalAdded;

    const native = await waitForNativeList(tabId, cfg.opName, seq, listenMs);
    let added = 0;
    if (native) {
      added = addNativeUsers(native, seen, profile.username, type);
      if (native.seq) seq = Math.max(seq, native.seq);
    }

    if (added > 0) {
      totalAdded += added;
      stalePasses = 0;
      trimListToFetchLimit(type);
      const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
      notifyProgress({
        reason: 'collecting',
        method: 'native-sniffer',
        addedLastPage: added,
        status: `Tail scroll ${curList(type).length.toLocaleString()} / ${totalLabel} (+${added})`
      });
    } else {
      stalePasses += 1;
      if (stalePasses >= staleLimit) break;
    }
  }

  return totalAdded;
}

async function fetchListTailGraphql(tabId, profile, type, seen, totalList, captured) {
  const cfg = listCfg(type);
  let catalog = await buildGraphqlCatalog(tabId, type, false);
  let dropped404Recovery = false;
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;
  const listPath = await resolveListPagePath(tabId, profile.username, cfg.path);
  const gap = totalList != null ? totalList - curList(type).length : null;
  let cursor = await readNativeListCursorFromTab(tabId, cfg.opName);
  const spareCursors = (await readNativeListAllCursorsFromTab(tabId, cfg.opName)) || [];
  let spareCursorIdx = 0;
  let pages = 0;
  let totalAdded = 0;
  let staleCursorPasses = 0;

  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: `Tail GraphQL for ${gap != null ? gap.toLocaleString() : 'remaining'} ${cfg.label.toLowerCase()}...`
  });

  while (!isJobCancelled() && pages < 30 && listFetchNeedsMore(type, totalList)) {
    if (!cursor) {
      await scrollListToLoad(tabId);
      await sleep(fastScrollEnabled ? pageDelayMs * 2 : await sleepAfterScrollStep(type, 'tail'), { cancellable: true });
      if (isJobCancelled()) return totalAdded;
      cursor = await readNativeListCursorFromTab(tabId, cfg.opName);
      if (!cursor && spareCursorIdx < spareCursors.length) {
        cursor = spareCursors[spareCursorIdx];
        spareCursorIdx += 1;
      }
      if (!cursor) {
        staleCursorPasses += 1;
        if (staleCursorPasses >= 6) break;
        continue;
      }
    }

    const requestCount = graphqlRequestCount(type, totalList, curList(type).length);
    let res = await fetchListGraphqlPage(tabId, type, {
      opName: cfg.opName,
      listPath,
      userId: profile.userId,
      screenName: profile.username,
      cursor,
      count: requestCount,
      catalog
    }, {
      capturedTemplate: type === 'followers' ? null : (dropped404Recovery ? null : (captured || null)),
      retried: dropped404Recovery
    });

    if (
      !res?.ok
      && !dropped404Recovery
      && (res?.status === 404 || res?.status === 401 || /404|401|auth failed/i.test(res?.error || ''))
    ) {
      dropped404Recovery = true;
      catalog = await buildGraphqlCatalog(tabId, type, true);
      res = await fetchListGraphqlPage(tabId, type, {
        opName: cfg.opName,
        listPath,
        userId: profile.userId,
        screenName: profile.username,
        cursor,
        count: requestCount,
        catalog
      }, { capturedTemplate: null, retried: true });
    }

    if (!res?.ok) break;

    const parsedCount = (res.users || []).length;
    const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
    totalAdded += added;
    trimListToFetchLimit(type);

    const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
    const pageLabel = graphqlPageStatusLabel(type, totalList, curList(type).length, pages + 1, requestCount);
    notifyProgress({
      reason: 'collecting',
      method: 'graphql',
      addedLastPage: added,
      status: `Tail GraphQL ${curList(type).length.toLocaleString()} / ${totalLabel} (${pageLabel}, parsed ${parsedCount}, +${added})`
    });

    if (!listFetchNeedsMore(type, totalList)) break;

    const nextCursor = res.nextCursor || null;
    if (!nextCursor || nextCursor === cursor) {
      if (parsedCount > 0 && listFetchNeedsMore(type, totalList) && staleCursorPasses < 8) {
        staleCursorPasses += 1;
        await sleep(pageDelayMs, { cancellable: true });
    if (isJobCancelled()) break;
        continue;
      }
      staleCursorPasses += 1;
      cursor = null;
      if (staleCursorPasses >= 8) break;
      continue;
    }

    staleCursorPasses = 0;
    cursor = nextCursor;
    pages += 1;
    const tailDelay = requestCount === 1 ? Math.min(pageDelayMs, 450) : pageDelayMs;
    await sleep(tailDelay, { cancellable: true });
    if (isJobCancelled()) return totalAdded;
  }

  return totalAdded;
}

async function fetchListTailDom(tabId, profile, type, seen, totalList) {
  const cfg = listCfg(type);
  let totalAdded = 0;
  const settleMs = type === 'followers' ? 2200 : 1500;

  for (let pass = 0; pass < 2 && !isJobCancelled() && listFetchNeedsMore(type, totalList); pass += 1) {
    const gap = totalList != null ? totalList - curList(type).length : null;
    notifyProgress({
      reason: 'collecting',
      method: 'dom-scrape',
      status: `Bottom scan pass ${pass + 1} for ${gap != null ? gap.toLocaleString() : 'remaining'} ${cfg.label.toLowerCase()}...`
    });

    await scrollListToLoad(tabId);
    await sleep(fastScrollEnabled ? settleMs : await sleepAfterScrollStep(type, 'tail'), { cancellable: true });
    if (isJobCancelled()) return totalAdded;

    const scraped = await collectVisibleListUsersFromTab(tabId, profile.username);
    const added = addNativeUsers({ users: scraped?.users || [] }, seen, profile.username, type);
    totalAdded += added;
    trimListToFetchLimit(type);

    if (added > 0) {
      const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
      notifyProgress({
        reason: 'collecting',
        method: 'dom-scrape',
        addedLastPage: added,
        status: `DOM scan ${curList(type).length.toLocaleString()} / ${totalLabel} ${cfg.label.toLowerCase()} (+${added})`
      });
    }
  }

  return totalAdded;
}

async function fetchListTailGap(tabId, profile, type, seen, totalList, lastSeq = 0) {
  const cfg = listCfg(type);
  if (!listFetchNeedsMore(type, totalList)) return 0;

  const gap = totalList != null ? totalList - curList(type).length : null;
  if (gap == null || gap <= 0 || gap > 200) return 0;

  let totalAdded = 0;
  const captured = await readCapturedListTemplateFromTab(tabId, cfg.opName);

  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: `Short by ${gap.toLocaleString()} — finishing ${cfg.label.toLowerCase()} tail...`
  });

  const drained = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
  if (drained?.users?.length) {
    const queueAdded = addNativeUsers({ users: drained.users }, seen, profile.username, type);
    totalAdded += queueAdded;
    trimListToFetchLimit(type);
    if (queueAdded > 0) {
      const totalLabel = totalList.toLocaleString();
      notifyProgress({
        reason: 'collecting',
        method: 'native-sniffer',
        addedLastPage: queueAdded,
        status: `Queue drain ${curList(type).length.toLocaleString()} / ${totalLabel} (+${queueAdded})`
      });
    }
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList) && profile.userId) {
    totalAdded += await fetchListFinalPartialPage(tabId, profile, type, seen, totalList, captured);
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList) && profile.userId) {
    totalAdded += await fetchListTailCursorSweep(tabId, profile, type, seen, totalList, captured);
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList) && profile.userId) {
    totalAdded += await fetchListTailGraphql(tabId, profile, type, seen, totalList, captured);
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList)) {
    totalAdded += await fetchListTailScrollNative(tabId, profile, type, seen, totalList, lastSeq);
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList)) {
    totalAdded += await fetchListTailDom(tabId, profile, type, seen, totalList);
  }

  return totalAdded;
}

async function continueListFetchWithGraphql(tabId, profile, type, seen, fetchTarget, totalList, options = {}) {
  const cfg = listCfg(type);
  const opName = type === 'followers'
    ? await resolveFollowersWorkerOpName(tabId, cfg.opName)
    : cfg.opName;
  let userId = profile.userId;
  if (!userId) {
    const catalog = await prefetchQueryCatalog(false);
    userId = await resolveUserIdFromScreenName(profile.username, catalog);
    profile.userId = userId;
  }
  if (!userId) {
    console.warn('[X Cleaner] GraphQL continuation skipped — could not resolve userId');
    return 0;
  }

  if (!listFetchNeedsMore(type, totalList)) return 0;

  const subscriptionCap = subscriptionInfo.fetchLimit;
  let catalog = await buildGraphqlCatalog(tabId, type, true);
  const pageSize = graphqlListPageCount(type);
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;
  let cursor = options.restartFromTop ? null : await readNativeListCursorFromTab(tabId, opName);
  if (options.restartFromTop) {
    try {
      await scrollListToTop(tabId);
      await sleep(1200, { cancellable: true });
      if (isJobCancelled()) return totalAdded;
    } catch (error) {}
  }
  if (!cursor && seen.size > nativePageSize(type)) {
    await scrollListToLoad(tabId);
    await sleep(fastScrollEnabled ? pageDelayMs * 2 : await sleepAfterScrollStep(type, 'tail'), { cancellable: true });
    if (isJobCancelled()) return totalAdded;
    cursor = await readNativeListCursorFromTab(tabId, opName);
    if (!cursor) {
      const resumeCursors = (await readNativeListTailCursorsFromTab(tabId, opName, 4)) || [];
      if (resumeCursors.length > 0) {
        cursor = resumeCursors[resumeCursors.length - 1];
      }
    }
  }
  const captured = await readCapturedListTemplateFromTab(tabId, opName);
  const listPath = await resolveListPagePath(tabId, profile.username, cfg.path);
  let pages = 0;
  let totalAdded = 0;
  let cursorRetries = 0;
  const maxPages = 500;
  let dropped404Recovery = false;

  const startPlan = planGraphqlListFetch(type, totalList, curList(type).length);
  jobState.method = 'graphql';
  notifyProgress({
    reason: 'collecting',
    method: 'graphql',
    status: startPlan.totalPages != null
      ? `Collected ${curList(type).length.toLocaleString()} via native — GraphQL plan: ${startPlan.totalPages} page(s), ${startPlan.remaining.toLocaleString()} left${startPlan.tailSingleAccount ? ' (tail: 1/request)' : ''}...`
      : `Collected ${curList(type).length.toLocaleString()} via native — continuing with GraphQL pages...`
  });

  while (!isJobCancelled() && pages < maxPages) {
    if (!listFetchNeedsMore(type, totalList)) break;

    const requestCount = graphqlRequestCount(type, totalList, curList(type).length);
    const useCapturedTemplate = type !== 'followers'
      && !dropped404Recovery
      && pages === 0
      && !cursor
      && captured?.url;
    const fetchParams = {
      opName,
      listPath,
      userId,
      screenName: profile.username,
      cursor,
      count: requestCount,
      catalog
    };
    let res = await fetchListGraphqlPage(tabId, type, fetchParams, {
      capturedTemplate: useCapturedTemplate ? captured : null,
      retried: dropped404Recovery
    });

    if (
      !res?.ok
      && !dropped404Recovery
      && (res?.status === 404 || res?.status === 401 || /404|401|auth failed/i.test(res?.error || ''))
    ) {
      dropped404Recovery = true;
      catalog = await buildGraphqlCatalog(tabId, type, true);
      appendDebugStatusLog({
        reason: 'collecting',
        method: 'graphql',
        status: `GraphQL ${res?.status || 'error'} — retrying ${opName} in tab with live query id...`
      });
      res = await fetchListGraphqlPage(tabId, type, { ...fetchParams, catalog }, {
        capturedTemplate: null,
        retried: true
      });
    }

    if (!res?.ok) {
      console.warn('[X Cleaner] GraphQL page failed', res.error || res.status);
      notifyProgress({
        reason: 'collecting',
        method: 'graphql',
        status: `GraphQL failed: ${res?.error || `HTTP ${res?.status || 0}`}. Collected ${curList(type).length.toLocaleString()} so far.`
      });
      if (listFetchNeedsMore(type, totalList)) {
        // For followers, heavily prefer REST recoveries (which proved reliable) over more GraphQL
        if (type === 'followers') {
          totalAdded += await recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList, {
            maxPages: 20,
            scrollToLoad: true
          });
          const tailGap = totalList != null ? totalList - curList(type).length : null;
          if (listFetchNeedsMore(type, totalList) && tailGap != null && tailGap > 0) {
            totalAdded += await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
          }
          // Only try more GraphQL as last resort for followers
          if (listFetchNeedsMore(type, totalList) && tailGap != null && tailGap > 50) {
            totalAdded += await recoverShortfallViaTabGraphql(tabId, profile, type, seen, totalList, { skipWarmup: true });
          }
        } else {
          totalAdded += await recoverShortfallViaRestSnifferCursor(tabId, profile, type, seen, totalList, {
            maxPages: 16,
            scrollToLoad: true
          });
          const tailGap = totalList != null ? totalList - curList(type).length : null;
          if (listFetchNeedsMore(type, totalList) && tailGap != null && tailGap > 0 && tailGap <= 200) {
            totalAdded += await recoverShortfallViaRest(tabId, profile, type, seen, totalList);
          }
          if (listFetchNeedsMore(type, totalList)) {
            totalAdded += await recoverShortfallViaTabGraphql(tabId, profile, type, seen, totalList, { skipWarmup: true });
          }
        }
      }
      break;
    }

    const parsedCount = (res.users || []).length;
    const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
    totalAdded += added;
    trimListToFetchLimit(type);

    const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
    const dupes = Math.max(0, parsedCount - added);
    const dupNote = dupes > 0 ? `, ${dupes} dupes` : '';
    const srcNote = res.tabCount != null || res.workerCount != null
      ? ` [tab ${res.tabCount ?? 0}/worker ${res.workerCount ?? 0}]`
      : '';
    const pageLabel = graphqlPageStatusLabel(type, totalList, curList(type).length, pages + 1, requestCount);
    notifyProgress({
      reason: 'collecting',
      method: 'graphql',
      pages: pages + 1,
      parsedLastPage: parsedCount,
      dupLastPage: dupes,
      addedLastPage: added,
      fetchTarget,
      status: `GraphQL ${curList(type).length.toLocaleString()} / ${totalLabel} ${cfg.label.toLowerCase()} (${pageLabel}, parsed ${parsedCount}, +${added}${dupNote}${srcNote})`
    });

    if (subscriptionCap != null && curList(type).length >= subscriptionCap) break;

    const nextCursor = res.nextCursor || null;
    if (added === 0 && parsedCount > 0 && nextCursor && nextCursor !== cursor) {
      cursorRetries = 0;
      cursor = nextCursor;
      pages += 1;
      await sleep(requestCount === 1 ? Math.min(pageDelayMs, 450) : pageDelayMs, { cancellable: true });
      if (isJobCancelled()) break;
      continue;
    }

    if (!nextCursor || nextCursor === cursor) {
      const tailGap = totalList != null ? totalList - curList(type).length : null;
      const maxCursorRetries = tailGap != null && tailGap > 0
        ? (type === 'followers' ? 15 : 18)
        : (tailGap != null && tailGap <= 20 ? 12 : 3);
      if (listFetchNeedsMore(type, totalList) && cursorRetries < maxCursorRetries) {
        cursorRetries += 1;
        await scrollListToLoad(tabId);
        await sleep(pageDelayMs * 2, { cancellable: true });
      if (isJobCancelled()) break;
        const refreshed = await readNativeListCursorFromTab(tabId, opName);
        if (refreshed && refreshed !== cursor) {
          cursor = refreshed;
          continue;
        }
        continue;
      }
      if (listFetchNeedsMore(type, totalList)) {
        break;
      }
      break;
    }

    cursorRetries = 0;
    cursor = nextCursor;
    pages += 1;
    const tailDelay = requestCount === 1 ? Math.min(pageDelayMs, 450) : pageDelayMs;
    await sleep(tailDelay);
  }

  if (!options.skipPostRecovery && listFetchNeedsMore(type, totalList)) {
    const gap = totalList != null ? totalList - curList(type).length : null;
    if (gap != null && gap > 0) {
      notifyProgress({
        reason: 'collecting',
        method: 'graphql',
        status: `GraphQL paused — ${gap.toLocaleString()} short, running tail recovery...`
      });
      const tailAdded = await fetchListTailGap(tabId, profile, type, seen, totalList);
      totalAdded += tailAdded;
      if (
        listFetchNeedsMore(type, totalList)
        && !options.restartFromTop
        && gap > Math.max(12, Math.floor(nativePageSize(type) / 2))
        && profile.userId
      ) {
        totalAdded += await continueListFetchWithGraphql(
          tabId,
          profile,
          type,
          seen,
          fetchTarget,
          totalList,
          { restartFromTop: true, skipPostRecovery: true }
        );
      }
    }
  }

  return totalAdded;
}

async function runObserveListFetch(tabId, profile, type = listType) {
  const cfg = listCfg(type);
  const resolvedUsername = profile.username;
  const totalList = effectiveTotalList(type, profile);
  if (totalList != null) {
    profile[cfg.totalKey] = totalList;
    jobState[cfg.totalKey] = totalList;
  }

  const listUrl = `https://x.com/${resolvedUsername}/${cfg.path}`;
  await ensureSnifferInstalled(tabId);

  throwIfCancelled();
  await chrome.tabs.update(tabId, {
    url: listUrl,
    active: true
  });
  const listNavSettleMs = type === 'followers' ? XC_FOLLOWERS_NAV_SETTLE_MS : XC_LIST_NAV_SETTLE_MS;
  await waitAfterTabNavigation(tabId, listNavSettleMs);
  throwIfCancelled();
  await ensureSnifferInstalled(tabId);

  const listPageTotal = await scrapeListPageTotal(tabId, type);
  if (listPageTotal != null && (totalList == null || listPageTotal > totalList)) {
    profile[cfg.totalKey] = listPageTotal;
    jobState[cfg.totalKey] = listPageTotal;
  }

  const cachedCount = curList(type).length;
  const effectiveTotal = effectiveTotalList(type, profile);

  if (cachedCount > 0 && effectiveTotal != null && cachedCount >= effectiveTotal) {
    snapshotListRaw(type);
    jobState.isScraping = false;
    jobState.reason = 'complete';
    jobState.count = cachedCount;
    jobState.status = `Already have ${cachedCount.toLocaleString()} ${cfg.label.toLowerCase()} — skipping observe fetch`;
    notifyProgress({ status: jobState.status });
    schedulePersist(true, type);
    return;
  }

  appendDebugStatusLogStart({
    status: `Starting ${cfg.label} observe collection (gentle scroll + sniffer + DOM)`,
    reason: 'start',
    method: 'observe',
    listType: type
  });

  if (!cachedCount) {
    setCurList([], type);
    setCurRaw([], type);
  }
  listType = type;

  await sendHudMessage(tabId, {
    action: 'showHud',
    ...buildHudState({
      username: resolvedUsername,
      listType: type,
      totalFollowing: profile.totalFollowing,
      totalFollowers: profile.totalFollowers,
      count: cachedCount,
      isScraping: true,
      reason: 'collecting',
      method: 'observe',
      status: `Observe ${cfg.label.toLowerCase()} — gentle scroll, no REST bulk...`
    })
  }, 20);
  notifyProgress({
    reason: 'collecting',
    method: 'observe',
    status: `Observe ${cfg.label.toLowerCase()} — gentle scroll, no REST bulk...`
  });

  const seen = buildSeenFromCurList(type, resolvedUsername);
  let lastSeq = 0;
  let stalePasses = 0;
  let zeroParsePasses = 0;
  let passes = 0;
  let batchesWithAdds = 0;
  let tailRecoveryAttempts = 0;
  const fetchTarget = effectiveFetchTarget(effectiveTotal);

  await ensureProfileUserId(tabId, profile);

  try {
    await startListObserverFromTab(tabId, resolvedUsername);
  } catch (error) {}

  while (!isJobCancelled()) {
    const remaining = remainingListCount(type, effectiveTotal, fetchTarget);
    const listenMs = observeListenTimeoutMs(type, passes, remaining);
    let added = 0;
    let parsedLastBatch = 0;

    const native = await waitForNativeList(tabId, cfg.opName, lastSeq, listenMs);
    if (native) {
      parsedLastBatch += native.rawCount != null ? native.rawCount : (native.users || []).length;
      if (native.users?.length) {
        added += addNativeUsers(native, seen, resolvedUsername, type);
      }
      if (native.seq) lastSeq = Math.max(lastSeq, native.seq);
    }

    if (passes <= 1 && effectiveTotal != null && listFetchNeedsMore(type, effectiveTotal)) {
      try {
        const drained = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
        if (drained?.users?.length) {
          parsedLastBatch += drained.users.length;
          added += addNativeUsers({ users: drained.users }, seen, resolvedUsername, type);
          trimListToFetchLimit(type);
        }
      } catch (error) {}
    }

    // Early enrich on first data so the initial batch (what people test first, and free tier)
    // has the per-user counts, created dates and tweet numbers visible for verification.
    if (tabId && curList(type).length > 0 && passes <= 2) {
      ensureCoreProfileStats(tabId, type, null).catch(() => {});
    }

    try {
      const observed = await drainListObserverFromTab(tabId);
      if (observed?.users?.length) {
        parsedLastBatch += observed.users.length;
        added += addNativeUsers({ users: observed.users }, seen, resolvedUsername, type);
      }
    } catch (error) {}

    try {
      const domBatch = await collectVisibleListUsersLightFromTab(tabId, resolvedUsername);
      if (domBatch?.users?.length) {
        parsedLastBatch += domBatch.users.length;
        added += addNativeUsers({ users: domBatch.users }, seen, resolvedUsername, type);
      }
    } catch (error) {}

    trimListToFetchLimit(type);
    passes += 1;
    if (added > 0) {
      stalePasses = 0;
      zeroParsePasses = 0;
      batchesWithAdds += 1;
    } else {
      stalePasses += 1;
      if (parsedLastBatch === 0) zeroParsePasses += 1;
      else zeroParsePasses = 0;
    }

    const targetLabel = fetchTarget != null ? fetchTarget.toLocaleString() : '—';
    const capNote = subscriptionInfo.fetchLimit != null && !subscriptionInfo.isSubscribed
      ? ' (free limit)'
      : '';
    const atTail = nativeLikelyAtTail(type, curList(type).length, effectiveTotal);
    const tailNote = atTail ? ' [tail]' : '';
    let stuckNote = '';
    if (zeroParsePasses >= 3 && curList(type).length === 0) {
      try {
        const diag = await readObserveDiagnosticsFromTab(tabId, cfg.opName);
        if (diag) {
          stuckNote = ` — diag sniffer v${diag.snifferVersion || 0}, gql:${diag.capturedGql ? 'yes' : 'no'}, q:${diag.queueLen || 0}, raw:${diag.latestRaw || 0}, kept:${diag.latestKept || 0}, cells:${diag.userCells || 0}, root:${diag.listRoot ? 'yes' : 'no'}`;
        }
      } catch (error) {
        stuckNote = ' — hard-refresh x.com & open Following tab';
      }
    }
    notifyProgress({
      reason: 'collecting',
      method: 'observe',
      passes,
      pages: batchesWithAdds,
      parsedLastPage: parsedLastBatch,
      addedLastPage: added,
      fetchTarget,
      status: `Observe ${curList(type).length.toLocaleString()} / ${targetLabel}${capNote} ${cfg.label.toLowerCase()} (+${added}, parsed ${parsedLastBatch}${tailNote}${stuckNote})`
    });

    if (subscriptionInfo.fetchLimit != null && curList(type).length >= subscriptionInfo.fetchLimit) break;
    if (
      effectiveTotal != null &&
      curList(type).length >= effectiveTotal &&
      !nativeListLikelyHasMore(curList(type).length, effectiveTotal, type)
    ) {
      break;
    }

    const collected = curList(type).length;
    const gap = effectiveTotal != null ? effectiveTotal - collected : null;
    const staleLimit = nativeStalePassLimit(type, effectiveTotal, collected);
    const stillShort = listFetchNeedsMore(type, effectiveTotal);
    const followersGentleGap = type === 'followers' ? gentleFollowersRecoveryCap(effectiveTotal) : 25;
    if (atTail && stalePasses >= 3 && !stillShort) break;
    if (atTail && stillShort && gap != null && gap <= followersGentleGap && stalePasses >= 25) break;
    if (collected > 0 && stalePasses >= staleLimit && !stillShort) break;
    if (collected > 0 && stillShort && gap != null && gap <= followersGentleGap && stalePasses >= 30) break;
    if (passes > 2000) break;

    if (await observeTryGraphqlHandoff(tabId, profile, type, seen, fetchTarget, effectiveTotal, passes)) {
      break;
    }

    if (isJobCancelled() || !jobState.isScraping) break;

    const onListPage = await tabIsOnListPage(tabId, resolvedUsername, cfg.path);
    if (!onListPage) {
      if (isJobCancelled() || !jobState.isScraping) break;
      await chrome.tabs.update(tabId, { url: listUrl });
      await waitForTabComplete(tabId);
      await sleep(1200, { cancellable: true });
      if (isJobCancelled()) break;
      try {
        await startListObserverFromTab(tabId, resolvedUsername);
      } catch (error) {}
      continue;
    }

    if (
      stillShort &&
      gap != null &&
      gap <= (type === 'followers' ? Math.min(50, gentleFollowersRecoveryCap(effectiveTotal)) : 15) &&
      stalePasses >= 4 &&
      tailRecoveryAttempts < 3
    ) {
      tailRecoveryAttempts += 1;
      const recovered = await observeRecoverShortfall(tabId, profile, type, seen, effectiveTotal);
      if (recovered > 0) {
        stalePasses = 0;
        continue;
      }
    }

    const nudgeGap = type === 'followers' ? Math.min(60, gentleFollowersRecoveryCap(effectiveTotal)) : 25;
    if (stillShort && gap != null && gap <= nudgeGap && (stalePasses >= 2 || passes % 4 === 0)) {
      appendDebugStatusLog({
        reason: 'scroll-step',
        method: 'observe',
        status: `Observe tail nudge — scroll-to-load (${gap} short)`
      });
      await scrollListToLoad(tabId, { gap, aggressive: true });
    } else {
      await scrollListStep(tabId);
    }
    await sleep(observeLoopPaceMs(type, added), { cancellable: true });
    if (isJobCancelled()) break;
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, effectiveTotal)) {
    await observeFinishShortfall(tabId, profile, type, seen, effectiveTotal);
  }

  try {
    await stopListObserverFromTab(tabId);
  } catch (error) {}

  if (!isJobCancelled() && tabId) {
    try {
      await ensureCoreProfileStats(tabId, type, (prog) => {
        if (prog && prog.total) {
          notifyProgress({
            reason: 'collecting',
            status: `Enriching profile stats ${prog.processed || 0}/${prog.total}...`
          });
        }
      });
    } catch (e) {}
  }

  snapshotListRaw(type);
  jobState.isScraping = false;
  jobState.method = 'observe';
  jobState.count = curList(type).length;
  if (isJobCancelled()) {
    jobState.reason = 'stopped';
    if (!String(jobState.status || '').toLowerCase().includes('stopped')) {
      jobState.status = 'Stopped.';
    }
    appendDebugStatusLog({ status: jobState.status, reason: 'stopped' });
  } else {
    jobState.reason = curList(type).length > 0 ? 'complete' : 'observe-empty';
    const shortBy = effectiveTotal != null ? Math.max(0, effectiveTotal - curList(type).length) : 0;
    const isSmallGap = shortBy > 0 && (
      shortBy <= 20 ||
      (effectiveTotal > 0 && shortBy / effectiveTotal < 0.08)
    );
    jobState.status = curList(type).length > 0
      ? shortBy > 0
        ? isSmallGap
          ? `Observe complete — ${curList(type).length.toLocaleString()} ${cfg.label.toLowerCase()} (X profile reported ${effectiveTotal.toLocaleString()}; ${shortBy} may be deactivated/hidden)`
          : `Observe complete — ${curList(type).length.toLocaleString()} / ${effectiveTotal.toLocaleString()} ${cfg.label.toLowerCase()} (short by ${shortBy}; profile count may include hidden/deactivated accounts)`
        : `Observe complete — ${curList(type).length.toLocaleString()} ${cfg.label.toLowerCase()}`
      : 'Observe returned 0 — scroll the list manually, then retry';
  }
  persistDebugStatusLog();
  notifyProgress({ status: jobState.status, reason: jobState.reason, isScraping: false });
  schedulePersist(true, type);
}

async function runObserveExportFlowJob(tab, type, username) {
  const cfg = listCfg(type);
  const fetchMode = 'auto';

  assignJobState({
    username: username || null,
    listType: type,
    totalFollowing: null,
    totalFollowers: null,
    count: curList(type).length,
    isScraping: true,
    reason: 'loading-profile',
    method: 'observe',
    fetchMode
  });

  await ensureSnifferInstalled(tab.id);

  if (!username) {
    username = await detectHandle(tab.id);
    if (!username) {
      return {
        ok: false,
        error: 'Could not detect your X username. Open x.com/home or your profile, then try again.'
      };
    }
  }

  notifyProgress({ status: 'Opening profile for observe fetch...' });
  await chrome.tabs.update(tab.id, {
    url: `https://x.com/${username}`,
    active: true
  });
  await waitAfterTabNavigation(tab.id, XC_PROFILE_NAV_SETTLE_MS);
  throwIfCancelled();

  const profile = await scrapeProfileStats(tab.id, username);
  throwIfCancelled();

  jobState.username = profile.username || username;
  await alignAccountForJob(jobState.username);
  jobState.totalFollowing = profile.totalFollowing;
  jobState.totalFollowers = profile.totalFollowers;
  jobState.reason = 'profile-loaded';

  const totalForFetch = profile[cfg.totalKey];
  const resumeCount = curList(type).length;
  if (resumeCount > 0 && totalForFetch != null && resumeCount >= totalForFetch) {
    jobState.count = resumeCount;
    jobState.reason = 'complete';
    jobState.isScraping = false;
    jobState.status = `Already have ${resumeCount.toLocaleString()} ${cfg.label.toLowerCase()} — skipping fetch`;
    notifyProgress({ status: jobState.status });
    await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
    persistListState(type).catch(() => {});
    return {
      ok: true,
      ...jobState,
      count: resumeCount,
      mutuals: computeMutuals(),
      fetchMode,
      ...subscriptionPayload(),
      ...debugStatusPayload()
    };
  }

  const totalLabel = totalForFetch != null ? totalForFetch.toLocaleString() : '—';
  notifyProgress({
    status: `Logged in as @${jobState.username} • observe ${cfg.label.toLowerCase()} (${totalLabel}) — no REST bulk`
  });

  await runObserveListFetch(tab.id, profile, type);

  await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
  persistListState(type).catch(() => {});
  persistDebugStatusLog();
  return {
    ok: curList(type).length > 0,
    ...jobState,
    count: curList(type).length,
    mutuals: computeMutuals(),
    fetchMode,
    ...subscriptionPayload(),
    ...debugStatusPayload()
  };
}

async function runNativeListFetch(tabId, profile, type = listType) {
  const session = await getXSessionCookies();
  if (!session.loggedIn) {
    throw new Error('Not logged in to X. Open x.com, sign in, then try again.');
  }

  const cfg = listCfg(type);
  const resolvedUsername = profile.username;
  if (!profile.userId) {
    const catalog = await prefetchQueryCatalog(false);
    profile.userId = await resolveUserIdFromScreenName(resolvedUsername, catalog);
  }
  const totalList = effectiveTotalList(type, profile);
  if (totalList != null) {
    profile[cfg.totalKey] = totalList;
    jobState[cfg.totalKey] = totalList;
  }

  const resuming = curList(type).length > 0;
  if (!resuming) {
    await executeOnTab(tabId, (opName) => {
      try {
        sessionStorage.removeItem(`xc_list_queue_${opName}`);
        sessionStorage.removeItem(`xc_list_latest_${opName}`);
        sessionStorage.removeItem('xc_list_queue_BlueVerifiedFollowers');
        sessionStorage.removeItem('xc_list_latest_BlueVerifiedFollowers');
      } catch (error) {}
    }, [cfg.opName]);
  }

  const listUrl = `https://x.com/${resolvedUsername}/${cfg.path}`;
  await ensureSnifferInstalled(tabId);

  await chrome.tabs.update(tabId, {
    url: listUrl,
    active: true
  });
  await waitForTabComplete(tabId);
  await ensureSnifferInstalled(tabId);

  // Reload once so the timeline GraphQL request runs with the sniffer hooked.
  await executeOnTab(tabId, () => {
    location.reload();
  });
  const listNavSettleMs = type === 'followers' ? XC_FOLLOWERS_NAV_SETTLE_MS : XC_LIST_NAV_SETTLE_MS;
  await waitAfterTabNavigation(tabId, listNavSettleMs);
  await ensureSnifferInstalled(tabId);

  const listPageTotal = await scrapeListPageTotal(tabId, type);
  if (listPageTotal != null && (totalList == null || listPageTotal > totalList)) {
    totalList = listPageTotal;
    profile[cfg.totalKey] = listPageTotal;
    jobState[cfg.totalKey] = listPageTotal;
  }

  const cachedCount = curList(type).length;
  const tailResume = listResumeIsTailOnly(type, totalList);

  if (cachedCount > 0 && totalList != null && cachedCount >= totalList) {
    snapshotListRaw(type);
    jobState.isScraping = false;
    jobState.reason = 'complete';
    jobState.count = cachedCount;
    jobState.status = `Already have ${cachedCount.toLocaleString()} ${cfg.label.toLowerCase()} — skipping sniffer fetch`;
    notifyProgress({ status: jobState.status });
    schedulePersist(true, type);
    return;
  }

  appendDebugStatusLogStart({
    status: tailResume
      ? `Tail-only sniffer resume: ${cachedCount.toLocaleString()} / ${totalList?.toLocaleString() || '—'} ${cfg.label} cached`
      : `Starting ${cfg.label} collection (sniffer)`,
    reason: 'start',
    method: 'native-sniffer',
    listType: type
  });

  await sendHudMessage(tabId, {
    action: 'showHud',
    ...buildHudState({
      username: resolvedUsername,
      listType: type,
      totalFollowing: profile.totalFollowing,
      totalFollowers: profile.totalFollowers,
      count: cachedCount,
      isScraping: true,
      reason: 'waiting-native',
      method: 'native-sniffer',
      status: tailResume
        ? `Sniffer tail: ${cachedCount.toLocaleString()} / ${totalList?.toLocaleString() || '—'} ${cfg.label.toLowerCase()}...`
        : `Listening for X native ${cfg.label} responses...`
    })
  }, 20);

  if (!cachedCount) {
    setCurList([], type);
    setCurRaw([], type);
  }
  listType = type;
  const debugLogSnapshot = jobState.debugStatusLog;
  jobState = {
    username: resolvedUsername,
    listType: type,
    totalFollowing: profile.totalFollowing,
    totalFollowers: profile.totalFollowers,
    count: cachedCount,
    rawCount: curRaw(type).length || cachedCount,
    isScraping: true,
    reason: 'waiting-native',
    method: 'native-sniffer',
    status: hudState.status,
    debugStatusLog: debugLogSnapshot
  };
  notifyProgress();

  const seen = buildSeenFromCurList(type, resolvedUsername);
  let lastSeq = 0;
  let stalePasses = 0;
  let dupBatches = 0;
  let passes = 0;
  let batchesWithAdds = 0;
  const fetchTarget = effectiveFetchTarget(totalList);

  if (tailResume && totalList != null && profile.userId) {
    appendDebugStatusLog({
      status: `Sniffer tail-only: skipping full native sweep (${cachedCount}/${totalList})`,
      method: 'native-sniffer',
      reason: 'collecting'
    });
    await fetchListTailGap(tabId, profile, type, seen, totalList, lastSeq);
    if (!isJobCancelled() && listFetchNeedsMore(type, totalList)) {
      await recoverShortfallChain(tabId, profile, type, seen, totalList, { skipWarmup: true });
    }
    if (curList(type).length > 0) {
      trimListToFetchLimit(type);
      snapshotListRaw(type);
      jobState.isScraping = false;
      jobState.reason = isJobCancelled() ? 'stopped' : 'complete';
      jobState.count = curList(type).length;
      const shortBy = totalList != null ? Math.max(0, totalList - curList(type).length) : 0;
      jobState.status = shortBy > 0
        ? `Sniffer tail — ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} ${cfg.label.toLowerCase()} (short by ${shortBy})`
        : `Sniffer tail complete — ${curList(type).length.toLocaleString()} ${cfg.label.toLowerCase()}`;
      notifyProgress({ status: jobState.status });
      schedulePersist(true, type);
      return;
    }
  }

  while (!isJobCancelled()) {
    const remaining = remainingListCount(type, totalList, fetchTarget);
    const listenMs = nativeListenTimeoutMs(type, passes, remaining);
    const native = await waitForNativeList(
      tabId,
      cfg.opName,
      lastSeq,
      listenMs
    );
    let added = 0;
    let parsedLastBatch = 0;
    if (native) {
      const batchUsers = native.users || [];
      parsedLastBatch = batchUsers.length;
      if (batchUsers.length > 0) {
        added = addNativeUsers(native, seen, resolvedUsername, type);
        if (native.seq) lastSeq = Math.max(lastSeq, native.seq);
        if (added > 0) {
          dupBatches = 0;
          stalePasses = 0;
          batchesWithAdds += 1;
        } else {
          dupBatches += 1;
          stalePasses += 1;
        }
      } else if (native.seq) {
        lastSeq = Math.max(lastSeq, native.seq);
        stalePasses += 1;
      } else {
        stalePasses += 1;
      }
    } else {
      stalePasses += 1;
    }

    trimListToFetchLimit(type);
    passes += 1;

    const targetLabel = fetchTarget != null ? fetchTarget.toLocaleString() : '—';
    const capNote = subscriptionInfo.fetchLimit != null && !subscriptionInfo.isSubscribed
      ? ' (free limit)'
      : '';
    const dupes = Math.max(0, parsedLastBatch - added);
    const atTail = nativeLikelyAtTail(type, curList(type).length, totalList);
    const tailNote = atTail ? ' [tail]' : '';
    const staleNote = stalePasses > 0 ? `, stale ${stalePasses}` : '';
    const dupNote = dupes > 0 ? `, ${dupes} dupes` : '';
    notifyProgress({
      reason: 'collecting',
      method: 'native-sniffer',
      passes,
      pages: batchesWithAdds,
      parsedLastPage: parsedLastBatch,
      dupLastPage: dupes,
      addedLastPage: added,
      fetchTarget,
      status: `Native ${curList().length.toLocaleString()} / ${targetLabel}${capNote} ${cfg.label.toLowerCase()} (+${added}, parsed ${parsedLastBatch}${dupNote}${staleNote})${tailNote}`
    });

    if (subscriptionInfo.fetchLimit != null && curList(type).length >= subscriptionInfo.fetchLimit) break;
    if (
      totalList != null &&
      curList(type).length >= totalList &&
      !nativeListLikelyHasMore(curList(type).length, totalList, type)
    ) {
      break;
    }

    const collected = curList(type).length;
    if (atTail && (dupBatches >= 2 || stalePasses >= 3)) {
      appendDebugStatusLog({
        status: `Native tail detected at ${collected.toLocaleString()} — switching to GraphQL`,
        reason: 'collecting',
        method: 'native-sniffer'
      });
      notifyProgress({
        reason: 'collecting',
        method: 'graphql',
        status: `Native done at ${collected.toLocaleString()} (tail) — continuing via GraphQL...`
      });
      break;
    }

    const staleLimit = nativeStalePassLimit(type, totalList, collected);
    if (collected > 0 && stalePasses >= staleLimit) {
      appendDebugStatusLog({
        status: `Native stale limit (${stalePasses}/${staleLimit}) — switching to GraphQL`,
        reason: 'collecting',
        method: 'native-sniffer'
      });
      break;
    }
    if (passes > 2000) break;

    const onListPage = await tabIsOnListPage(tabId, resolvedUsername, cfg.path);
    if (!onListPage) {
      await chrome.tabs.update(tabId, { url: listUrl });
      await waitForTabComplete(tabId);
      await sleep(1200, { cancellable: true });
      if (isJobCancelled()) break;
      continue;
    }

    await scrollListToLoad(tabId);
    await sleep(await sleepAfterScrollStep(type, 'native-loop'), { cancellable: true });
    if (isJobCancelled()) break;
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList) && profile.userId) {
    await continueListFetchWithGraphql(tabId, profile, type, seen, fetchTarget, totalList);
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList)) {
    await fetchListTailGap(tabId, profile, type, seen, totalList, lastSeq);
  }

  if (!isJobCancelled() && listFetchNeedsMore(type, totalList) && profile.userId) {
    await recoverShortfallViaWorkerGraphql(tabId, profile, type, seen, totalList);
  }

  if (curList().length === 0) {
    if (isJobCancelled()) {
      jobState.isScraping = false;
      jobState.reason = 'stopped';
      notifyProgress({ status: 'Stopped.' });
      return;
    }
    throw new Error(
      `No ${cfg.label.toLowerCase()} accounts captured from X native responses. Reload the extension at chrome://extensions/, refresh the x.com tab once, then try again.`
    );
  }

  trimListToFetchLimit(type);
  snapshotListRaw(type);

  const reason = isJobCancelled() ? 'stopped' : 'complete';
  jobState.isScraping = false;
  jobState.reason = reason;
  restoredTypes[type] = false;

  const finalCount = curList(type).length;
  const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
  let doneStatus = `Collected ${finalCount.toLocaleString()} / ${totalLabel} ${cfg.label.toLowerCase()}.`;
  if (totalList != null && finalCount < totalList) {
    doneStatus += ` (${(totalList - finalCount).toLocaleString()} short of profile total — try Refresh or collect again.)`;
  } else if (nativeListLikelyHasMore(finalCount, totalList, type)) {
    doneStatus += ' (ends on a full page — more accounts may exist.)';
  }

  if (
    subscriptionInfo.fetchLimit != null &&
    fetchTarget != null &&
    finalCount >= fetchTarget &&
    (totalList == null || fetchTarget < totalList)
  ) {
    doneStatus = `Free tier limit reached (${XC_FREE_FETCH_LIMIT}). Resets every 24 hours — export up to ${XC_FREE_FETCH_LIMIT} records anytime.`;
  }

  notifyProgress({
    status: `DONE — ${doneStatus}`,
    reason: 'complete',
    method: jobState.method || 'native-sniffer'
  });
  persistDebugStatusLog();
  schedulePersist(true, type);
}

function buildFilterClientResponse(extra = {}) {
  const payload = {
    ok: extra.ok !== false,
    ...buildHudState(),
    ...extra
  };
  if (extra.error) {
    payload.ok = false;
    payload.error = extra.error;
    payload.status = extra.error;
    payload.reason = payload.reason || 'error';
  }
  return normalizeClientState(payload);
}

function finishEmptyFilter(type = listType) {
  setCurList([], type);
  activeEnrich = null;
  jobState.filterRemoved = curRaw(type).length;
  jobState.reason = 'filtered';
  jobState.isEnriching = false;
  jobState.isScraping = false;
  jobState.filterPhase = null;
  jobState.enrichProcessed = 0;
  jobState.enrichTotal = 0;
  jobState.count = 0;
  notifyProgress({
    reason: 'filtered',
    isScraping: false,
    isEnriching: false,
    status: `Filtered: 0 remaining after filters (0 / ${curRaw(type).length.toLocaleString()} qualified as inactive / unfollow candidates). Original data is preserved in the raw snapshot — use "clear filters" or switch list to restore the full list.`
  });
  schedulePersist(true, type);
  return buildFilterClientResponse({
    count: 0,
    rawCount: curRaw(type).length,
    removed: jobState.filterRemoved
  });
}

async function applyInactiveLastPostFilter(working, type, inactiveMonths, jobTabId) {
  const inactiveLabel = listCfg(type).label.toLowerCase();
  const candidateLabel = 'unfollow candidates'; // last post filter is following-only
  const activityCache = await loadActivityCache();
  const now = Date.now();
  syncWorkingFromRaw(working, type);

  const parts = partitionInactiveFilterCandidates(working, inactiveMonths, activityCache, now, type);
  // Note: inactiveMonths comes from UI input (not hardcoded 6); passed to both last-post cutoff and age pre-qual (tooYoung).
  const inactiveByKey = new Map();
  const rememberInactive = (user) => {
    const key = (user.username || '').toLowerCase();
    if (!key || inactiveByKey.has(key)) return;
    inactiveByKey.set(key, user);
  };

  for (const user of parts.resolvedInactive) rememberInactive(user);

  const agePhaseStatus = parts.needsLookup.length > 0
    ? `Last post (${inactiveMonths} mo): ${parts.resolvedInactive.length.toLocaleString()} ${candidateLabel} by account age — checking last tweet for ${parts.needsLookup.length.toLocaleString()} more...`
    : `Last post (${inactiveMonths} mo): ${parts.resolvedInactive.length.toLocaleString()} ${candidateLabel} by account age — no last-tweet lookups needed`;

  setCurList(Array.from(inactiveByKey.values()), type);
  jobState.filterPhase = 'inactive-age';
  notifyProgress({
    reason: 'filtering',
    filterPhase: 'inactive-age',
    isEnriching: false,
    enrichProcessed: parts.resolvedInactive.length,
    enrichTotal: parts.resolvedInactive.length + parts.needsLookup.length,
    status: agePhaseStatus
  });

  let enrichCancelled = false;
  if (parts.needsLookup.length > 0) {
    activeEnrich = { running: true, cancelled: false };
    jobState.isEnriching = true;
    jobState.reason = 'enriching';
    jobState.filterPhase = 'inactive';
    jobState.enrichTotal = parts.needsLookup.length;
    jobState.enrichProcessed = 0;

    try {
      const enriched = await enrichLastActiveForUsers(jobTabId, parts.needsLookup, type, {
        batchSize: INACTIVE_LOOKUP_BATCH_SIZE,
        batchDelayMs: INACTIVE_LOOKUP_DELAY_MS,
        onProgress: (progress) => {
          const status = progress.waiting
            ? `Last post (${inactiveMonths} mo): ${inactiveByKey.size.toLocaleString()} by account age — pausing… last-tweet ${progress.processed.toLocaleString()} / ${progress.total.toLocaleString()}`
            : `Last post (${inactiveMonths} mo): ${inactiveByKey.size.toLocaleString()} by account age — last-tweet ${progress.processed.toLocaleString()} / ${progress.total.toLocaleString()}`;
          notifyProgress({
            reason: 'enriching',
            isEnriching: true,
            enrichProcessed: progress.processed,
            enrichTotal: progress.total,
            status
          });
        }
      });

      for (const user of enriched) {
        if (classifyInactiveAfterLookup(user, parts.cutoffMs)) {
          rememberInactive(user);
        }
      }

      // Sync last_active dates for ALL freshly looked-up accounts back to the main list (raw + live)
      // so that enrichment results are stored for the full list (and visible/exported), not just the filtered inactive ones.
      for (const user of enriched) {
        if (user.last_active_ms !== undefined) {
          const rawRow = findRawUserByHandle(type, user.username);
          if (rawRow && (rawRow.last_active_ms == null || rawRow.last_active_ms === undefined)) {
            rawRow.last_active_ms = user.last_active_ms;
          }
          const live = findListUserByHandle(type, user.username);
          if (live && (live.last_active_ms == null || live.last_active_ms === undefined)) {
            live.last_active_ms = user.last_active_ms;
          }
        }
      }

      // Transfer newly hydrated last_active_ms for any mutuals also to the followers list
      // (so hydration picked up for mutuals during last-post filter transfers to followers set as well)
      try {
        const followersUsers = usersForMutuals('followers');
        const fMap = new Map(followersUsers.map(u => [(u.username || '').toLowerCase(), u]));
        for (const user of enriched) {
          if (user.last_active_ms != null) {
            const k = (user.username || '').toLowerCase();
            const fUser = fMap.get(k);
            if (fUser && fUser.last_active_ms == null) {
              fUser.last_active_ms = user.last_active_ms;
              const fLive = findListUserByHandle('followers', k);
              if (fLive && fLive.last_active_ms == null) fLive.last_active_ms = user.last_active_ms;
              const fRaw = findRawUserByHandle('followers', k);
              if (fRaw && fRaw.last_active_ms == null) fRaw.last_active_ms = user.last_active_ms;
            }
          }
        }
      } catch (e) {}

      enrichCancelled = !!activeEnrich?.cancelled;
    } finally {
      activeEnrich = null;
      jobState.isEnriching = false;
    }
  }

  if (enrichCancelled) {
    syncLastActiveIntoRaw(Array.from(inactiveByKey.values()), type);
    setCurList(Array.from(inactiveByKey.values()), type);
    schedulePersist(true, type);
    return { cancelled: true };
  }

  const finalInactive = Array.from(inactiveByKey.values());
  syncLastActiveIntoRaw(finalInactive, type);
  setCurList(finalInactive, type);
  schedulePersist(true, type);

  const removedYoung = parts.tooYoung.length;
  const removedActive = parts.resolvedActive.length;
  const lookupUnresolved = parts.needsLookup.filter(
    (user) => !inactiveByKey.has((user.username || '').toLowerCase())
  ).length;

  const summaryParts = [];
  if (removedYoung > 0) summaryParts.push(`too new (${removedYoung.toLocaleString()})`);
  if (removedActive > 0) summaryParts.push(`active (${removedActive.toLocaleString()})`);
  if (lookupUnresolved > 0) summaryParts.push(`no tweet date (${lookupUnresolved.toLocaleString()})`);

  return {
    cancelled: false,
    working: finalInactive,
    removedYoung,
    removedActive,
    lookupUnresolved,
    summaryParts,
    inactiveLabel,
    candidateLabel
  };
}

async function filterList(options = {}) {
  if (options.listType && LIST_CONFIG[options.listType]) {
    await setListType(options.listType);
  }

  await ensureEnrichArchiveLoaded();

  const type = listType;
  const source = curRaw(type).length ? curRaw(type) : curList(type);
  if (!source.length) {
    return buildFilterClientResponse({
      ok: false,
      error: `No ${listCfg(type).label.toLowerCase()} collected yet.`
    });
  }

  if (isListTypeSwitchLocked()) {
    return buildFilterClientResponse({
      ok: false,
      error: 'Wait until collection finishes before filtering.'
    });
  }

  jobState.isScraping = false;

  if (activeEnrich?.running) {
    return buildFilterClientResponse({
      ok: false,
      error: 'Activity lookup already running.'
    });
  }

  if (!curRaw(type).length) {
    snapshotListRaw(type);
  }

  const handoff = await ensureFilterHudHandoff(options, type);
  if (!handoff.ok) return handoff;

  if (options.handoffAfterHud) {
    void filterList({ ...options, handoffAfterHud: false }).catch((error) => {
      if (isCancelledError(error)) {
        void finishStoppedJob('Stopped.', { notifyHud: false });
        return;
      }
      jobState.reason = 'error';
      const errorText = String(error?.message || error);
      notifyProgress({ status: errorText, error: errorText, reason: 'error' });
    });
    return attachHudReady({
      ok: true,
      ...normalizeClientState(getStatus())
    }, true);
  }

  const filterHudReady = handoff.hudReady;
  throwIfCancelled();

  try {
  const removeBlue = !!options.removeBlue;
  let removeInactive = !!options.removeInactive;
  const removeMutuals = !!options.removeMutuals;
  const botCheck = !!options.botCheck;
  const inactiveMonths = normalizeInactiveMonths(options.inactiveMonths);

  if (removeInactive && type !== 'following') {
    notifyProgress({
      status: 'Last post filter applies to Following only — skipped on Followers.'
    });
    removeInactive = false;
  }

  if (!removeBlue && !removeInactive && !removeMutuals && !botCheck) {
    setCurList(curRaw(type).slice(), type);
    jobState.filterRemoved = 0;
    jobState.appliedFilters = [];
    jobState.reason = curList(type).length ? 'complete' : jobState.reason;
    jobState.filterPhase = null;
    notifyProgress({ status: `${curList(type).length.toLocaleString()} accounts ready (filters cleared).` });
    schedulePersist(true, type);
    return attachHudReady(buildFilterClientResponse({
      removed: 0
    }), filterHudReady);
  }

  let working = curRaw(type).slice();
  const parts = [];
  const appliedFilters = [];
  jobState.appliedFilters = appliedFilters;
  jobState.reason = 'filtering';
  jobState.isEnriching = false;
  jobState.enrichProcessed = 0;
  jobState.enrichTotal = 0;

  if (removeMutuals) {
    throwIfCancelled();
    await ensureRestored();
    const ctx = buildMutualFilterContext(type);
    const otherCfg = listCfg(ctx.otherType);

    if (!mutualDetectionAvailable(type, ctx)) {
      return buildFilterClientResponse({
        ok: false,
        error: `Remove mutuals needs ${otherCfg.label} collected (or relationship flags on this list). Fetch ${otherCfg.label.toLowerCase()} first.`
      });
    }

    const refresh = refreshMutualFlagsFromOtherList(type);
    if (refresh.upgraded > 0) {
      appendDebugStatusLog({
        status: `Filter: merged mutual flags from ${otherCfg.label.toLowerCase()} on ${refresh.upgraded.toLocaleString()} accounts`,
        method: jobState.method || 'filter',
        reason: 'filtering'
      });
    }

    const beforeMutuals = working.length;
    working = excludeMutuals(working, type, ctx);
    const mutualsRemoved = beforeMutuals - working.length;
    if (mutualsRemoved > 0) {
      parts.push(`non-mutuals (${mutualsRemoved.toLocaleString()} mutuals removed)`);
    }
    jobState.filterPhase = 'mutuals';
    notifyProgress({
      reason: 'filtering',
      filterPhase: 'mutuals',
      status: mutualsRemoved > 0
        ? `Remove mutuals: ${working.length.toLocaleString()} remaining (−${mutualsRemoved.toLocaleString()})`
        : `Remove mutuals: 0 removed (${beforeMutuals.toLocaleString()} accounts — none matched mutuals)`
    });
    if (!working.length) return finishEmptyFilter(type);
    appliedFilters.push('non_mutuals');
  }

  if (removeBlue) {
    throwIfCancelled();
    const blueMerged = await refreshBlueFlagsFromSniffer(type);
    if (blueMerged > 0) {
      syncWorkingFromRaw(working, type);
      appendDebugStatusLog({
        status: `Filter: sniffer merged is_blue on ${blueMerged.toLocaleString()} ${listCfg(type).label.toLowerCase()}`,
        method: jobState.method || 'filter',
        reason: 'filtering'
      });
    }

    const before = working.length;
    working = applyRemoveBlueFilter(working);
    setCurList(working, type);
    jobState.filterRemoved = curRaw(type).length - working.length;
    jobState.filterPhase = 'blue';
    jobState.reason = 'filtering';
    const removed = before - working.length;
    if (removed > 0) parts.push(`non-blue (${removed.toLocaleString()} verified removed)`);
    const blueHint = removed === 0 && before > 0
      ? ` (0/${before.toLocaleString()} flagged verified — open your ${listCfg(type).label.toLowerCase()} tab on X, then filter again)`
      : '';
    notifyProgress({
      reason: 'filtering',
      filterPhase: 'blue',
      isEnriching: false,
      status: `Remove verified: ${working.length.toLocaleString()} remaining (−${removed.toLocaleString()})${blueHint}`
    });
    if (!working.length) return finishEmptyFilter(type);
    appliedFilters.push('non_blue');
  }

  if (removeInactive) {
    throwIfCancelled();
    await ensureRestored();
    refreshMutualFlagsFromOtherList(type); // transfer any last_active hydration for mutuals across lists
    if (!(await ensureJobTabId())) {
      return buildFilterClientResponse({
        ok: false,
        error: 'No X tab available for activity lookup.'
      });
    }

    const inactiveResult = await applyInactiveLastPostFilter(
      working,
      type,
      inactiveMonths,
      jobTabId
    );
    if (inactiveResult.cancelled) {
      return await finishStoppedJob();
    }

    working = inactiveResult.working;
    if (inactiveResult.summaryParts.length) {
      parts.push(...inactiveResult.summaryParts);
    }
    jobState.filterRemoved = curRaw(type).length - working.length;
    jobState.filterPhase = 'inactive';
    notifyProgress({
      reason: 'filtering',
      filterPhase: 'inactive',
      isEnriching: false,
      enrichProcessed: working.length,
      enrichTotal: working.length,
      status: `Last post (${inactiveMonths} mo): ${working.length.toLocaleString()} ${inactiveResult.candidateLabel}${inactiveResult.summaryParts.length ? ` (−${inactiveResult.summaryParts.join(', ')})` : ''}`
    });
    if (!working.length) return finishEmptyFilter(type);
    appliedFilters.push('inactive');
  }

  if (botCheck) {
    throwIfCancelled();
    if (type !== 'followers') {
      notifyProgress({
        status: 'Bot check applies to Followers — skipped on Following.'
      });
    } else {
      await ensureRestored();
      const mutualCtx = buildMutualFilterContext('followers');
      const followingCfg = listCfg('following');

      if (!mutualDetectionAvailable('followers', mutualCtx)) {
        return buildFilterClientResponse({
          ok: false,
          error: 'Bot check needs you_follow on follower rows (included in a REST Followers fetch) or a Following list to cross-check. Re-fetch Followers if relationship flags are missing.'
        });
      }

      const mutualRefresh = refreshMutualFlagsFromOtherList('followers');
      if (mutualRefresh.upgraded > 0) {
        appendDebugStatusLog({
          status: `Bot check: filled you_follow from ${followingCfg.label.toLowerCase()} on ${mutualRefresh.upgraded.toLocaleString()} accounts`,
          method: jobState.method || 'filter',
          reason: 'filtering'
        });
      }

      const youFollowSkipped = working.filter((user) => isYouFollowingAccount(user, mutualCtx)).length;
      let candidates = working.filter((user) => !isYouFollowingAccount(user, mutualCtx));

      if (!(await ensureJobTabId())) {
        return buildFilterClientResponse({
          ok: false,
          error: 'No X tab available for bot-check profile enrichment.'
        });
      }

      const sparseCount = candidates.filter((user) => !hasReliableProfileForBotCheck(user)).length;
      let enrichCancelled = false;

      if (sparseCount > 0) {
        activeEnrich = { running: true, cancelled: false };
        jobState.isEnriching = true;
        jobState.reason = 'enriching';
        jobState.filterPhase = 'bot-enrich';
        jobState.enrichTotal = sparseCount;
        jobState.enrichProcessed = 0;
        notifyProgress({
          reason: 'enriching',
          isEnriching: true,
          enrichProcessed: 0,
          enrichTotal: sparseCount,
          status: `Bot check: enriching ${sparseCount.toLocaleString()} sparse profiles (sniffer first, then batched lookup)...`
        });

        try {
          const enrichResult = await ensureReliableProfilesForBotCheck(
            jobTabId,
            type,
            candidates,
            (progress) => {
              const status = progress.waiting
                ? `Waiting… enriched ${progress.processed.toLocaleString()} / ${progress.total.toLocaleString()} sparse profiles`
                : `Profile enrich ${progress.processed.toLocaleString()} / ${progress.total.toLocaleString()}...`;
              notifyProgress({
                reason: 'enriching',
                isEnriching: true,
                enrichProcessed: progress.processed,
                enrichTotal: progress.total,
                status
              });
            }
          );
          candidates = enrichResult.users;
          const { stats } = enrichResult;
          if (stats.snifferMerged > 0 || stats.lookupUpgraded > 0) {
            appendDebugStatusLog({
              status: `Bot enrich: sniffer ${stats.snifferMerged.toLocaleString()} field merges, lookup upgraded ${stats.lookupUpgraded.toLocaleString()} / ${stats.lookedUp.toLocaleString()} sparse`,
              method: jobState.method || 'filter',
              reason: 'filtering'
            });
          }
          enrichCancelled = !!activeEnrich?.cancelled;
        } finally {
          activeEnrich = null;
          jobState.isEnriching = false;
        }

        if (enrichCancelled) {
          working = candidates;
          setCurList(working, type);
          return await finishStoppedJob();
        }
      }

      const beforeBots = candidates.length;
      working = candidates.filter((user) => isPotentialBot(user));
      setCurList(working, type);
      const nonBotRemoved = beforeBots - working.length;
      if (nonBotRemoved > 0) {
        parts.push(`non-bot (${nonBotRemoved.toLocaleString()})`);
      }
      if (youFollowSkipped > 0) {
        parts.push(`you-follow skipped (${youFollowSkipped.toLocaleString()})`);
      }
      jobState.filterRemoved = curRaw(type).length - working.length;
      jobState.filterPhase = 'bot';
      const youFollowHint = youFollowSkipped > 0
        ? `, −${youFollowSkipped.toLocaleString()} you-follow`
        : '';
      notifyProgress({
        reason: 'filtering',
        filterPhase: 'bot',
        isEnriching: false,
        status: `Bot check: ${working.length.toLocaleString()} potential bots kept (−${nonBotRemoved.toLocaleString()} non-bot${youFollowHint})`
      });
      if (!working.length) return finishEmptyFilter(type);
      appliedFilters.push('bot');
    }
  }

  setCurList(working, type);
  jobState.filterRemoved = curRaw(type).length - curList(type).length;
  jobState.appliedFilters = appliedFilters.slice();
  jobState.reason = 'filtered';
  jobState.filterPhase = null;
  jobState.isEnriching = false;
  jobState.count = curList(type).length;

  notifyProgress({
    status: `Filtered: ${curList(type).length.toLocaleString()} remaining after filters (removed ${jobState.filterRemoved.toLocaleString()} from the original ${curRaw(type).length.toLocaleString()} in raw${parts.length ? ` — ${parts.join(', ')}` : ''})`
  });
  schedulePersist(true, type);

  return buildFilterClientResponse({
    removed: jobState.filterRemoved
  });
  } catch (error) {
    activeEnrich = null;
    jobState.isEnriching = false;
    if (isCancelledError(error)) {
      return await finishStoppedJob('Stopped.', { notifyHud: false });
    }
    throw error;
  }
}

async function resolveUsernameForFetch(tabId, fallbackUsername = null) {
  const candidates = [
    fallbackUsername,
    tabId ? await detectHandle(tabId) : null,
    jobState.username,
    subscriptionInfo?.lastHandle
  ];

  for (const value of candidates) {
    const handle = String(value || '').replace(/^@+/, '').trim();
    if (handle) return handle;
  }

  return null;
}

async function resolveProfileViaTab(tabId, username) {
  const handle = String(username || '').replace(/^@+/, '');
  if (!tabId || !handle) return null;

  let totalFollowing = null;
  let totalFollowers = null;
  let userId = null;
  try {
    await ensureSnifferInstalled(tabId);

    const onProfile = await executeOnTab(tabId, (sn) => {
      const p = (location.pathname || '').toLowerCase();
      const base = `/${String(sn || '').replace(/^@+/, '').toLowerCase()}`;
      return p === base
        || p.startsWith(`${base}/`)
        || p.includes('/followers')
        || p.includes('/following');
    }, [handle]);

    if (!onProfile) {
      await chrome.tabs.update(tabId, { url: `https://x.com/${handle}`, active: true });
      await waitForTabComplete(tabId);
      await sleep(XC_PROFILE_NAV_SETTLE_MS);
      await ensureSnifferInstalled(tabId);
    }

    const scraped = await scrapeProfileStats(tabId, handle);
    totalFollowing = scraped.totalFollowing ?? null;
    totalFollowers = scraped.totalFollowers ?? null;
    userId = scraped.userId ?? null;
  } catch (error) {}

  const catalog = await prefetchQueryCatalog(false);

  if (!userId) {
    userId = await resolveUserIdFromScreenName(handle, catalog, tabId);
  }

  return {
    username: handle,
    userId: userId || null,
    totalFollowing,
    totalFollowers
  };
}

async function resolveProfileViaRest(fallbackUsername, tabId = null) {
  const session = await getXSessionCookies();
  if (!session.loggedIn) {
    throw new Error('Not logged in to X. Open x.com, sign in, then try again.');
  }

  const attempts = [];
  const cookies = await xcRestCollectAllCookies();
  let userIdFromCookie = xcRestParseUserIdFromCookies(cookies);
  const username = await resolveUsernameForFetch(tabId, fallbackUsername);

  if (tabId) {
    await ensureSnifferInstalled(tabId);
    const existingBearer = await xcRestReadBearerFromTab(tabId);
    if (!existingBearer) {
      await warmRestBearer(tabId);
    }
    await xcRestPrepareSession(tabId);
  }

  try {
    const creds = await xcRestVerifyCredentials({ tabId });
    appendDebugStatusLog({
      status: `REST verify_credentials OK — @${creds.screenName || fallbackUsername || '?'}`,
      method: 'rest-v1.1',
      reason: 'profile-loaded'
    });
    return {
      username: creds.screenName || fallbackUsername,
      userId: creds.userId,
      totalFollowing: creds.friendsCount ?? null,
      totalFollowers: creds.followersCount ?? null
    };
  } catch (error) {
    attempts.push(`verify_credentials: ${error.attemptSummary || error.message}`);
  }

  if (username) {
    try {
      const show = await xcRestUsersShow(username, { tabId });
      appendDebugStatusLog({
        status: `REST users/show OK — @${show.screenName} (verify_credentials unavailable)`,
        method: 'rest-v1.1',
        reason: 'profile-loaded'
      });
      return {
        username: show.screenName || username,
        userId: show.userId,
        totalFollowing: show.friendsCount ?? null,
        totalFollowers: show.followersCount ?? null
      };
    } catch (error) {
      attempts.push(`users/show: ${error.attemptSummary || error.message}`);
    }
  }

  let totalFollowing = null;
  let totalFollowers = null;
  let resolvedUserId = userIdFromCookie || null;

  if (tabId && username) {
    const tabProfile = await resolveProfileViaTab(tabId, username);
    if (tabProfile?.username) {
      totalFollowing = tabProfile.totalFollowing ?? totalFollowing;
      totalFollowers = tabProfile.totalFollowers ?? totalFollowers;
      resolvedUserId = tabProfile.userId || resolvedUserId;
    } else {
      attempts.push('tab: profile page scrape failed');
    }
  } else if (!username) {
    attempts.push('no username detected — open x.com/home while logged in');
  }

  if (username && tabId) {
    let probeOk = false;
    const probeBearer = await xcRestWaitForBearer(tabId, { maxMs: 12000 });
    if (probeBearer) {
      await sleep(2000, { cancellable: true });
      if (isJobCancelled()) return null;
      await xcRestPrepareSession(tabId);
    } else {
      attempts.push('list probe: bearer not captured yet (open x.com/home, wait for feed)');
    }
    for (const probeType of ['following', 'followers']) {
      if (!probeBearer) break;
      try {
        const probe = await xcRestFetchListPage(username, probeType, '-1', {
          tabId,
          pageSize: 5,
          preferTabContext: true,
          tabRetries: 2
        });
        const probeCount = probe.rawCount ?? probe.users?.length ?? 0;
        const winnerFailed = (probe?.attempts || []).some((line) => {
          const text = typeof line === 'string'
            ? line
            : `${line.strategy || ''}: ${line.error || line.detail || ''}`;
          const strategy = probe?.strategy || '';
          if (strategy && !text.includes(strategy.replace('tab@', ''))) return false;
          return /tab@x\.com:.*(authenticate you|Unauthorized|Forbidden)/i.test(text)
            || /tab:.*(authenticate you|Unauthorized|Forbidden)/i.test(text);
        });
        if (probe?.strategy && (probeCount > 0 || !winnerFailed)) {
          appendDebugStatusLog({
            status: `REST list probe OK — @${username} (${probe.strategy}, ${probeType}, ${probeCount} users on probe page)`,
            method: 'rest-v1.1',
            reason: 'profile-loaded'
          });
          probeOk = true;
          break;
        }
        if (probe?.attempts?.length) {
          attempts.push(`${probeType} probe: ${xcRestFormatAttempts(probe.attempts || [])}`);
        } else {
          attempts.push(`${probeType} probe: empty response`);
        }
      } catch (error) {
        attempts.push(`${probeType} probe: ${error.attemptSummary || error.message}`);
      }
    }
    if (probeOk) {
      return {
        username,
        userId: resolvedUserId,
        totalFollowing,
        totalFollowers
      };
    }
  }

  if (username) {
    appendDebugStatusLog({
      status: `REST profile: @${username} (account API blocked; list probe did not return users yet)`,
      method: 'rest-v1.1',
      reason: 'profile-loaded'
    });
    return {
      username,
      userId: resolvedUserId,
      totalFollowing,
      totalFollowers
    };
  }

  const summary = attempts.join(' | ');
  const err = new Error(
    `REST profile resolution failed. ${summary} — open x.com while logged in, or use Auto mode.`
  );
  err.attemptSummary = summary;
  appendDebugStatusLog({
    status: err.message,
    method: 'rest-v1.1',
    reason: 'error',
    error: err.message
  });
  throw err;
}

async function resolveProfileForFastFetch(tabId, fallbackUsername) {
  return resolveProfileViaRest(fallbackUsername, tabId);
}

async function runGraphqlWorkerListFetch(tabId, profile, type = listType) {
  const cfg = listCfg(type);
  const totalList = profile[cfg.totalKey] ?? jobState[cfg.totalKey] ?? null;
  const fetchTarget = effectiveFetchTarget(totalList);
  const seen = buildSeenFromCurList(type, profile.username);

  let userId = profile.userId;
  if (!userId) {
    const catalog = await prefetchQueryCatalog(false);
    userId = await resolveUserIdFromScreenName(profile.username, catalog);
    profile.userId = userId;
  }
  if (!userId) {
    throw new Error('Could not resolve user id for GraphQL worker fetch.');
  }

  const session = await getXSessionCookies();
  if (!session.ct0) {
    throw new Error('Missing ct0 cookie for GraphQL worker fetch.');
  }

  const catalog = await prefetchQueryCatalog(false);
  const opName = type === 'followers'
    ? (await resolveFollowersWorkerOpName(tabId, cfg.opName))
    : cfg.opName;
  const pageDelayMs = GRAPHQL_PAGE_DELAY_MS[type] || 600;
  let cursor = null;

  const tailResume = listResumeIsTailOnly(type, totalList);
  appendDebugStatusLogStart({
    status: tailResume
      ? `Tail-only GraphQL worker resume: ${curList(type).length.toLocaleString()} / ${totalList?.toLocaleString() || '—'} ${cfg.label} cached`
      : `Starting GraphQL worker ${cfg.label} collection`,
    reason: 'start',
    method: 'graphql-worker',
    listType: type
  });

  const opCandidates = type === 'followers'
    ? await followersWorkerOpCandidates(tabId)
    : [opName];

  jobState = {
    ...jobState,
    username: profile.username,
    listType: type,
    totalFollowing: profile.totalFollowing ?? jobState.totalFollowing,
    totalFollowers: profile.totalFollowers ?? jobState.totalFollowers,
    count: curList(type).length,
    isScraping: true,
    reason: 'collecting',
    method: 'graphql-worker',
    status: tailResume
      ? `GraphQL tail: ${curList(type).length.toLocaleString()} / ${totalList?.toLocaleString() || '—'} ${cfg.label.toLowerCase()}...`
      : `GraphQL worker: ${cfg.label} via ${opCandidates.join(' → ')} (${graphqlListPageCount(type)}/page)...`
  };

  if (tabId) {
    await sendHudMessage(tabId, { action: 'showHud', ...buildHudState() }, 12);
  }
  notifyProgress({ status: jobState.status });

  let activeOpName = opCandidates[0];
  let pages = 0;

  for (let opIdx = 0; opIdx < opCandidates.length && !isJobCancelled(); opIdx += 1) {
    activeOpName = opCandidates[opIdx];
    cursor = null;
    pages = 0;
    let gotUsers = false;

    if (opIdx > 0) {
      appendDebugStatusLog({
        status: `GraphQL worker switching to ${activeOpName}...`,
        reason: 'collecting',
        method: 'graphql-worker'
      });
      notifyProgress({
        status: `GraphQL worker retry with ${activeOpName}...`,
        method: 'graphql-worker'
      });
    }

    while (!isJobCancelled() && pages < 500) {
      if (!listFetchNeedsMore(type, totalList)) break;

      const requestCount = graphqlRequestCount(type, totalList, curList(type).length);
      const res = await fetchListPageWorker({
        opName: activeOpName,
        userId,
        screenName: profile.username,
        cursor,
        count: requestCount,
        catalog,
        ct0: session.ct0,
        listPath: cfg.path
      });

      if (!res?.ok) {
        if (pages === 0 && opIdx < opCandidates.length - 1) break;
        throw new Error(res.error || `GraphQL worker failed (HTTP ${res.status || 0})`);
      }

      const parsedCount = (res.users || []).length;
      const added = addNativeUsers({ users: res.users || [] }, seen, profile.username, type);
      trimListToFetchLimit(type);
      pages += 1;
      if (parsedCount > 0) gotUsers = true;

      const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
      notifyProgress({
        reason: 'collecting',
        method: 'graphql-worker',
        pages,
        addedLastPage: added,
        status: `GraphQL worker ${activeOpName} p${pages}: ${curList(type).length.toLocaleString()} / ${totalLabel} (+${added}, parsed ${parsedCount})`
      });

      if (fetchTarget != null && curList(type).length >= fetchTarget) break;

      const nextCursor = res.nextCursor || null;
      if (!nextCursor || nextCursor === cursor) {
        if (added === 0 && parsedCount === 0) break;
        if (!nextCursor) break;
      }

      if (added === 0 && parsedCount === 0) break;

      cursor = nextCursor;
      await sleep(requestCount === 1 ? Math.min(pageDelayMs, 450) : pageDelayMs, { cancellable: true });
      if (isJobCancelled()) break;
    }

    if (gotUsers || curList(type).length > 0 || !listFetchNeedsMore(type, totalList)) break;
  }

  snapshotListRaw(type);
  jobState.isScraping = false;
  jobState.reason = curList(type).length > 0 ? 'complete' : 'rest-empty';
  jobState.method = 'graphql-worker';
  jobState.count = curList(type).length;
  jobState.status = curList(type).length > 0
    ? `GraphQL worker complete — ${curList(type).length.toLocaleString()} ${cfg.label.toLowerCase()} (${pages} pages, ${activeOpName})`
    : `GraphQL worker returned 0 (${opCandidates.join(' → ')})`;
  notifyProgress({ status: jobState.status });

  return {
    ok: curList(type).length > 0,
    count: curList(type).length,
    pages,
    method: 'graphql-worker',
    opName: activeOpName
  };
}

async function warmRestBearer(tabId) {
  await ensureSnifferInstalled(tabId);
  const existing = await xcRestReadBearerFromTab(tabId);
  if (existing && existing.length > 20) return existing;

  try {
    const tab = await chrome.tabs.get(tabId);
    if (!isXTabUrl(tab?.url)) {
      await chrome.tabs.update(tabId, { url: 'https://x.com/home' });
      await waitForTabComplete(tabId);
    } else if (!/\/home|\/i\//.test(tab.url || '')) {
      await chrome.tabs.update(tabId, { url: 'https://x.com/home' });
      await waitForTabComplete(tabId);
    } else {
      await executeOnTab(tabId, () => {
        location.reload();
      });
      await waitForTabComplete(tabId);
    }
    await sleep(XC_PRE_LIST_FETCH_SETTLE_MS);
    await ensureSnifferInstalled(tabId);
    await xcRestPrepareSession(tabId);
  } catch (error) {}

  return xcRestReadBearerFromTab(tabId);
}

async function runRestListFetch(tabId, profile, type = listType, options = {}) {
  const cfg = listCfg(type);
  const totalList = profile[cfg.totalKey] ?? jobState[cfg.totalKey] ?? null;
  const fetchTarget = effectiveFetchTarget(totalList);
  const restPageSize = totalList != null && totalList > 0 && totalList <= XC_REST_PAGE_SIZE
    ? totalList
    : XC_REST_PAGE_SIZE;
  const cachedCount = curList(type).length;
  const tailOnly = !!(
    options.tailOnly
    || (cachedCount > 0 && totalList != null && cachedCount < totalList)
  );
  const seen = buildSeenFromCurList(type, profile.username);

  appendDebugStatusLogStart({
    status: tailOnly
      ? `Tail-only resume: ${cachedCount.toLocaleString()} / ${totalList?.toLocaleString() || '—'} ${cfg.label} cached`
      : `Starting REST ${cfg.label} collection`,
    reason: 'start',
    method: 'rest-v1.1',
    listType: type
  });

  jobState = {
    ...jobState,
    username: profile.username,
    listType: type,
    totalFollowing: profile.totalFollowing ?? jobState.totalFollowing,
    totalFollowers: profile.totalFollowers ?? jobState.totalFollowers,
    count: cachedCount,
    isScraping: true,
    reason: 'collecting',
    method: 'rest-v1.1',
    status: tailOnly
      ? `Tail fetch: ${cachedCount.toLocaleString()} / ${totalList?.toLocaleString() || '—'} ${cfg.label.toLowerCase()}...`
      : `REST fetch: ${cfg.label} (${restPageSize}/page)...`
  };

  if (tabId) {
    await sendHudMessage(tabId, {
      action: 'showHud',
      ...buildHudState()
    }, 12);
  }
  notifyProgress({ status: jobState.status });

  if (tabId) {
    await ensureSnifferInstalled(tabId);
    await warmRestListPageContext(tabId, profile, type);
    let bearer = await xcRestResolveBearer(tabId, { requireCaptured: true });
    if (!bearer) {
      await warmRestBearer(tabId);
      bearer = await xcRestResolveBearer(tabId, { requireCaptured: true });
    }
    appendDebugStatusLog({
      status: bearer
        ? `REST session ready (captured bearer, ${bearer.length} chars)`
        : 'REST session not ready — open x.com/home, wait for feed, then retry',
      method: 'rest-v1.1'
    });
    if (!bearer) {
      throw new Error('No captured X bearer token. Open x.com/home, let the feed load (triggers API calls), then retry REST fetch.');
    }

    try {
      const preDrain = await readNativeListQueueDrainFromTab(tabId, cfg.opName);
      if (preDrain?.users?.length) {
        const preAdded = addNativeUsers({ users: preDrain.users }, seen, profile.username, type);
        const blueMerged = mergeSnifferFieldsIntoList(preDrain.users, type, profile.username);
        trimListToFetchLimit(type);
        const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
        const blueNote = blueMerged > 0 ? `, ${blueMerged} is_blue merged` : '';
        notifyProgress({
          reason: 'collecting',
          method: 'rest-v1.1',
          addedLastPage: preAdded,
          status: preAdded > 0
            ? `Sniffer pre-load: ${curList(type).length.toLocaleString()} / ${totalLabel} (+${preAdded}${blueNote})`
            : `Sniffer pre-load: ${preDrain.users.length} captured, ${preAdded} new (already had ${curList(type).length}${blueNote})`
        });
      }
    } catch (error) {}
  }

  // Early core stats enrich for the first visible batch (testers + free users want
  // to verify counts, created date, tweet numbers right away from the first pages).
  if (tabId && curList(type).length > 0) {
    ensureCoreProfileStats(tabId, type, null).catch(() => {});
  }

  if (tailOnly) {
    let result = {
      collected: curList(type).length,
      pages: 0,
      shortfall: totalList != null ? Math.max(0, totalList - curList(type).length) : 0,
      attemptSummary: 'tail-resume'
    };
    if (totalList != null && curList(type).length < totalList && tabId) {
      const chain = await recoverShortfallChain(tabId, profile, type, seen, totalList, { skipWarmup: true });
      if (chain.summary) {
        result.attemptSummary = `tail-resume (${chain.summary})`;
      }
      result.collected = curList(type).length;
      result.shortfall = Math.max(0, totalList - curList(type).length);
    }
    snapshotListRaw(type);
    jobState.isScraping = false;
    jobState.reason = curList(type).length > 0 ? 'complete' : 'rest-empty';
    jobState.method = 'rest-v1.1';
    jobState.count = curList(type).length;
    jobState.restAttemptSummary = result.attemptSummary || null;
    const shortBy = result.shortfall || 0;
    jobState.status = curList(type).length > 0
      ? shortBy > 0
        ? `REST tail — ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} ${cfg.label.toLowerCase()} (short by ${shortBy})`
        : `REST tail complete — ${curList(type).length.toLocaleString()} ${cfg.label.toLowerCase()}`
      : `REST tail returned 0 — ${result.attemptSummary || 'no new users'}`;
    notifyProgress({ status: jobState.status });
    persistListState(type).catch(() => {});
    return {
      ok: curList(type).length > 0,
      count: curList(type).length,
      pages: result.pages,
      method: 'rest-v1.1',
      attemptSummary: result.attemptSummary || null
    };
  }

  let result;
  const restAlreadyComplete = totalList != null && curList(type).length >= totalList;
  try {
    if (restAlreadyComplete) {
      result = {
        collected: curList(type).length,
        pages: 0,
        shortfall: 0,
        attemptSummary: 'sniffer pre-load'
      };
    } else {
    result = await xcRestFetchFullList(profile.username, type, {
      pageSize: restPageSize,
      pageDelayMs: XC_REST_PAGE_DELAY_MS,
      maxUsers: fetchTarget,
      knownTotal: totalList,
      userId: profile.userId,
      tabId,
      shouldCancel: () => isJobCancelled(),
      onPage: async (info) => {
        throwIfCancelled();

        if (info.rateLimited) {
          notifyProgress({
            reason: 'collecting',
            method: 'rest-v1.1',
            status: `Rate limited — waiting ${Math.round((info.waitingMs || 0) / 1000)}s...`
          });
          return;
        }

        const added = addNativeUsers({ users: info.users || [] }, seen, profile.username, type);
        trimListToFetchLimit(type);

        let blueMerged = 0;
        if (tabId) {
          await pacedNudgeTabScroll(tabId, info.page % 2 === 0 ? 1100 : 650);
          blueMerged = await upgradeListFromSnifferDrain(tabId, type, profile.username);
        }

        const totalLabel = totalList != null ? totalList.toLocaleString() : '—';
        const strategyNote = info.strategy ? ` [${info.strategy}]` : '';
        const recoveryNote = info.shortfallRecovery
          ? ` (tail recovery${info.shortfallLabel ? `: ${info.shortfallLabel}` : ''})`
          : '';
        const blueNote = blueMerged > 0 ? `, ${blueMerged} is_blue` : '';
        notifyProgress({
          reason: 'collecting',
          method: 'rest-v1.1',
          addedLastPage: added,
          restPage: info.page,
          status: `REST page ${info.page}: ${curList(type).length.toLocaleString()} / ${totalLabel} (+${added}${blueNote})${strategyNote}${recoveryNote}`
        });
      }
    });
    }
  } catch (error) {
    if (curList(type).length > 0) {
      result = {
        collected: curList(type).length,
        pages: jobState.restPage || 1,
        shortfall: totalList != null ? Math.max(0, totalList - curList(type).length) : 0,
        partialError: error.message || String(error),
        attemptSummary: error.attemptSummary || error.message || null
      };
    } else {
      throw error;
    }
  }

  if (isJobCancelled()) {
    // stop immediately, do not continue to recovery passes
    jobState.isScraping = false;
    jobState.reason = 'stopped';
    jobState.status = 'Stopped.';
    notifyProgress({ reason: 'stopped', isScraping: false });
    return { ok: true, count: curList(type).length, reason: 'stopped' };
  }

  let shortBy = totalList != null && curList(type).length < totalList
    ? totalList - curList(type).length
    : (result.shortfall || 0);

  if (shortBy > 0 && shortBy <= 100 && tabId) {
    const runChain = () => recoverShortfallChain(tabId, profile, type, seen, totalList, { skipWarmup: true });
    const chain = shortBy <= 20
      ? await withFastScrollRecoveryBoost(runChain)
      : await runChain();
    if (chain.totalAdded > 0) {
      shortBy = totalList != null ? Math.max(0, totalList - curList(type).length) : 0;
      const tailNote = `shortfall (${chain.summary})`;
      result.attemptSummary = result.attemptSummary
        ? `${result.attemptSummary} | ${tailNote}`
        : tailNote;
    }
  }

  if (shortBy > 0 && shortBy <= 20 && tabId && listFetchNeedsMore(type, totalList)) {
    const tailAdded = await withFastScrollRecoveryBoost(
      () => fetchListTailGap(tabId, profile, type, seen, totalList)
    );
    if (tailAdded > 0) {
      shortBy = Math.max(0, totalList - curList(type).length);
      const tailNote = `final tail-gap:+${tailAdded}`;
      result.attemptSummary = result.attemptSummary
        ? `${result.attemptSummary} | ${tailNote}`
        : tailNote;
    }
  }

  if (tabId) {
    try {
      if (fastScrollEnabled) {
        await executeOnTab(tabId, () => window.scrollTo(0, Math.max(document.body.scrollHeight, 2400)));
        await sleep(700, { cancellable: true });
      } else {
        await scrollListStep(tabId);
        await sleep(await sleepAfterScrollStep(type, 'nudge'), { cancellable: true });
      }
      if (isJobCancelled()) { /* will be caught higher or finalize as stopped */ }
      const blueMerged = await upgradeListFromSnifferDrain(tabId, type, profile.username);
      if (blueMerged > 0) {
        appendDebugStatusLog({
          status: `Sniffer final merge: is_blue on ${blueMerged.toLocaleString()} accounts`,
          method: 'rest-v1.1',
          reason: 'collecting'
        });
      }
    } catch (error) {}
  }

  if (!isJobCancelled() && tabId) {
    try {
      await ensureCoreProfileStats(tabId, type, (prog) => {
        if (prog && prog.total) {
          notifyProgress({
            reason: 'collecting',
            status: `Enriching profile stats ${prog.processed || 0}/${prog.total}...`
          });
        }
      });
    } catch (e) {}
  }

  if (isJobCancelled()) {
    snapshotListRaw(type);
    jobState.isScraping = false;
    jobState.reason = 'stopped';
    jobState.status = 'Stopped.';
    jobState.method = 'rest-v1.1';
    notifyProgress({ reason: 'stopped', isScraping: false });
    return { ok: true, count: curList(type).length, reason: 'stopped' };
  }

  snapshotListRaw(type);
  jobState.isScraping = false;
  jobState.reason = curList(type).length > 0 ? 'complete' : 'rest-empty';
  jobState.method = 'rest-v1.1';
  jobState.count = curList(type).length;
  jobState.restAttemptSummary = result.attemptSummary || null;
  const authBlocked = /authenticate you|page does not exist|Unauthorized|Forbidden/i.test(result.attemptSummary || '');
  const partialNote = result.partialError ? `; page error: ${result.partialError}` : '';
  jobState.status = curList(type).length > 0
    ? shortBy > 0
      ? `REST complete — ${curList(type).length.toLocaleString()} / ${totalList.toLocaleString()} ${cfg.label.toLowerCase()} (${result.pages} pages; short by ${shortBy}${partialNote})`
      : `REST complete — ${curList(type).length.toLocaleString()} ${cfg.label.toLowerCase()} (${result.pages} pages${partialNote})`
    : authBlocked
      ? `REST v1.1 blocked for this session (${result.attemptSummary || 'auth failed'}) — use Auto mode`
      : `REST returned 0 — ${result.attemptSummary || 'all strategies empty'}`;
  notifyProgress({ status: jobState.status });

  return {
    ok: curList(type).length > 0,
    count: curList(type).length,
    pages: result.pages,
    method: 'rest-v1.1',
    attemptSummary: result.attemptSummary || null
  };
}

async function runExportFlow(requestedType = listType, options = {}) {
  if (activeFetch?.running) {
    return { ok: false, error: 'Collection already running.' };
  }
  if (jobState.isScraping || jobLooksBusy()) {
    return { ok: false, error: 'Collection already running.' };
  }
  if (activeFetch?.cancelled || jobCancelled) {
    activeFetch = null;
    jobCancelled = false;
  }

  if (options.fastScroll != null) {
    await setFastScrollPref(!!options.fastScroll);
  } else {
    await loadFastScrollPref();
  }
  gentleScrollStepCount = 0;

  const type = LIST_CONFIG[requestedType] ? requestedType : listType;
  const cfg = listCfg(type);
  const fetchMode = normalizeFetchMode(options.fetchMode || (await getFetchMode()));

  const tab = await findFocusedXTab();
  if (!tab?.id) {
    return { ok: false, error: 'No X tab found. Open x.com in a browser tab first.' };
  }

  jobTabId = tab.id;
  listType = type;
  jobState.listType = type;
  jobState.fetchMode = fetchMode;
  jobState.isScraping = true;
  jobState.reason = 'collecting';
  jobState.method = null;

  let username = await detectHandle(tab.id);
  await alignAccountForJob(username || '');
  await ensureEnrichArchiveLoaded();

  if (options.forceRefresh) {
    await archiveListEnrichment(type);
    setCurList([], type);
    setCurRaw([], type);
    restoredTypes[type] = false;
    await clearListPersist(type);
    if (type === listType) {
      jobState.count = 0;
      jobState.rawCount = 0;
      jobState.savedAt = null;
    }
  } else {
    await restoreListState(type);
    if (!curList(type).length) {
      await restoreListState(type, { username });
    }
  }

  const cachedCount = curList(type).length;

  resetDebugStatusLog({
    status: options.forceRefresh
      ? `Fresh start — cleared cached ${cfg.label.toLowerCase()} (${fetchMode} mode)`
      : cachedCount > 0
        ? `Resuming — ${cachedCount.toLocaleString()} ${cfg.label} cached (${fetchMode} mode)`
        : `Collection started — ${fetchMode} mode, ${cfg.label}`,
    reason: 'start',
    fetchMode,
    listType: type
  });

  await refreshSubscription(username, false);

  const hudReady = await ensureHudShown(tab.id, {
    isScraping: true,
    reason: 'start',
    listType: type,
    username: jobState.username || username || null,
    count: cachedCount,
    fetchMode,
    status: options.forceRefresh
      ? `Fresh start — ${cfg.label.toLowerCase()}...`
      : cachedCount > 0
        ? `Resuming — ${cachedCount.toLocaleString()} ${cfg.label.toLowerCase()}...`
        : `Starting ${cfg.label.toLowerCase()} collection...`
  });

  if (options.handoffAfterHud) {
    if (!hudReady) {
      return {
        ok: false,
        hudReady: false,
        error: 'Could not open the on-page HUD on your X tab. Refresh x.com and try again.',
        ...getStatus()
      };
    }
    void runExportFlowJob(tab, type, options, username).catch((error) => {
      if (isCancelledError(error)) {
        void finishStoppedJob();
        return;
      }
      jobState.isScraping = false;
      jobState.reason = 'error';
      const errorText = String(error?.message || error);
      const errorDetail = error?.attemptSummary ? `${errorText} (${error.attemptSummary})` : errorText;
      jobState.status = errorDetail;
      notifyProgress({ status: errorDetail, error: errorDetail, reason: 'error' });
      persistDebugStatusLog();
      activeFetch = null;
    });
    return {
      ok: true,
      hudReady: true,
      isScraping: true,
      ...getStatus()
    };
  }

  return runExportFlowJob(tab, type, options, username);
}

async function runExportFlowJob(tab, type, options, username) {
  const cfg = listCfg(type);
  const fetchMode = normalizeFetchMode(options.fetchMode || jobState.fetchMode || (await getFetchMode()));

  try {
    jobCancelled = false;
    activeFetch = { running: true, cancelled: false };

    let useObservePath = !fastScrollEnabled && fetchMode === 'auto';

    // If the target list (or either) is <500 from profile, do the fastest possible for the *first* get.
    // Gentle observe's first pass often only captures ~35 for followers. For small lists a full REST page is fine and stealthy.
    if (useObservePath) {
      try {
        const u = username || await detectHandle(tab.id);
        if (u) {
          const prof = await resolveProfileViaRest(u, tab.id);
          const followingT = prof?.totalFollowing || 0;
          const followersT = prof?.totalFollowers || 0;
          const thisT = (type === 'followers' ? followersT : followingT);
          if ((followingT > 0 && followingT < 500) || (followersT > 0 && followersT < 500) || (thisT > 0 && thisT < 500)) {
            useObservePath = false;
            appendDebugStatusLog({
              reason: 'start',
              status: `Small list (<500) — forcing fastest initial fetch (full REST) for the first get`
            });
          }
        }
      } catch (e) {}
    }

    appendDebugStatusLog({
      reason: 'start',
      fetchMode,
      method: useObservePath ? 'observe' : 'rest-v1.1',
      status: useObservePath
        ? 'Gentle mode — observe path (no REST bulk)'
        : 'Fast mode — auto REST → GraphQL → sniffer'
    });
    notifyProgress({
      status: useObservePath
        ? 'Gentle mode — observe collection (no REST bulk)...'
        : 'Fast mode — REST collection...',
      reason: 'collecting',
      isScraping: true,
      method: useObservePath ? 'observe' : 'rest-v1.1'
    });

    if (useObservePath) {
      return await runObserveExportFlowJob(tab, type, username);
    }

    let profile = null;
    let fastFetchSucceeded = false;

    if (fetchMode === 'rest' || fetchMode === 'auto') {
      jobState = {
        username: username || null,
        listType: type,
        totalFollowing: null,
        totalFollowers: null,
        count: 0,
        isScraping: true,
        reason: 'loading-profile',
        method: 'rest-v1.1',
        fetchMode
      };
      notifyProgress({ status: 'Resolving session (REST profile)...' });
      await ensureSnifferInstalled(tab.id);

      try {
        profile = await resolveProfileForFastFetch(tab.id, username);
        username = profile.username || username;
        jobState.username = username;
        await alignAccountForJob(username);

        jobState.totalFollowing = profile.totalFollowing;
        jobState.totalFollowers = profile.totalFollowers;
        jobState.reason = 'profile-loaded';

        const totalForFetch = profile[cfg.totalKey];
        const totalLabel = totalForFetch != null ? totalForFetch.toLocaleString() : '—';
        const resumeCount = curList(type).length;
        const tailOnly = resumeCount > 0
          && totalForFetch != null
          && resumeCount < totalForFetch;

        if (resumeCount > 0 && totalForFetch != null && resumeCount >= totalForFetch) {
          jobState.count = resumeCount;
          jobState.reason = 'complete';
          jobState.isScraping = false;
          jobState.status = `Already have ${resumeCount.toLocaleString()} ${cfg.label.toLowerCase()} — skipping fetch`;
          notifyProgress({ status: jobState.status });
          fastFetchSucceeded = true;
          await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
          persistListState(type).catch(() => {});
          return {
            ok: true,
            ...jobState,
            count: resumeCount,
            mutuals: computeMutuals(),
            fetchMode,
            ...subscriptionPayload(),
            ...debugStatusPayload()
          };
        }

        notifyProgress({
          status: tailOnly
            ? `Logged in as @${username} • tail fetch ${cfg.label.toLowerCase()} (${resumeCount}/${totalLabel})`
            : `Logged in as @${username} • REST fetch ${cfg.label.toLowerCase()} (${totalLabel})`
        });

        const restResult = await runRestListFetch(tab.id, profile, type, { tailOnly });

        if (restResult.ok) {
          fastFetchSucceeded = true;
          await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
          return {
            ok: true,
            ...jobState,
            count: curList().length,
            mutuals: computeMutuals(),
            fetchMode,
            ...subscriptionPayload(),
            ...debugStatusPayload()
          };
        }

        if (fetchMode === 'auto') {
          notifyProgress({
            status: curList(type).length > 0
              ? `REST short (${restResult.attemptSummary || 'partial'}) — tail via GraphQL worker...`
              : `REST empty (${restResult.attemptSummary || 'no users'}) — trying GraphQL worker...`
          });
          resetListForFreshFallback(type);

          const gqlResult = await runGraphqlWorkerListFetch(tab.id, profile, type);
          if (gqlResult.ok) {
            fastFetchSucceeded = true;
            await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
            return {
              ok: true,
              ...jobState,
              count: curList().length,
              mutuals: computeMutuals(),
              fetchMode,
              ...subscriptionPayload(),
              ...debugStatusPayload()
            };
          }

          notifyProgress({
            status: curList(type).length > 0
              ? 'GraphQL worker short — finishing tail via native sniffer...'
              : 'GraphQL worker returned 0 — falling back to native sniffer...'
          });
          resetListForFreshFallback(type);
        } else {
          await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
          return {
            ok: false,
            error: restResult.attemptSummary
              ? `REST fetch returned no accounts (${restResult.attemptSummary}).`
              : 'REST fetch returned no accounts.',
            ...jobState,
            count: curList().length,
            mutuals: computeMutuals(),
            fetchMode,
            ...subscriptionPayload(),
            ...debugStatusPayload()
          };
        }
      } catch (restError) {
        if (fetchMode === 'rest') {
          throw restError;
        }

        notifyProgress({
          status: curList(type).length > 0
            ? `REST failed (${restError.message}) — tail via GraphQL worker...`
            : `REST failed (${restError.message}) — trying GraphQL worker...`
        });
        resetListForFreshFallback(type);

        try {
          if (!profile?.userId && !profile?.username) {
            profile = await resolveProfileForFastFetch(tab.id, username);
            username = profile.username || username;
            jobState.username = username;
          }
          const gqlResult = await runGraphqlWorkerListFetch(tab.id, profile, type);
          if (gqlResult.ok) {
            fastFetchSucceeded = true;
            await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
            return {
              ok: true,
              ...jobState,
              count: curList().length,
              mutuals: computeMutuals(),
              fetchMode,
              ...subscriptionPayload(),
              ...debugStatusPayload()
            };
          }
        } catch (gqlError) {
          notifyProgress({
            status: `GraphQL worker failed (${gqlError.message}) — falling back to native sniffer...`
          });
        }

        resetListForFreshFallback(type);
        profile = profile || null;
      }
    }

    if (fetchMode === 'sniffer' || (fetchMode === 'auto' && !fastFetchSucceeded)) {
      if (!username) {
        username = await detectHandle(tab.id);
        if (!username) {
          return {
            ok: false,
            error: 'Could not detect your X username. Open x.com/home or your profile, then try again.'
          };
        }
      }

      jobState = {
        username,
        listType: type,
        totalFollowing: profile?.totalFollowing ?? null,
        totalFollowers: profile?.totalFollowers ?? null,
        count: curList(type).length,
        isScraping: true,
        reason: 'loading-profile',
        method: 'native-sniffer',
        fetchMode
      };
      await sendHudMessage(tab.id, {
        action: 'showHud',
        ...buildHudState({ status: 'Opening your profile...' })
      }, 8);
      notifyProgress({ status: 'Opening your profile...' });

      throwIfCancelled();

      await chrome.tabs.update(tab.id, {
        url: `https://x.com/${username}`,
        active: true
      });
      await waitAfterTabNavigation(tab.id, XC_PROFILE_NAV_SETTLE_MS);
      throwIfCancelled();

      profile = await scrapeProfileStats(tab.id, username);
      throwIfCancelled();
      if (!profile.userId) {
        const catalog = await prefetchQueryCatalog(false);
        profile.userId = await resolveUserIdFromScreenName(profile.username || username, catalog);
      }
      const totalForFetch = profile[cfg.totalKey];
      if (totalForFetch == null && profile.userId == null) {
        throw new Error('Could not read your profile on X. Confirm you are logged in and try again.');
      }

      jobState = {
        username: profile.username || username,
        listType: type,
        totalFollowing: profile.totalFollowing,
        totalFollowers: profile.totalFollowers,
        count: curList(type).length,
        isScraping: true,
        reason: 'profile-loaded',
        method: 'native-sniffer',
        fetchMode
      };
      const totalLabel = totalForFetch != null ? totalForFetch.toLocaleString() : '—';
      await sendHudMessage(tab.id, {
        action: 'updateHud',
        ...buildHudState({
          status: `Logged in as @${jobState.username} • ${totalLabel} ${cfg.label.toLowerCase()}`
        })
      }, 12);
      notifyProgress({
        status: `Logged in as @${jobState.username} • opening ${cfg.label}...`
      });
      await sleep(XC_PRE_LIST_FETCH_SETTLE_MS);
      throwIfCancelled();

      await runNativeListFetch(tab.id, {
        username: jobState.username,
        totalFollowing: profile.totalFollowing,
        totalFollowers: profile.totalFollowers,
        userId: profile.userId
      }, type);
    }

    await chrome.storage.local.set({ [XC_LIST_TYPE_PREF_KEY]: type });
    persistDebugStatusLog();
    return {
      ok: true,
      ...jobState,
      count: curList().length,
      mutuals: computeMutuals(),
      fetchMode,
      ...subscriptionPayload(),
      ...debugStatusPayload()
    };
  } catch (error) {
    if (isCancelledError(error)) {
      return await finishStoppedJob();
    }
    jobState.isScraping = false;
    jobState.reason = 'error';
    const errorText = String(error.message || error);
    const errorDetail = error.attemptSummary ? `${errorText} (${error.attemptSummary})` : errorText;
    notifyProgress({ status: errorDetail, error: errorDetail, reason: 'error' });
    persistDebugStatusLog();
    return {
      ok: false,
      error: errorDetail,
      ...jobState,
      ...subscriptionPayload(),
      ...debugStatusPayload()
    };
  } finally {
    const hadRunningFetch = !!activeFetch?.running;
    activeFetch = null;
    if (hadRunningFetch && !jobState.isScraping && jobTabId) {
      const payload = normalizeClientState({
        type: 'scrapeStatus',
        ok: true,
        ...jobState,
        totalList: totalForType(),
        fetchTarget: effectiveFetchTarget(totalForType()),
        storedCounts: {
          following: listStore.following.list.length,
          followers: listStore.followers.list.length
        },
        listStats: buildListStats(),
        mutuals: computeMutuals(),
        ...subscriptionPayload(),
        ...debugStatusPayload()
      });
      chrome.runtime.sendMessage(payload).catch(() => {});
      sendHudMessage(jobTabId, {
        action: 'updateHud',
        ...buildHudState()
      }).catch(() => {});
    }
  }
}

function jobLooksBusy() {
  return !!(
    activeFetch?.running
    || activeEnrich?.running
    || jobState.isScraping
    || jobState.isEnriching
    || jobState.reason === 'filtering'
    || jobState.reason === 'enriching'
    || jobState.reason === 'loading-profile'
    || jobState.reason === 'profile-loaded'
    || jobState.reason === 'waiting-native'
    || jobState.reason === 'collecting'
  );
}

function cancelActiveWork() {
  jobCancelled = true;
  if (activeFetch) {
    activeFetch.cancelled = true;
    activeFetch.running = false;
  }
  if (activeEnrich?.running || jobState.isEnriching || jobState.reason === 'enriching' || jobState.reason === 'filtering') {
    activeEnrich = { running: false, cancelled: true };
  } else if (activeEnrich) {
    activeEnrich.cancelled = true;
  }
  jobState.isScraping = false;
  jobState.isEnriching = false;
  jobState.filterPhase = null;
}

function isJobCancelled() {
  return jobCancelled || !!(activeFetch?.cancelled || activeEnrich?.cancelled);
}

function throwIfCancelled() {
  if (isJobCancelled()) {
    const error = new Error('Job cancelled');
    error.code = 'XC_CANCELLED';
    throw error;
  }
}

function isCancelledError(error) {
  return error?.code === 'XC_CANCELLED' || isJobCancelled();
}

async function finishStoppedJob(status = 'Stopped.', options = {}) {
  cancelActiveWork();
  await restoreDebugStatusLogFromStorage();
  jobState.reason = 'stopped';
  jobState.status = status;
  jobState.isScraping = false;
  jobState.isEnriching = false;
  await persistFreshStartStopState();
  appendDebugStatusLog({ status, reason: 'stopped' });
  notifyProgress({ status, reason: 'stopped', isScraping: false, isEnriching: false });
  persistDebugStatusLog();
  activeFetch = null;
  activeEnrich = null;
  if (options.notifyHud !== false && jobTabId) {
    sendHudMessage(jobTabId, {
      action: 'updateHud',
      ...buildHudState({ status, reason: 'stopped', isScraping: false, isEnriching: false })
    }).catch(() => {});
  }
  return {
    ok: true,
    ...jobState,
    count: curList().length,
    reason: 'stopped',
    isScraping: false,
    isEnriching: false,
    ...debugStatusPayload()
  };
}

async function stopScrape(status = 'Stopped.', options = {}) {
  const hadActiveWork = jobLooksBusy() || !!activeFetch || !!activeEnrich;
  cancelActiveWork();

  if (hadActiveWork) {
    return await finishStoppedJob(status, options);
  }

  await restoreDebugStatusLogFromStorage();
  jobState.reason = 'stopped';
  appendDebugStatusLog({ status, reason: 'stopped' });
  notifyProgress({ status, reason: 'stopped', isScraping: false, isEnriching: false });
  persistDebugStatusLog();
  activeFetch = null;
  activeEnrich = null;
  return {
    ok: true,
    ...jobState,
    count: curList().length,
    reason: 'stopped',
    isScraping: false,
    isEnriching: false,
    ...debugStatusPayload()
  };
}

async function dismissHud() {
  return await stopScrape('HUD closed — work stopped.', { notifyHud: false });
}

function listFilterWasApplied(type = listType) {
  const count = curList(type).length;
  const rawCount = curRaw(type).length;
  if (jobState.reason === 'filtered' || jobState.reason === 'filtering') return true;
  return rawCount > 0 && count < rawCount;
}

function isExportFiltered(type = listType) {
  if (Array.isArray(jobState.appliedFilters) && jobState.appliedFilters.length > 0) {
    return true;
  }
  return listFilterWasApplied(type);
}

function buildExportFilterSuffix(type = listType) {
  const filters = Array.isArray(jobState.appliedFilters)
    ? jobState.appliedFilters.filter(Boolean)
    : [];
  if (!filters.length) return '';
  return `_${filters.join('_')}`;
}

function sanitizeExportFilenamePart(value) {
  return String(value || '')
    .replace(/[<>:"/\\|?*@]/g, '_')
    .replace(/\s+/g, '_')
    .slice(0, 80) || 'user';
}

function waitForDownloadComplete(downloadId, timeoutMs = 120000) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      chrome.downloads.onChanged.removeListener(onChanged);
      clearTimeout(timer);
    };
    const finish = (fn, value) => {
      if (settled) return;
      settled = true;
      cleanup();
      fn(value);
    };

    const onChanged = (delta) => {
      if (delta.id !== downloadId) return;
      if (delta.error?.current) {
        finish(reject, new Error(delta.error.current));
        return;
      }
      if (delta.state?.current === 'complete') {
        chrome.downloads.search({ id: downloadId }, (items) => {
          if (chrome.runtime.lastError) {
            finish(resolve, { id: downloadId });
            return;
          }
          finish(resolve, items?.[0] || { id: downloadId });
        });
        return;
      }
      if (delta.state?.current === 'interrupted') {
        finish(reject, new Error('Download interrupted'));
      }
    };

    chrome.downloads.onChanged.addListener(onChanged);
    const timer = setTimeout(() => {
      finish(reject, new Error('Download timed out'));
    }, timeoutMs);

    chrome.downloads.search({ id: downloadId }, (items) => {
      if (chrome.runtime.lastError) return;
      const item = items?.[0];
      if (!item) return;
      if (item.state === 'complete') {
        finish(resolve, item);
      } else if (item.state === 'interrupted') {
        finish(reject, new Error(item.error || 'Download interrupted'));
      }
    });
  });
}

async function downloadCsvFile(csvContent, filename) {
  const blob = new Blob(['\ufeff', csvContent], { type: 'text/csv;charset=utf-8' });
  const dataUrl = await new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => reject(reader.error || new Error('Could not encode CSV for download.'));
    reader.readAsDataURL(blob);
  });

  const downloadId = await chrome.downloads.download({
    url: dataUrl,
    filename,
    saveAs: true
  });

  return waitForDownloadComplete(downloadId);
}

function rowsForExport(type = listType) {
  const rows = curList(type).slice();
  const cap = subscriptionInfo.fetchLimit;
  if (cap == null) return { rows, capped: false, total: rows.length };
  const limited = rows.slice(0, cap);
  return {
    rows: limited,
    capped: limited.length < rows.length,
    total: rows.length
  };
}

async function exportCSV(options = {}) {
  const requestedType = options.listType || listType;
  if (LIST_CONFIG[requestedType]) {
    listType = requestedType;
    jobState.listType = requestedType;
  }

  await ensureRestored();
  if (!curList().length) {
    await restoreListState(listType);
  }

  if (!curList().length) {
    return { ok: false, error: `No ${listCfg().label.toLowerCase()} collected yet.` };
  }

  await applyFreeTierWindow(jobState.username);
  await refreshSubscription(jobState.username);

  const exportRows = rowsForExport(listType);
  if (!exportRows.rows.length) {
    return { ok: false, error: `No ${listCfg().label.toLowerCase()} collected yet.` };
  }

  const owner = sanitizeExportFilenamePart(jobState.username);
  const cfg = listCfg();
  const date = new Date().toISOString().slice(0, 10);
  const filterSuffix = buildExportFilterSuffix();
  const filename = `x_${cfg.path}_${owner}_${date}${filterSuffix}.csv`;
  const csvContent = buildCsv(exportRows.rows);

  let downloadItem = null;
  try {
    downloadItem = await downloadCsvFile(csvContent, filename);
  } catch (error) {
    return {
      ok: false,
      error: String(error?.message || error || 'CSV download failed.')
    };
  }

  const exportedCount = exportRows.rows.length;
  const capNote = exportRows.capped
    ? ` (free tier: first ${exportedCount.toLocaleString()} of ${exportRows.total.toLocaleString()})`
    : '';
  const savedPath = downloadItem?.filename || filename;
  jobState.reason = 'exported';
  jobState.count = curList().length;
  jobState.status = `Exported ${exportedCount.toLocaleString()} accounts to ${savedPath}${capNote}`;
  notifyProgress({ status: jobState.status, reason: 'exported' });
  return {
    ok: true,
    ...normalizeClientState(getStatus()),
    exported: true,
    exportedCount,
    filename: savedPath,
    isFiltered: isExportFiltered(),
    status: jobState.status
  };
}

async function getStatusAsync() {
  if (!jobState.isScraping && !activeFetch?.running) {
    await syncActiveAccountFromTab({ refreshSub: false });
  }
  await ensureRestored();
  await restoreDebugStatusLogFromStorage();
  if (jobState.username) {
    await applyFreeTierWindow(jobState.username);
  } else {
    await hydrateSubscriptionFromStorage(null);
  }
  const fetchMode = await getFetchMode();
  await loadFastScrollPref();
  const storedCounts = {
    following: listStore.following.list.length,
    followers: listStore.followers.list.length
  };
  return normalizeClientState({
    ok: true,
    ...jobState,
    listType,
    count: curList().length,
    rawCount: curRaw().length || curList().length,
    totalList: totalForType(),
    storedCounts,
    restoredFromStorage: restoredFromStorage(),
    restoredTypes: { ...restoredTypes },
    mutuals: computeMutuals(),
    fetchTarget: effectiveFetchTarget(totalForType()),
    fetchMode,
    fetchModeLabel: fetchModeLabel(fetchMode),
    fastScroll: fastScrollEnabled,
    fastScrollLabel: scrollModeLabel(),
    listStats: buildListStats(),
    ...subscriptionPayload(),
    ...debugStatusPayload()
  });
}

function getStatus() {
  const storedCounts = {
    following: listStore.following.list.length,
    followers: listStore.followers.list.length
  };
  return normalizeClientState({
    ok: true,
    ...jobState,
    listType,
    count: curList().length,
    rawCount: curRaw().length || curList().length,
    totalList: totalForType(),
    storedCounts,
    restoredFromStorage: restoredFromStorage(),
    restoredTypes: { ...restoredTypes },
    mutuals: computeMutuals(),
    fetchTarget: effectiveFetchTarget(totalForType()),
    fetchMode: jobState.fetchMode || XC_FETCH_MODE_DEFAULT,
    fetchModeLabel: fetchModeLabel(jobState.fetchMode || XC_FETCH_MODE_DEFAULT),
    fastScroll: fastScrollEnabled,
    fastScrollLabel: scrollModeLabel(),
    listStats: buildListStats(),
    ...subscriptionPayload(),
    ...debugStatusPayload()
  });
}

async function restoreDebugStatusLogFromStorage() {
  if (!XC_DEBUG_STATUS_LOG) return;
  try {
    const stored = await chrome.storage.local.get(XC_DEBUG_STATUS_LOG_STORAGE_KEY);
    const lines = stored[XC_DEBUG_STATUS_LOG_STORAGE_KEY];
    if (!Array.isArray(lines) || !lines.length) return;
    const storedLines = lines.slice(-XC_DEBUG_STATUS_LOG_MAX_LINES);
    const current = Array.isArray(jobState.debugStatusLog) ? jobState.debugStatusLog : [];
    jobState.debugStatusLog = current.length >= storedLines.length ? current : storedLines;
  } catch (error) {}
}

async function bootstrapSubscription() {
  await syncActiveAccountFromTab({ refreshSub: false });
  await restoreDebugStatusLogFromStorage();
  if (jobState.username) {
    await restoreAllListState();
    await refreshSubscription(jobState.username, false);
  } else {
    await hydrateSubscriptionFromStorage(null);
  }
}

function configureActionPopupForDebugLog() {
  try {
    if (XC_DEBUG_STATUS_LOG) {
      chrome.action.setPopup({ popup: '' });
    } else {
      chrome.action.setPopup({ popup: 'popup.html' });
    }
  } catch (error) {}
}

async function openPersistentPopupWindow() {
  const base = chrome.runtime.getURL('popup.html');
  const url = `${base}?panel=1`;
  try {
    const wins = await chrome.windows.getAll({ populate: true });
    for (const win of wins) {
      const match = (win.tabs || []).find((tab) => tab.url && tab.url.startsWith(base));
      if (match) {
        await chrome.windows.update(win.id, { focused: true });
        return;
      }
    }
    await chrome.windows.create({
      url,
      type: 'popup',
      width: 440,
      height: 760,
      focused: true
    });
  } catch (error) {}
}

chrome.action.onClicked.addListener(() => {
  if (!XC_DEBUG_STATUS_LOG) return;
  openPersistentPopupWindow();
});

chrome.runtime.onInstalled.addListener(() => {
  configureActionPopupForDebugLog();
  console.log('X Cleaner installed');
  bootstrapSubscription().catch(() => {});
});

chrome.runtime.onStartup.addListener(() => {
  configureActionPopupForDebugLog();
  bootstrapSubscription().catch(() => {});
});

chrome.tabs.onRemoved.addListener((tabId) => {
  if (jobTabId === tabId) {
    cancelActiveWork();
    activeFetch = null;
    activeEnrich = null;
    jobTabId = null;
  }
});

configureActionPopupForDebugLog();

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message.type === 'scrapeStatus') {
    return false;
  }

  (async () => {
    try {
      if (message.action === 'syncFromFocusedTab') {
      await syncActiveAccountFromTab({
        tabId: message.tabId,
        username: message.username || null,
        refreshSub: message.refreshSub !== false,
        forceSubRefresh: !!message.force
      });
      notifyProgress();
      sendResponse({ ok: true, ...getStatus() });
      return;
    }

    await ensureRestored();

    switch (message.action) {
      case 'runExportFlow':
        sendResponse(await runExportFlow(message.listType || listType, {
          fetchMode: message.fetchMode,
          forceRefresh: !!message.forceRefresh,
          handoffAfterHud: !!message.handoffAfterHud,
          fastScroll: message.fastScroll
        }));
        break;
      case 'stopScrape':
        sendResponse(await stopScrape());
        break;
      case 'dismissHud':
        sendResponse(await dismissHud());
        break;
      case 'exportCSV':
        sendResponse(await exportCSV({ listType: message.listType }));
        break;
      case 'getListPreview':
        sendResponse(await getListPreview(message.listType));
        break;
      case 'loadListCsv':
        sendResponse(await loadListFromCsv(message.listType || listType, message.csvText || '', {
          mode: message.mode
        }));
        break;
      case 'setListType':
        sendResponse(await setListType(message.listType));
        break;
      case 'filterFollowingList':
      case 'filterList':
        sendResponse(await filterList({
          listType: message.listType,
          removeBlue: !!message.removeBlue,
          removeInactive: !!message.removeInactive,
          removeMutuals: !!message.removeMutuals,
          botCheck: !!message.botCheck,
          inactiveMonths: message.inactiveMonths,
          handoffAfterHud: !!message.handoffAfterHud
        }));
        break;
      case 'getMutuals':
        sendResponse({ ok: true, ...computeMutuals() });
        break;
      case 'checkSubscription':
        if (message.handoffAfterHud) {
          const handoff = await ensurePopupHudHandoff(message, {
            status: 'Refreshing subscription status...'
          });
          if (!handoff.ok) {
            sendResponse(handoff);
            break;
          }
          void (async () => {
            if (message.syncFromTab) {
              await syncActiveAccountFromTab({
                tabId: message.tabId,
                username: message.username || null,
                refreshSub: true,
                forceSubRefresh: !!message.force
              });
            } else {
              await refreshSubscription(message.username || null, !!message.force);
            }
            notifyProgress();
          })().catch((error) => {
            const errorText = String(error?.message || error);
            notifyProgress({ status: errorText, error: errorText, reason: 'error' });
          });
          sendResponse(attachHudReady({
            ok: true,
            ...normalizeClientState(getStatus())
          }, true));
          break;
        }
        if (message.syncFromTab) {
          await syncActiveAccountFromTab({
            tabId: message.tabId,
            username: message.username || null,
            refreshSub: true,
            forceSubRefresh: !!message.force
          });
        } else {
          await refreshSubscription(message.username || null, !!message.force);
        }
        notifyProgress();
        sendResponse({ ok: true, ...getStatus() });
        break;
      case 'setFetchMode':
        sendResponse({
          ok: true,
          fetchMode: await setFetchMode(message.fetchMode),
          ...(await getStatusAsync())
        });
        break;
      case 'setFastScroll':
        await setFastScrollPref(!!message.fastScroll);
        notifyProgress();
        sendResponse({
          ok: true,
          fastScroll: fastScrollEnabled,
          fastScrollLabel: scrollModeLabel(),
          ...(await getStatusAsync())
        });
        break;
      case 'getStatus':
      case 'getJobState':
        if (message.handoffAfterHud) {
          const handoff = await ensurePopupHudHandoff(message);
          if (!handoff.ok) {
            sendResponse({
              ...handoff,
              ...(await getStatusAsync())
            });
            break;
          }
        }
        reconcileIdleJobState();
        if (
          message.syncFromTab !== false
          && !jobState.isScraping
          && !activeFetch?.running
        ) {
          await syncActiveAccountFromTab({
            tabId: message.tabId,
            username: message.username || null,
            refreshSub: message.refreshSub !== false,
            forceSubRefresh: !!message.force
          });
        }
        await restoreDebugStatusLogFromStorage();
        const statusPayload = await getStatusAsync();
        if (message.handoffAfterHud) {
          notifyProgress();
          sendResponse({ ...statusPayload, hudReady: true });
        } else {
          sendResponse(statusPayload);
        }
        break;
      case 'openSubscribe':
        chrome.tabs.create({
          url: subscriptionInfo.checkoutUrl || XC_PRO_CHECKOUT_URL,
          active: true
        });
        sendResponse({ ok: true });
        break;
      default:
        sendResponse({ ok: false, error: 'Unknown action.' });
    }
    } catch (err) {
      try {
        sendResponse({ ok: false, error: String(err && err.message || err) });
      } catch (e) {}
    }
  })();

  return true;
});